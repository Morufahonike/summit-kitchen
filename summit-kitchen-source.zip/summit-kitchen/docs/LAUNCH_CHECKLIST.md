# Launch checklist — Summit Kitchen

Everything below is required before the site takes real orders. Items marked **Owner** need a decision,
document or approval from Summit Kitchen Services Limited; nothing here has been assumed or invented.

## Business decisions (Owner)

| # | Item | Why it blocks launch | Where it goes |
|---|---|---|---|
| 1 | **Supplier approval** and real product range | All products are labelled samples | Admin → Products, or a supplier import (`Supplier` table is ready; `apiEnabled` stays false until approved) |
| 2 | **Real prices and stock** | Sample prices are placeholders | Admin → Products / Stock |
| 3 | **Delivery rates by state** and timelines | Checkout is disabled until a zone exists | Admin → Delivery |
| 4 | **Returns & refunds policy** | Placeholder page only | `src/app/(store)/policies/page.tsx` |
| 5 | **Tax treatment (VAT)** | Prices currently shown without VAT handling; confirm with an accountant whether prices are VAT-inclusive and what must appear on receipts | Pricing + order display |
| 6 | **Terms of sale & privacy policy** (NDPA 2023 compliance) | Legal requirement for collecting customer data | New pages |
| 7 | **Product photography** and logo files (SVG / high-res PNG) | Placeholder illustrations and a recreated logo are used | `public/images`, `src/components/Logo.tsx` |
| 8 | **Live payments approval** | Code blocks live keys unless `PAYSTACK_ALLOW_LIVE="true"` | Environment |

## Paystack go-live (Owner)

- Complete Paystack business activation: CAC documents, beneficial owners (≥25%), director proof of address (< 6 months).
- Corporate settlement bank account in the registered company name.
- Request **international payments** if non-Nigerian cards must be accepted (about 48 working hours).
- Decide settlement currency: NGN (default) or USD (needs a Zenith Bank USD domiciliary account).
- Fees at time of writing (verify on Paystack before launch): local cards 1.5% + ₦100 (₦100 waived under ₦2,500, capped at ₦2,000); international cards 3.9% + ₦100.
- Payouts: NGN next working day; USD after 2 working days.
- Set the live webhook URL, then swap to live keys and set `PAYSTACK_ALLOW_LIVE="true"` — **only after written approval**.
- Run one small real transaction and refund it as a smoke test.

## Technical (developer)

| Item | Status |
|---|---|
| `npm install` and commit the generated `package-lock.json` | Not yet done — no package registry access in the build environment |
| `npm run typecheck`, `npm run lint`, `npm run build` | **Not yet run** for the Next.js app (core logic type-checked) |
| Confirm migration matches schema with `prisma migrate diff` (see README) | Not yet run |
| Run end-to-end tests (`npm run test:e2e`) on mobile/tablet/desktop | Written, **not yet run** |
| Email provider for password resets and order confirmations | **Not connected.** In development, reset links are logged to the console; in production nothing is sent |
| Order confirmation / shipping emails | Not built (needs email provider) |
| Hosting, managed PostgreSQL, backups, domain + TLS | Not chosen — needs Owner approval for any paid service |
| Schedule `POST /api/cron/release-reservations` every 10–15 min | Needs hosting |
| Error monitoring and uptime alerts | Not set up |
| Image upload for products | Not built (products reference images under `/images/`) |
| Supplier API integration | Not built; awaiting supplier approval and API documentation |
| Make the GitHub repository private | Repository is currently **public** |
| Rate limiting behind a proxy: ensure `x-forwarded-for` is set by a trusted proxy | Depends on host |
