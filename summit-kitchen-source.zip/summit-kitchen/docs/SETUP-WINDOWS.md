# Windows guide — push the bundle and run Summit Kitchen locally

All commands are for **Windows PowerShell** (Start → type "PowerShell"). Paste one block at a time.

## 0. Install once

| Tool | Version | Get it |
|---|---|---|
| Git for Windows | 2.40+ | https://git-scm.com/download/win (includes Git Bash and Git Credential Manager) |
| Node.js | 22 LTS (22.18 or newer) | https://nodejs.org |
| PostgreSQL | 16 | https://www.postgresql.org/download/windows/ — note the password you set for the `postgres` user |

Check:

```powershell
git --version
node --version     # must print v22.18.0 or newer
psql --version     # if "not recognised", use the full path: & "C:\Program Files\PostgreSQL\16\bin\psql.exe" --version
```

## 1. Push the bundle to GitHub

The GitHub repository `Morufahonike/summit-kitchen` must still be **empty**. If the push in step 1.4 is
rejected with "fetch first" or "non-fast-forward", **stop** — someone has pushed to it. Do not force-push.

**1.1 Go to the folder containing the downloaded `summit-kitchen.bundle`** (usually Downloads):

```powershell
cd $HOME\Downloads
```

**1.2 Check the bundle.** It should print two lines, one ending in `HEAD` and one in `refs/heads/main`,
both starting with the same commit ID. That ID must match the one given in the transfer report.

```powershell
git bundle list-heads .\summit-kitchen.bundle
```

**1.3 Unpack it into a working copy and check it** (cloning validates every object in the bundle):

```powershell
git clone .\summit-kitchen.bundle summit-kitchen
cd summit-kitchen
git fsck --full
git branch --show-current
git log --oneline
git status
```

`git branch --show-current` should print `main`, and `git status` should say
`nothing to commit, working tree clean`. If the folder is empty or the branch is `master`, stop — the
bundle is the wrong file.

**1.4 Point it at GitHub and push:**

```powershell
git remote set-url origin https://github.com/Morufahonike/summit-kitchen.git
git remote -v
git push -u origin main
```

A browser window opens for GitHub sign-in the first time (Git Credential Manager). Sign in as
**Morufahonike**. Never paste a password or token into a file in this project.

**1.5 Confirm:** open https://github.com/Morufahonike/summit-kitchen. You should see the code, the README,
and the commits from step 1.3. Make sure there is **no `.env` file** in the list.

> The commits were signed by the build environment's key, so GitHub may label them "Unverified". That
> is cosmetic and doesn't affect the code.

**Recommended while you're there:** Settings → General → Danger Zone → **Change visibility → Private**.
The repository is currently public.

## 2. Run the site on your PC

Steps 2.2 onwards need internet access to download packages. Everything stays in test mode.

**2.1 Create a database** (enter the `postgres` password when asked):

```powershell
psql -U postgres -h localhost -c "CREATE DATABASE summit_kitchen;"
```

**2.2 Install packages:**

```powershell
npm install
```

This creates `package-lock.json`. Commit it after a successful build so every install uses the same versions.

**2.3 Create your `.env`** from the template and open it in Notepad:

```powershell
Copy-Item .env.example .env
notepad .env
```

Fill in:

- `DATABASE_URL="postgresql://postgres:YOUR_POSTGRES_PASSWORD@localhost:5432/summit_kitchen?schema=public"`
- `CRON_SECRET` — paste the output of the command below
- `PAYSTACK_SECRET_KEY` / `PAYSTACK_PUBLIC_KEY` — the **test** keys (`sk_test_…`, `pk_test_…`) from the
  Paystack dashboard in Test Mode. Leave `PAYSTACK_ALLOW_LIVE="false"`.
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — your first admin login (14+ characters, letters and numbers)

Generate a random secret:

```powershell
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

`.env` is excluded from Git by `.gitignore`. Never commit it or send it to anyone.

**2.4 Prepare the database and sample data:**

```powershell
npx prisma migrate deploy
npx prisma generate
npm run db:seed
npm run admin:create
```

After `admin:create` prints `Admin ready`, delete the `ADMIN_PASSWORD` line from `.env`.

**2.5 Confirm the migration matches the schema** (one-off; expected output is an empty migration).
This needs a second, empty database to compare against:

```powershell
psql -U postgres -h localhost -c "CREATE DATABASE summit_shadow;"
npx prisma migrate diff --from-migrations prisma/migrations --to-schema-datamodel prisma/schema.prisma --shadow-database-url "postgresql://postgres:YOUR_POSTGRES_PASSWORD@localhost:5432/summit_shadow"
```

**2.6 Start the site:**

```powershell
npm run dev
```

Open http://localhost:3000. Admin is at http://localhost:3000/admin.
Checkout stays disabled until you add a delivery zone under **Admin → Delivery**.

## 3. Run the checks

```powershell
npm run test:unit       # 48 unit tests, no database needed
npm run typecheck
npm run lint
npm run build
```

Database integrity tests need **Git Bash** (installed with Git). They create and delete a throwaway database:

```powershell
$env:TEST_DB_ADMIN_URL = "postgresql://postgres:YOUR_POSTGRES_PASSWORD@localhost:5432/postgres"
& "C:\Program Files\Git\bin\bash.exe" tests/db/run.sh
Remove-Item Env:TEST_DB_ADMIN_URL
```

If `psql` isn't on your PATH, first run (adjust the version if needed):
`$env:Path += ";C:\Program Files\PostgreSQL\16\bin"`

End-to-end tests (mobile, tablet, desktop) — run after `npm run build`:

```powershell
npx playwright install chromium
npm run test:e2e
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `node: bad option: --experimental-strip-types` | Node is older than 22.18 — install Node 22 LTS |
| `P1001: Can't reach database server` | PostgreSQL service not running (Services → postgresql-x64-16 → Start) or wrong password in `DATABASE_URL` |
| `bash: $'\r': command not found` when running `tests/db/run.sh` | The file got Windows line endings. Run `git rm --cached -r . ; git reset --hard` in the project (only if you have no uncommitted changes) |
| Push asks for a password | Cancel, run `git credential-manager github login`, then push again |
| `Admin password too weak` | Use 14+ characters with letters and numbers |
