// SAMPLE CATALOGUE — placeholder content only.
// No supplier has been approved. Every product is flagged isSample=true and is
// shown with a "Sample product" badge. Prices and stock are illustrative
// samples approved for demonstration, NOT real supplier prices or stock.
// Replace via the admin dashboard or a supplier import once a supplier is approved.

export type SampleCategory = { slug: string; name: string; description: string; sortOrder: number };
export type SampleProduct = {
  slug: string; sku: string; name: string; category: string; description: string;
  priceNaira: number; compareAtNaira?: number; stock: number;
  material?: string; colour?: string; featured?: boolean; bestseller?: boolean;
};

export const SAMPLE_CATEGORIES: SampleCategory[] = [
  { slug: "cookware", name: "Cookware", description: "Pots, pans and casseroles built for everyday cooking.", sortOrder: 1 },
  { slug: "utensils", name: "Utensils", description: "Spoons, spatulas and tools for the hob and the table.", sortOrder: 2 },
  { slug: "knives", name: "Knives", description: "Kitchen knives, blocks and sharpening essentials.", sortOrder: 3 },
  { slug: "appliances", name: "Appliances", description: "Small electrical helpers for faster prep.", sortOrder: 4 },
  { slug: "storage", name: "Storage", description: "Canisters, jars and containers to keep things fresh.", sortOrder: 5 },
  { slug: "baking", name: "Baking", description: "Tins, trays and tools for the home baker.", sortOrder: 6 },
  { slug: "accessories", name: "Accessories", description: "Linens, boards and finishing touches.", sortOrder: 7 },
];

export const SAMPLE_PRODUCTS: SampleProduct[] = [
  // Cookware
  { slug: "enamelled-cast-iron-casserole-24cm", sku: "SMP-CW-001", name: "Enamelled Cast Iron Casserole, 24cm", category: "cookware", description: "A heavy enamelled casserole for slow stews, jollof and braises. Even heat, oven-safe, with a tight-fitting lid.", priceNaira: 85000, compareAtNaira: 95000, stock: 12, material: "Enamelled cast iron", colour: "Forest green", featured: true, bestseller: true },
  { slug: "tri-ply-stainless-saucepan-2l", sku: "SMP-CW-002", name: "Tri-Ply Stainless Saucepan, 2L", category: "cookware", description: "Tri-ply stainless steel saucepan with a pouring lip and stay-cool handle. Suitable for all hobs.", priceNaira: 38500, stock: 20, material: "Stainless steel", colour: "Silver", featured: true },
  { slug: "non-stick-frying-pan-28cm", sku: "SMP-CW-003", name: "Non-Stick Frying Pan, 28cm", category: "cookware", description: "Everyday frying pan with a durable non-stick coating and riveted handle.", priceNaira: 27000, stock: 30, material: "Aluminium, non-stick", colour: "Charcoal", bestseller: true },
  // Utensils
  { slug: "olivewood-utensil-set-5", sku: "SMP-UT-001", name: "Olivewood Utensil Set (5 pieces)", category: "utensils", description: "Spoon, slotted spoon, spatula, ladle and turner in smooth olivewood. Gentle on all cookware.", priceNaira: 18500, stock: 25, material: "Olivewood", colour: "Natural", featured: true, bestseller: true },
  { slug: "silicone-spatula-pair", sku: "SMP-UT-002", name: "Silicone Spatula Pair", category: "utensils", description: "Heat-resistant silicone spatulas with sage handles, for mixing, folding and scraping.", priceNaira: 7500, stock: 40, material: "Silicone", colour: "Sage" },
  { slug: "stainless-balloon-whisk", sku: "SMP-UT-003", name: "Stainless Balloon Whisk", category: "utensils", description: "A balanced 30cm balloon whisk for batters, sauces and cream.", priceNaira: 6000, stock: 35, material: "Stainless steel" },
  // Knives
  { slug: "chefs-knife-20cm", sku: "SMP-KN-001", name: "Chef's Knife, 20cm", category: "knives", description: "All-purpose chef's knife with a full tang and comfortable handle.", priceNaira: 32000, stock: 15, material: "High-carbon stainless steel", featured: true, bestseller: true },
  { slug: "acacia-knife-block-set", sku: "SMP-KN-002", name: "Acacia Knife Block Set (5 pieces)", category: "knives", description: "Chef's, bread, utility and paring knives with an acacia wood block.", priceNaira: 74000, stock: 6, material: "Stainless steel, acacia" },
  { slug: "two-stage-knife-sharpener", sku: "SMP-KN-003", name: "Two-Stage Knife Sharpener", category: "knives", description: "Coarse and fine sharpening stages to keep edges keen.", priceNaira: 9500, stock: 18 },
  // Appliances
  { slug: "electric-kettle-1-7l", sku: "SMP-AP-001", name: "Electric Kettle, 1.7L", category: "appliances", description: "Cordless kettle with auto shut-off and a matt ivory finish.", priceNaira: 45000, stock: 10, colour: "Warm ivory", featured: true },
  { slug: "hand-blender-set", sku: "SMP-AP-002", name: "Hand Blender Set", category: "appliances", description: "Stick blender with whisk and chopper attachments for soups and sauces.", priceNaira: 52000, stock: 8, bestseller: true },
  { slug: "digital-kitchen-scale", sku: "SMP-AP-003", name: "Digital Kitchen Scale", category: "appliances", description: "Precise to 1g with a tare function and slim glass platform.", priceNaira: 14500, stock: 0 },
  // Storage
  { slug: "glass-canister-set-3", sku: "SMP-ST-001", name: "Glass Canister Set (3 pieces)", category: "storage", description: "Airtight glass canisters with bamboo lids for grains, beans and pasta.", priceNaira: 24000, stock: 22, material: "Glass, bamboo", featured: true },
  { slug: "stackable-food-containers-10", sku: "SMP-ST-002", name: "Stackable Food Containers (10 pieces)", category: "storage", description: "Leak-resistant containers that nest neatly. Freezer and microwave safe.", priceNaira: 19500, stock: 28, bestseller: true },
  { slug: "ceramic-spice-jars-6", sku: "SMP-ST-003", name: "Ceramic Spice Jars (6 pieces)", category: "storage", description: "Ivory ceramic jars with sealed lids and a bamboo rack.", priceNaira: 21000, stock: 3, colour: "Warm ivory" },
  // Baking
  { slug: "non-stick-loaf-tin", sku: "SMP-BK-001", name: "Non-Stick Loaf Tin, 900g", category: "baking", description: "Heavy-gauge loaf tin for bread, banana loaf and cakes.", priceNaira: 9000, stock: 26 },
  { slug: "springform-cake-pan-23cm", sku: "SMP-BK-002", name: "Springform Cake Pan, 23cm", category: "baking", description: "Leak-resistant springform pan with a quick-release clasp.", priceNaira: 13500, stock: 14, bestseller: true },
  { slug: "stoneware-mixing-bowl-set", sku: "SMP-BK-003", name: "Stoneware Mixing Bowl Set (3 pieces)", category: "baking", description: "Sturdy stoneware bowls in sage, ivory and taupe.", priceNaira: 36000, stock: 9, material: "Stoneware", featured: true },
  // Accessories
  { slug: "acacia-serving-board", sku: "SMP-AC-001", name: "Acacia Serving Board", category: "accessories", description: "Generous acacia board for chopping and serving, with a juice groove.", priceNaira: 16500, stock: 17, material: "Acacia wood", bestseller: true },
  { slug: "linen-tea-towels-3", sku: "SMP-AC-002", name: "Linen Tea Towels (3 pieces)", category: "accessories", description: "Absorbent stonewashed linen towels in sage, ivory and taupe.", priceNaira: 11000, stock: 30, material: "Linen" },
  { slug: "quilted-oven-gloves", sku: "SMP-AC-003", name: "Quilted Oven Gloves", category: "accessories", description: "Double oven gloves with heat-resistant quilted cotton.", priceNaira: 8500, stock: 21, material: "Cotton", colour: "Forest green" },
];

export function productImage(category: string): string {
  return `/images/products/${category}.svg`;
}
