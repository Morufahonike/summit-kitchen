// Seeds the labelled sample catalogue. Idempotent (upserts by slug/SKU).
// Does NOT create delivery zones (rates are unconfigured by design), suppliers,
// customers or admins. Create the first admin with `npm run admin:create`.
import { PrismaClient } from "@prisma/client";
import { SAMPLE_CATEGORIES, SAMPLE_PRODUCTS, productImage } from "./sample-data.ts";

const prisma = new PrismaClient();

async function main(): Promise<void> {
  const ids = new Map<string, string>();
  for (const c of SAMPLE_CATEGORIES) {
    const row = await prisma.category.upsert({
      where: { slug: c.slug },
      update: { name: c.name, description: c.description, sortOrder: c.sortOrder },
      create: c,
    });
    ids.set(c.slug, row.id);
  }
  for (const p of SAMPLE_PRODUCTS) {
    const data = {
      name: p.name,
      sku: p.sku,
      description: p.description,
      priceKobo: p.priceNaira * 100,
      compareAtKobo: p.compareAtNaira ? p.compareAtNaira * 100 : null,
      material: p.material ?? null,
      colour: p.colour ?? null,
      isFeatured: p.featured ?? false,
      isBestseller: p.bestseller ?? false,
      isSample: true,
      image: productImage(p.category),
      categoryId: ids.get(p.category)!,
    };
    // Stock is only set on first insert so re-seeding never overwrites real stock counts.
    await prisma.product.upsert({ where: { slug: p.slug }, update: data, create: { ...data, slug: p.slug, stock: p.stock } });
  }
  console.log(`Seeded ${SAMPLE_CATEGORIES.length} categories and ${SAMPLE_PRODUCTS.length} SAMPLE products.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
