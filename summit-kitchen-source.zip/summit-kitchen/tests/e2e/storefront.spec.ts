import { test, expect } from "@playwright/test";

test("home page shows brand hero, categories and sample labelling", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1, name: "Elevate Your Everyday Living" })).toBeVisible();
  await expect(page.getByText("samples", { exact: false }).first()).toBeVisible();
  await expect(page.getByRole("link", { name: /cookware/i }).first()).toBeVisible();
});

test("no horizontal scrolling on key pages", async ({ page }) => {
  for (const path of ["/", "/shop", "/collections", "/cart", "/account/login", "/track"]) {
    await page.goto(path);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow, path).toBeLessThanOrEqual(0);
  }
});

test("search and category filter narrow results", async ({ page }) => {
  await page.goto("/shop?q=casserole");
  await expect(page.getByRole("heading", { name: /casserole/i })).toBeVisible();
  await page.goto("/shop?category=knives");
  await expect(page.getByRole("heading", { level: 1, name: "Knives" })).toBeVisible();
});

test("add to cart, then checkout is blocked while delivery rates are unconfigured", async ({ page }) => {
  await page.goto("/product/olivewood-utensil-set-5");
  await expect(page.getByText("Sample product.")).toBeVisible();
  await page.getByRole("button", { name: "Add to cart" }).click();
  await expect(page.getByText("Added to your cart")).toBeVisible();
  await page.goto("/cart");
  await expect(page.getByText("Olivewood Utensil Set (5 pieces)")).toBeVisible();
  await page.getByRole("link", { name: "Proceed to checkout" }).click();
  // With no delivery zones configured the order cannot be placed.
  await expect(page.getByText("Delivery rates are not configured yet.")).toBeVisible();
  await expect(page.getByRole("button", { name: "Checkout unavailable" })).toBeDisabled();
});

test("sold-out products cannot be added", async ({ page }) => {
  await page.goto("/product/digital-kitchen-scale"); // seeded with 0 stock
  await expect(page.getByRole("button", { name: "Sold out" })).toBeDisabled();
});

test("unknown product returns 404", async ({ page }) => {
  const res = await page.goto("/product/does-not-exist");
  expect(res?.status()).toBe(404);
});
