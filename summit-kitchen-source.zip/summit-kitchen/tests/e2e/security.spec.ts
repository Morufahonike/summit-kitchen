import { test, expect } from "@playwright/test";

test("security headers are set", async ({ request }) => {
  const res = await request.get("/");
  const h = res.headers();
  expect(h["x-frame-options"]).toBe("DENY");
  expect(h["x-content-type-options"]).toBe("nosniff");
  expect(h["content-security-policy"]).toContain("frame-ancestors 'none'");
  expect(h["x-powered-by"]).toBeUndefined();
});

test("admin is not reachable without signing in", async ({ page }) => {
  await page.goto("/admin");
  await expect(page).toHaveURL(/\/account\/login/);
});

test("a signed-in customer cannot open admin", async ({ page }) => {
  const email = `e2e-${Date.now()}@example.com`;
  await page.goto("/account/login");
  const reg = page.locator("form").nth(1);
  await reg.getByLabel("Full name").fill("E2E Customer");
  await reg.getByLabel("Email").fill(email);
  await reg.getByLabel(/^Password/).fill("Summit-E2E-2026");
  await reg.getByLabel("Confirm password").fill("Summit-E2E-2026");
  await reg.getByRole("button", { name: "Create account" }).click();
  await expect(page).toHaveURL(/\/account$/);
  await page.goto("/admin");
  await expect(page).not.toHaveURL(/\/admin/);
});

test("order pages are not viewable by reference alone", async ({ page }) => {
  const res = await page.goto("/orders/SK-261021-AAAAAA");
  expect(res?.status()).toBe(404);
});

test("webhook rejects unsigned and wrongly signed payloads", async ({ request }) => {
  const body = JSON.stringify({ event: "charge.success", data: { reference: "SK-261021-AAAAAA-PAAAAAA" } });
  const none = await request.post("/api/paystack/webhook", { data: body, headers: { "content-type": "application/json" } });
  expect([401, 503]).toContain(none.status());
  const bad = await request.post("/api/paystack/webhook", { data: body, headers: { "content-type": "application/json", "x-paystack-signature": "0".repeat(128) } });
  expect([401, 503]).toContain(bad.status());
});

test("reservation cleanup endpoint requires the cron secret", async ({ request }) => {
  const res = await request.post("/api/cron/release-reservations");
  expect(res.status()).toBe(401);
});

test("login does not reveal whether an email exists", async ({ page }) => {
  await page.goto("/account/login");
  const login = page.locator("form").first();
  await login.getByLabel("Email").fill("nobody-here@example.com");
  await login.getByLabel("Password").fill("Wrong-password-1");
  await login.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByText("Incorrect email or password.")).toBeVisible();
});
