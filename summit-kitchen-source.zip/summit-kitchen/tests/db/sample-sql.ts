// Emits SQL inserts for the sample catalogue so tests/db/run.sh can prove the
// seed data satisfies every schema constraint without needing Prisma.
import { SAMPLE_CATEGORIES, SAMPLE_PRODUCTS, productImage } from "../../prisma/sample-data.ts";

const s = (v: string | null | undefined) => (v == null ? "NULL" : `'${v.replace(/'/g, "''")}'`);
const out: string[] = ["BEGIN;"];
for (const c of SAMPLE_CATEGORIES) {
  out.push(`INSERT INTO "Category"(id,name,slug,description,"sortOrder","updatedAt") VALUES (${s("cat_" + c.slug)},${s(c.name)},${s(c.slug)},${s(c.description)},${c.sortOrder},now());`);
}
for (const p of SAMPLE_PRODUCTS) {
  out.push(
    `INSERT INTO "Product"(id,name,slug,sku,description,"priceKobo","compareAtKobo",stock,"isFeatured","isBestseller","isSample",material,colour,image,"categoryId","updatedAt") VALUES (` +
      [s("prd_" + p.slug.slice(0, 30)), s(p.name), s(p.slug), s(p.sku), s(p.description), p.priceNaira * 100,
       p.compareAtNaira ? p.compareAtNaira * 100 : "NULL", p.stock, p.featured ?? false, p.bestseller ?? false, true,
       s(p.material), s(p.colour), s(productImage(p.category)), s("cat_" + p.category), "now()"].join(",") + ");",
  );
}
out.push("COMMIT;");
console.log(out.join("\n"));
