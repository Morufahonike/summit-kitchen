#!/usr/bin/env bash
# Database integrity tests against a real PostgreSQL. Creates and drops a
# throwaway database. Requires `psql`/`createdb` and a role that can create DBs.
#
#   TEST_DB_ADMIN_URL=postgresql:///postgres npm run test:db
#
# The SQL statements mirror exactly what the app issues via Prisma
# (see src/lib/server/checkout.ts and payments.ts).
set -uo pipefail

ADMIN_URL="${TEST_DB_ADMIN_URL:-postgresql:///postgres}"
DB="sk_dbtest_$$"
BASE="${ADMIN_URL%/*}"
URL="$BASE/$DB"
DIR="$(cd "$(dirname "$0")/../.." && pwd)"
PASS=0; FAIL=0

q() { psql "$URL" -v ON_ERROR_STOP=1 -qtAX -c "$1"; }
ok()   { echo "ok   - $1"; PASS=$((PASS+1)); }
bad()  { echo "FAIL - $1 ${2:-}"; FAIL=$((FAIL+1)); }
expect_eq() { if [[ "$2" == "$3" ]]; then ok "$1"; else bad "$1" "(expected '$3', got '$2')"; fi; }
expect_error() { if q "$2" >/dev/null 2>&1; then bad "$1" "(statement unexpectedly succeeded)"; else ok "$1"; fi; }

cleanup() { psql "$ADMIN_URL" -qc "DROP DATABASE IF EXISTS $DB" >/dev/null 2>&1; }
trap cleanup EXIT

psql "$ADMIN_URL" -qc "CREATE DATABASE $DB" >/dev/null || { echo "cannot create test database"; exit 2; }

# 1. Migration applies cleanly
if psql "$URL" -v ON_ERROR_STOP=1 -q -f "$DIR/prisma/migrations/20261021000000_init/migration.sql" >/dev/null; then
  ok "migration applies to an empty database"
else
  bad "migration applies to an empty database"; exit 1
fi
expect_eq "18 tables created" "$(q "select count(*) from information_schema.tables where table_schema='public'")" "18"

# Fixtures (labelled sample data)
q "insert into \"Category\"(id,name,slug,\"updatedAt\") values ('c1','Cookware','cookware',now())"
q "insert into \"Product\"(id,name,slug,sku,description,\"priceKobo\",stock,\"categoryId\",\"updatedAt\")
   values ('p1','Sample Pan','sample-pan','SK-T-1','Sample',2500000,5,'c1',now())"

# 2. Overselling: 12 concurrent buyers, 5 in stock -> exactly 5 succeed
RESERVE='begin;
  select pg_sleep(0.2);
  update "Product" set stock = stock - 1, "updatedAt" = now()
    where id = '"'"'p1'"'"' and "isActive" = true and stock >= 1
  returning 1;
commit;'
TMP="$(mktemp -d)"
for i in $(seq 1 12); do
  ( psql "$URL" -qtAX -c "$RESERVE" > "$TMP/$i.out" 2>&1 ) &
done
wait
WINS=$(cat "$TMP"/*.out | grep -c '^1$')
rm -rf "$TMP"
expect_eq "concurrent reservations never oversell (winners)" "$WINS" "5"
expect_eq "stock ends at zero, never negative" "$(q "select stock from \"Product\" where id='p1'")" "0"

# 3. Check constraints
expect_error "stock cannot go negative" "update \"Product\" set stock = -1 where id='p1'"
expect_error "price must be positive" "update \"Product\" set \"priceKobo\" = 0 where id='p1'"
q "update \"Product\" set stock = 5 where id='p1'"

q "insert into \"Order\"(id,reference,\"accessTokenHash\",email,phone,\"shippingName\",line1,city,state,\"subtotalKobo\",\"deliveryKobo\",\"totalKobo\",\"updatedAt\")
   values ('o1','SK-261021-AAAAAA','h','a@b.co','+2348031234567','Ada','1 Road','Ikeja','Lagos',2500000,100000,2600000,now())"
expect_error "order total must equal subtotal + delivery" \
  "insert into \"Order\"(id,reference,\"accessTokenHash\",email,phone,\"shippingName\",line1,city,state,\"subtotalKobo\",\"deliveryKobo\",\"totalKobo\",\"updatedAt\")
   values ('o2','SK-261021-BBBBBB','h','a@b.co','+234','Ada','1 Road','Ikeja','Lagos',100,100,1,now())"
expect_error "order line total must equal unit x qty" \
  "insert into \"OrderItem\"(id,\"orderId\",\"productId\",\"nameSnapshot\",\"skuSnapshot\",\"unitPriceKobo\",quantity,\"lineTotalKobo\") values ('i1','o1','p1','x','x',100,2,100)"
expect_error "duplicate order reference rejected" \
  "insert into \"Order\"(id,reference,\"accessTokenHash\",email,phone,\"shippingName\",line1,city,state,\"subtotalKobo\",\"deliveryKobo\",\"totalKobo\",\"updatedAt\")
   values ('o3','SK-261021-AAAAAA','h','a@b.co','+234','Ada','1 Road','Ikeja','Lagos',1,0,1,now())"

# 4. Duplicate payments / webhooks
q "insert into \"Payment\"(id,\"orderId\",reference,\"amountKobo\",currency,mode,\"updatedAt\") values ('pay1','o1','SK-261021-AAAAAA-P1',2600000,'NGN','test',now())"
expect_error "duplicate payment reference rejected" \
  "insert into \"Payment\"(id,\"orderId\",reference,\"amountKobo\",currency,mode,\"updatedAt\") values ('pay2','o1','SK-261021-AAAAAA-P1',2600000,'NGN','test',now())"
q "insert into \"WebhookEvent\"(id,provider,\"dedupeKey\",\"eventType\") values ('w1','PAYSTACK','abc','charge.success')"
expect_error "replayed webhook body rejected by dedupe key" \
  "insert into \"WebhookEvent\"(id,provider,\"dedupeKey\",\"eventType\") values ('w2','PAYSTACK','abc','charge.success')"

# 5. Payment confirmation is idempotent under concurrency: callback + webhook
#    racing to mark the same order PAID -> exactly one transition wins.
CONFIRM='update "Order" set status = '"'"'PAID'"'"', "updatedAt" = now()
  where id = '"'"'o1'"'"' and status = '"'"'PENDING_PAYMENT'"'"' returning 1;'
TMP="$(mktemp -d)"
for i in $(seq 1 6); do ( psql "$URL" -qtAX -c "$CONFIRM" > "$TMP/$i.out" 2>&1 ) & done
wait
expect_eq "concurrent payment confirmations transition order exactly once" "$(cat "$TMP"/*.out | grep -c '^1$')" "1"
rm -rf "$TMP"

# 6. Expiry release only affects unpaid, expired orders
q "insert into \"Order\"(id,reference,\"accessTokenHash\",email,phone,\"shippingName\",line1,city,state,\"subtotalKobo\",\"deliveryKobo\",\"totalKobo\",\"reservationExpiresAt\",\"updatedAt\")
   values ('o4','SK-261021-CCCCCC','h','a@b.co','+234','Ada','1 Road','Ikeja','Lagos',1,0,1,now() - interval '1 minute',now())"
RELEASED=$(q "update \"Order\" set status='EXPIRED' where status='PENDING_PAYMENT' and \"reservationExpiresAt\" < now() returning id")
expect_eq "only expired unpaid orders are released" "$RELEASED" "o4"

# 7. Category with products cannot be deleted (RESTRICT)
expect_error "category in use cannot be deleted" "delete from \"Category\" where id='c1'"

# 8. Sample catalogue satisfies every constraint
#    (fresh database so fixture rows above don't collide)
DB2="${DB}_seed"; URL2="$BASE/$DB2"
psql "$ADMIN_URL" -qc "CREATE DATABASE $DB2" >/dev/null
psql "$URL2" -q -f "$DIR/prisma/migrations/20261021000000_init/migration.sql" >/dev/null
if node --experimental-strip-types --no-warnings "$DIR/tests/db/sample-sql.ts" | psql "$URL2" -v ON_ERROR_STOP=1 -q >/dev/null 2>&1; then
  ok "sample catalogue loads into the schema"
else
  bad "sample catalogue loads into the schema"
fi
expect_eq "all seeded products flagged as samples" "$(psql "$URL2" -qtAX -c "select count(*) from \"Product\" where \"isSample\" = false")" "0"
expect_eq "seeded categories" "$(psql "$URL2" -qtAX -c "select count(*) from \"Category\"")" "7"
psql "$ADMIN_URL" -qc "DROP DATABASE IF EXISTS $DB2" >/dev/null

# 9. Rate-limit statement (same SQL as src/lib/server/ratelimit.ts) is atomic
RL='INSERT INTO "RateLimit"("key","count","windowStart") VALUES ('"'"'login:1.2.3.4'"'"', 1, now())
  ON CONFLICT ("key") DO UPDATE SET
   "count" = CASE WHEN "RateLimit"."windowStart" < now() - (900::int * interval '"'"'1 second'"'"') THEN 1 ELSE "RateLimit"."count" + 1 END,
   "windowStart" = CASE WHEN "RateLimit"."windowStart" < now() - (900::int * interval '"'"'1 second'"'"') THEN now() ELSE "RateLimit"."windowStart" END
  RETURNING "count";'
for i in $(seq 1 15); do ( psql "$URL" -qtAX -c "$RL" >/dev/null 2>&1 ) & done
wait
expect_eq "15 concurrent hits counted exactly" "$(q "select count from \"RateLimit\" where key='login:1.2.3.4'")" "15"
q "update \"RateLimit\" set \"windowStart\" = now() - interval '16 minutes' where key='login:1.2.3.4'"
expect_eq "window resets after expiry" "$(q "$RL")" "1"

echo
echo "# db tests: $PASS passed, $FAIL failed"
[[ $FAIL -eq 0 ]]
