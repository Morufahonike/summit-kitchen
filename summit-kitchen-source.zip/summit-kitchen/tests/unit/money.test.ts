import { test } from "node:test";
import assert from "node:assert/strict";
import { formatMoney, parseMajorToMinor, minorToMajorString } from "../../src/lib/core/money.ts";

test("formatMoney formats naira from kobo", () => {
  assert.equal(formatMoney(4500000), "₦45,000");
  assert.equal(formatMoney(125050), "₦1,250.50");
  assert.equal(formatMoney(0), "₦0");
  assert.equal(formatMoney(1999, "USD"), "$19.99");
});

test("formatMoney rejects non-integer minor units", () => {
  assert.throws(() => formatMoney(10.5));
});

test("parseMajorToMinor parses admin input strictly", () => {
  assert.equal(parseMajorToMinor("45,000"), 4500000);
  assert.equal(parseMajorToMinor("₦1250.5"), 125050);
  assert.equal(parseMajorToMinor("0.01"), 1);
  assert.equal(parseMajorToMinor("-5"), null);
  assert.equal(parseMajorToMinor("12.345"), null);
  assert.equal(parseMajorToMinor("abc"), null);
  assert.equal(parseMajorToMinor("1e5"), null);
  assert.equal(parseMajorToMinor(""), null);
});

test("minorToMajorString round-trips", () => {
  for (const v of [0, 1, 99, 100, 125050, 4500000]) {
    assert.equal(parseMajorToMinor(minorToMajorString(v)), v);
  }
});
