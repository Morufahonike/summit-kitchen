import { test } from "node:test";
import assert from "node:assert/strict";
import { validateProduct, validateCategory, validateZone, overlappingStates, safeNextPath } from "../../src/lib/core/admin.ts";

const base = {
  name: "Enamel Casserole", sku: "smp-cw-009", description: "A sturdy casserole for stews.", categoryId: "clx0category01",
  price: "45,000", compareAt: "", image: "/images/products/cookware.svg", isActive: "on", isSample: "on",
};

test("product validation parses price, slug and flags", () => {
  const r = validateProduct(base);
  assert.ok(r.ok);
  if (r.ok) {
    assert.equal(r.data.priceKobo, 4500000);
    assert.equal(r.data.slug, "enamel-casserole");
    assert.equal(r.data.sku, "SMP-CW-009");
    assert.equal(r.data.isActive, true);
    assert.equal(r.data.isFeatured, false);
    assert.equal(r.data.isSample, true);
  }
});

test("product validation rejects bad input", () => {
  const r = validateProduct({ ...base, price: "0", compareAt: "100", image: "https://evil.example/x.png", sku: "a b", categoryId: "" });
  assert.ok(!r.ok);
  if (!r.ok) assert.deepEqual(Object.keys(r.errors).sort(), ["categoryId", "image", "price", "sku"]);
  const c = validateProduct({ ...base, compareAt: "40000" });
  assert.ok(!c.ok && "compareAt" in c.errors);
  const js = validateProduct({ ...base, image: "javascript:alert(1)" });
  assert.ok(!js.ok);
});

test("category validation", () => {
  assert.ok(validateCategory({ name: "Table Linen", sortOrder: "3" }).ok);
  assert.ok(!validateCategory({ name: "X", sortOrder: "-1" }).ok);
});

test("zone validation and overlap", () => {
  const z = validateZone({ name: "South West", states: ["Lagos", "Ogun", "Lagos"], fee: "2,500", isActive: "on" });
  assert.ok(z.ok);
  if (z.ok) {
    assert.deepEqual(z.data.states, ["Lagos", "Ogun"]);
    assert.equal(z.data.feeKobo, 250000);
  }
  assert.ok(!validateZone({ name: "Bad", states: ["Narnia"], fee: "100" }).ok);
  assert.ok(!validateZone({ name: "Empty", states: [], fee: "100" }).ok);
  assert.ok(validateZone({ name: "Free", states: ["Oyo"], fee: "0" }).ok);
  const zones = [{ id: "a", states: ["Lagos"], isActive: true }, { id: "b", states: ["Kano"], isActive: false }];
  assert.deepEqual(overlappingStates(zones, { states: ["Lagos", "Kano"] }), ["Lagos"]);
  assert.deepEqual(overlappingStates(zones, { id: "a", states: ["Lagos"] }), []);
});

test("safeNextPath blocks open redirects", () => {
  assert.equal(safeNextPath("/checkout", "/"), "/checkout");
  assert.equal(safeNextPath("/shop?category=knives", "/"), "/shop?category=knives");
  for (const bad of ["//evil.com", "https://evil.com", "/\\evil.com", "javascript:alert(1)", "/a\nb", "", "evil.com"]) {
    assert.equal(safeNextPath(bad, "/account"), "/account", bad);
  }
});
