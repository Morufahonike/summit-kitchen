import { test } from "node:test";
import assert from "node:assert/strict";
import {
  hashPassword, verifyPassword, orderReference, paymentReference, randomToken, sha256, safeEqualHex, DUMMY_HASH,
} from "../../src/lib/core/crypto.ts";

test("password hash verifies and rejects wrong password", async () => {
  const h = await hashPassword("Summit-Kitchen-9");
  assert.match(h, /^scrypt\$32768\$8\$1\$/);
  assert.ok(await verifyPassword("Summit-Kitchen-9", h));
  assert.ok(!(await verifyPassword("summit-kitchen-9", h)));
  assert.notEqual(h, await hashPassword("Summit-Kitchen-9"), "salted");
});

test("verifyPassword is safe on malformed hashes", async () => {
  assert.equal(await verifyPassword("x", "garbage"), false);
  assert.equal(await verifyPassword("x", "scrypt$99999999$8$1$a$b"), false);
  assert.equal(await verifyPassword("x", DUMMY_HASH), false);
});

test("order references are well-formed and unique", () => {
  const ref = orderReference(new Date("2026-10-21T10:00:00Z"));
  assert.match(ref, /^SK-261021-[2-9A-HJKMNP-Z]{6}$/);
  const set = new Set(Array.from({ length: 2000 }, () => orderReference()));
  assert.equal(set.size, 2000);
  assert.match(paymentReference(ref), /^SK-261021-[A-Z0-9]{6}-P[A-Z0-9]{6}$/);
});

test("tokens and hashing", () => {
  const t = randomToken();
  assert.ok(t.length >= 43);
  assert.equal(sha256("abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  assert.ok(safeEqualHex(sha256("a"), sha256("a")));
  assert.ok(!safeEqualHex(sha256("a"), sha256("b")));
  assert.ok(!safeEqualHex("", ""));
  assert.ok(!safeEqualHex("zz", "zz"));
});
