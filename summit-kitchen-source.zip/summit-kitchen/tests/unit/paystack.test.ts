import { test } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import {
  keyMode, assertPaymentsAllowed, verifyWebhookSignature, evaluateVerification, PaystackClient, PaymentConfigError,
} from "../../src/lib/core/paystack.ts";

// Obviously fake keys — never real credentials.
const TEST_KEY = "sk_test_0000000000000000000000000000000000000000";
const LIVE_KEY = "sk_live_0000000000000000000000000000000000000000";

test("key mode detection", () => {
  assert.equal(keyMode(TEST_KEY), "test");
  assert.equal(keyMode(LIVE_KEY), "live");
  assert.equal(keyMode("pk_test_abc"), "invalid");
  assert.equal(keyMode(""), "invalid");
  assert.equal(keyMode(undefined), "invalid");
});

test("live keys are blocked unless explicitly approved", () => {
  assert.equal(assertPaymentsAllowed(TEST_KEY, undefined), "test");
  assert.throws(() => assertPaymentsAllowed(LIVE_KEY, undefined), PaymentConfigError);
  assert.throws(() => assertPaymentsAllowed(LIVE_KEY, "false"), PaymentConfigError);
  assert.throws(() => assertPaymentsAllowed(LIVE_KEY, "TRUE"), PaymentConfigError);
  assert.equal(assertPaymentsAllowed(LIVE_KEY, "true"), "live");
  assert.throws(() => assertPaymentsAllowed("nonsense", "true"), PaymentConfigError);
});

test("webhook signature: valid, tampered, wrong key, malformed", () => {
  const body = JSON.stringify({ event: "charge.success", data: { reference: "SK-1", amount: 500000 } });
  const sig = createHmac("sha512", TEST_KEY).update(body).digest("hex");
  assert.ok(verifyWebhookSignature(body, sig, TEST_KEY));
  assert.ok(verifyWebhookSignature(Buffer.from(body), sig, TEST_KEY));
  assert.ok(!verifyWebhookSignature(body.replace("500000", "1"), sig, TEST_KEY));
  assert.ok(!verifyWebhookSignature(body, sig, LIVE_KEY));
  assert.ok(!verifyWebhookSignature(body, null, TEST_KEY));
  assert.ok(!verifyWebhookSignature(body, "abc", TEST_KEY));
  assert.ok(!verifyWebhookSignature(body, sig.toUpperCase().replace(/./, "Z"), TEST_KEY));
});

const expected = { reference: "SK-261021-ABCDEF-PXYZ234", amountKobo: 5150050, currency: "NGN" };
const good = {
  status: "success", reference: expected.reference, amount: 5150050, currency: "NGN", channel: "card",
  gateway_response: "Successful", paid_at: "2026-10-21T10:00:00.000Z",
  authorization: { brand: "mastercard", card_type: "mastercard", last4: "4081" },
};

test("verification succeeds only on exact match", () => {
  const r = evaluateVerification(good, expected);
  assert.ok(r.ok);
  if (r.ok) {
    assert.equal(r.cardBrand, "mastercard");
    assert.equal(r.last4, "4081");
    assert.equal(r.paidAt?.toISOString(), "2026-10-21T10:00:00.000Z");
  }
});

test("verification rejects amount, currency, reference and status problems", () => {
  const cases: [Record<string, unknown>, RegExp, boolean][] = [
    [{ amount: 5150049 }, /Amount/, true],
    [{ amount: "5150050" }, /Amount/, true],
    [{ currency: "USD" }, /Currency/, true],
    [{ reference: "other" }, /Reference/, true],
    [{ status: "failed" }, /failed/, true],
    [{ status: "abandoned" }, /abandoned/, true],
    [{ status: "ongoing" }, /ongoing/, false],
  ];
  for (const [patch, re, final] of cases) {
    const r = evaluateVerification({ ...good, ...patch } as never, expected);
    assert.ok(!r.ok, JSON.stringify(patch));
    if (!r.ok) {
      assert.match(r.reason, re);
      assert.equal(r.final, final, JSON.stringify(patch));
    }
  }
  assert.ok(!evaluateVerification(null, expected).ok);
});

test("verification ignores malformed last4", () => {
  const r = evaluateVerification({ ...good, authorization: { last4: "40811234", brand: "x" } }, expected);
  assert.ok(r.ok && r.last4 === null);
});

test("client sends kobo amount, card channel and bearer key (mock fetch)", async () => {
  const calls: { url: string; init: { method: string; headers: Record<string, string>; body?: string } }[] = [];
  const fake = async (url: string, init: { method: string; headers: Record<string, string>; body?: string }) => {
    calls.push({ url, init });
    return { ok: true, status: 200, json: async () => ({ status: true, data: { authorization_url: "https://checkout.paystack.com/x", access_code: "x", reference: "R" } }) };
  };
  const c = new PaystackClient(TEST_KEY, fake);
  const out = await c.initialize({ email: "a@b.co", amountKobo: 5150050, currency: "NGN", reference: "R", callbackUrl: "http://localhost:3000/checkout/callback" });
  assert.equal(out.authorization_url, "https://checkout.paystack.com/x");
  assert.equal(calls[0]!.url, "https://api.paystack.co/transaction/initialize");
  assert.equal(calls[0]!.init.headers.Authorization, `Bearer ${TEST_KEY}`);
  const body = JSON.parse(calls[0]!.init.body!);
  assert.equal(body.amount, 5150050);
  assert.deepEqual(body.channels, ["card"]);
  await assert.rejects(() => c.initialize({ email: "a@b.co", amountKobo: 10.5, currency: "NGN", reference: "R", callbackUrl: "x" }));
});

test("client errors never leak the secret key", async () => {
  const fake = async () => ({ ok: false, status: 401, json: async () => ({ status: false, message: "Invalid key" }) });
  const c = new PaystackClient(TEST_KEY, fake);
  await assert.rejects(() => c.verify("SK-1"), (e: Error) => !e.message.includes(TEST_KEY) && /401/.test(e.message));
  await assert.rejects(() => c.verify("../../etc"), /Invalid reference/);
});
