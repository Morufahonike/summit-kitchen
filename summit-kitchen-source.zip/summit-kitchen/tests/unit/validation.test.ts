import { test } from "node:test";
import assert from "node:assert/strict";
import {
  normaliseNigerianPhone, isEmail, passwordProblem, slugify, isSlug, parseIntStrict,
  validateRegister, validateCheckout, validateAddress,
} from "../../src/lib/core/validation.ts";

test("Nigerian phone numbers normalise to +234", () => {
  assert.equal(normaliseNigerianPhone("08031234567"), "+2348031234567");
  assert.equal(normaliseNigerianPhone("+234 803 123 4567"), "+2348031234567");
  assert.equal(normaliseNigerianPhone("2349051234567"), "+2349051234567");
  assert.equal(normaliseNigerianPhone("0803123456"), null);
  assert.equal(normaliseNigerianPhone("+447700900000"), null);
  assert.equal(normaliseNigerianPhone("06031234567"), null);
});

test("email validation", () => {
  assert.ok(isEmail("ada@example.com"));
  assert.ok(!isEmail("ada@example"));
  assert.ok(!isEmail("a da@example.com"));
  assert.ok(!isEmail("<script>@x.com"));
});

test("password policy", () => {
  assert.match(passwordProblem("short1")!, /at least/);
  assert.match(passwordProblem("onlyletterslong")!, /letter and one number/);
  assert.match(passwordProblem("chiamaka2026x", "chiamaka@example.com")!, /email/);
  assert.equal(passwordProblem("Kitchen-Summit-42"), null);
});

test("slugs", () => {
  assert.equal(slugify("  Cast-Iron Dutch Oven (5.5L) "), "cast-iron-dutch-oven-5-5l");
  assert.equal(slugify("Crème Brûlée Set"), "creme-brulee-set");
  assert.ok(isSlug("cast-iron"));
  assert.ok(!isSlug("Cast Iron"));
  assert.ok(!isSlug("-bad"));
});

test("parseIntStrict bounds", () => {
  assert.equal(parseIntStrict("5", 0, 10), 5);
  assert.equal(parseIntStrict("11", 0, 10), null);
  assert.equal(parseIntStrict("5.5", 0, 10), null);
  assert.equal(parseIntStrict(" 5", 0, 10), null);
});

test("validateRegister", () => {
  const ok = validateRegister({ name: "Ada Obi", email: " Ada@Example.com ", password: "Summit-Kitchen-9", confirm: "Summit-Kitchen-9" });
  assert.ok(ok.ok);
  if (ok.ok) assert.equal(ok.data.email, "ada@example.com");
  const bad = validateRegister({ name: "A", email: "x", password: "Summit-Kitchen-9", confirm: "different-1" });
  assert.ok(!bad.ok);
  if (!bad.ok) assert.deepEqual(Object.keys(bad.errors).sort(), ["confirm", "email", "name"]);
});

test("validateAddress rejects unknown state", () => {
  const r = validateAddress({ fullName: "Ada Obi", phone: "08031234567", line1: "12 Marina Road", city: "Lagos", state: "Atlantis" });
  assert.ok(!r.ok);
  if (!r.ok) assert.ok(r.errors.state);
});

test("validateCheckout accepts FormData", () => {
  const fd = new FormData();
  for (const [k, v] of Object.entries({ email: "ada@example.com", fullName: "Ada Obi", phone: "08031234567", line1: "12 Marina Road", city: "Ikeja", state: "Lagos" })) fd.set(k, v);
  const r = validateCheckout(fd);
  assert.ok(r.ok);
  if (r.ok) {
    assert.equal(r.data.phone, "+2348031234567");
    assert.equal(r.data.line2, null);
  }
});
