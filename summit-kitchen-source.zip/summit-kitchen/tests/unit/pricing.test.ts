import { test } from "node:test";
import assert from "node:assert/strict";
import { computeTotals, findZoneForState, clampQuantity, MAX_QTY_PER_LINE, type PricedLine, type Zone } from "../../src/lib/core/pricing.ts";

// Fixture rates for tests only — real delivery rates are NOT configured.
const zones: Zone[] = [
  { id: "z1", name: "Test zone A", states: ["Lagos"], feeKobo: 100000, isActive: true },
  { id: "z2", name: "Inactive", states: ["Ogun"], feeKobo: 200000, isActive: false },
];

const line = (o: Partial<PricedLine> = {}): PricedLine => ({
  productId: "p1", name: "Pan", sku: "SK-1", unitPriceKobo: 2500000, quantity: 2, stock: 10, isActive: true, ...o,
});

test("totals = subtotal + zone fee", () => {
  const t = computeTotals([line(), line({ productId: "p2", unitPriceKobo: 150050, quantity: 1 })], zones, "lagos");
  assert.equal(t.subtotalKobo, 5000000 + 150050);
  assert.equal(t.deliveryKobo, 100000);
  assert.equal(t.totalKobo, 5150050 + 100000);
  assert.equal(t.problems.length, 0);
});

test("no configured zone => delivery and total are null (checkout blocked)", () => {
  const t = computeTotals([line()], zones, "Kano");
  assert.equal(t.deliveryKobo, null);
  assert.equal(t.totalKobo, null);
  assert.equal(computeTotals([line()], [], "Lagos").totalKobo, null);
});

test("inactive zones are ignored", () => {
  assert.equal(findZoneForState(zones, "Ogun"), null);
});

test("stock and quantity problems are reported", () => {
  const t = computeTotals(
    [line({ stock: 1 }), line({ productId: "p3", stock: 0, quantity: 1 }), line({ productId: "p4", quantity: MAX_QTY_PER_LINE + 1, stock: 99 }), line({ productId: "p5", isActive: false })],
    zones, "Lagos",
  );
  const byId = Object.fromEntries(t.problems.map((p) => [p.productId, p.problem]));
  assert.match(byId.p1!, /Only 1 left/);
  assert.match(byId.p3!, /Out of stock/);
  assert.match(byId.p4!, /between 1 and/);
  assert.match(byId.p5!, /No longer available/);
});

test("non-integer or negative quantities are rejected", () => {
  assert.equal(computeTotals([line({ quantity: 1.5 })], zones, "Lagos").problems.length, 1);
  assert.equal(computeTotals([line({ quantity: -1 })], zones, "Lagos").problems.length, 1);
});

test("clampQuantity", () => {
  assert.equal(clampQuantity(5, 3), 3);
  assert.equal(clampQuantity(0, 3), 1);
  assert.equal(clampQuantity(100, 100), MAX_QTY_PER_LINE);
  assert.equal(clampQuantity(Number.NaN, 3), 1);
});
