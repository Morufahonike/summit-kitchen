import { test } from "node:test";
import assert from "node:assert/strict";
import { canViewOrder } from "../../src/lib/core/access.ts";
import { sha256, randomToken } from "../../src/lib/core/crypto.ts";

const token = randomToken(24);
const guestOrder = { userId: null, accessTokenHash: sha256(token) };
const ownedOrder = { userId: "user_owner", accessTokenHash: sha256(token) };
const owner = { id: "user_owner", role: "CUSTOMER" };
const stranger = { id: "user_other", role: "CUSTOMER" };

test("guest order: only the secret link token grants access", () => {
  assert.ok(canViewOrder(guestOrder, null, token));
  assert.ok(!canViewOrder(guestOrder, null, null));
  assert.ok(!canViewOrder(guestOrder, null, ""));
  assert.ok(!canViewOrder(guestOrder, null, token + "x"));
  assert.ok(!canViewOrder(guestOrder, stranger, null), "signed-in stranger cannot view a guest order");
  assert.ok(!canViewOrder(guestOrder, null, "a".repeat(5000)), "oversized tokens rejected");
});

test("account order: owner yes, other customers no", () => {
  assert.ok(canViewOrder(ownedOrder, owner, null));
  assert.ok(!canViewOrder(ownedOrder, stranger, null));
  assert.ok(canViewOrder(ownedOrder, stranger, token), "link holder still allowed (link was emailed/shown to buyer)");
});

test("staff and admins can view all orders", () => {
  assert.ok(canViewOrder(guestOrder, { id: "s", role: "STAFF" }, null));
  assert.ok(canViewOrder(ownedOrder, { id: "a", role: "ADMIN" }, null));
});

test("a stored hash is not itself a valid token", () => {
  assert.ok(!canViewOrder(guestOrder, null, guestOrder.accessTokenHash));
});
