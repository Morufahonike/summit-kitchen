import { test } from "node:test";
import assert from "node:assert/strict";
import { SAMPLE_CATEGORIES, SAMPLE_PRODUCTS } from "../../prisma/sample-data.ts";
import { isSlug } from "../../src/lib/core/validation.ts";

const REQUIRED = ["cookware", "utensils", "knives", "appliances", "storage", "baking", "accessories"];

test("all required catalogue categories exist", () => {
  assert.deepEqual(SAMPLE_CATEGORIES.map((c) => c.slug).sort(), [...REQUIRED].sort());
});

test("every category has products, slugs and SKUs are unique and valid", () => {
  for (const c of REQUIRED) assert.ok(SAMPLE_PRODUCTS.some((p) => p.category === c), c);
  assert.equal(new Set(SAMPLE_PRODUCTS.map((p) => p.slug)).size, SAMPLE_PRODUCTS.length);
  assert.equal(new Set(SAMPLE_PRODUCTS.map((p) => p.sku)).size, SAMPLE_PRODUCTS.length);
  for (const p of SAMPLE_PRODUCTS) {
    assert.ok(isSlug(p.slug), p.slug);
    assert.match(p.sku, /^SMP-/, "sample SKUs are clearly marked");
    assert.ok(Number.isInteger(p.priceNaira) && p.priceNaira > 0);
    assert.ok(!p.compareAtNaira || p.compareAtNaira > p.priceNaira);
    assert.ok(Number.isInteger(p.stock) && p.stock >= 0);
  }
});

test("homepage has featured and bestseller items", () => {
  assert.ok(SAMPLE_PRODUCTS.filter((p) => p.featured).length >= 4);
  assert.ok(SAMPLE_PRODUCTS.filter((p) => p.bestseller).length >= 4);
});
