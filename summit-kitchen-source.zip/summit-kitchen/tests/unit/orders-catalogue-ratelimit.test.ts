import { test } from "node:test";
import assert from "node:assert/strict";
import { adminCanTransition, releasesStock, trackingSteps, isOrderStatus } from "../../src/lib/core/orders.ts";
import { parseCatalogueParams, toQuery } from "../../src/lib/core/catalogue.ts";
import { LIMITS, lockoutUntil } from "../../src/lib/core/ratelimit.ts";

test("admin order transitions", () => {
  assert.ok(adminCanTransition("PAID", "PROCESSING"));
  assert.ok(adminCanTransition("PROCESSING", "SHIPPED"));
  assert.ok(!adminCanTransition("PENDING_PAYMENT", "PAID"), "only a verified payment can mark paid");
  assert.ok(!adminCanTransition("DELIVERED", "PENDING_PAYMENT"));
  assert.ok(!adminCanTransition("CANCELLED", "PAID"));
  assert.ok(isOrderStatus("SHIPPED") && !isOrderStatus("HACKED"));
});

test("stock release rules", () => {
  assert.ok(releasesStock("PENDING_PAYMENT", "EXPIRED"));
  assert.ok(releasesStock("PAID", "CANCELLED"));
  assert.ok(!releasesStock("SHIPPED", "DELIVERED"));
  assert.ok(!releasesStock("CANCELLED", "CANCELLED"));
});

test("tracking steps", () => {
  assert.equal(trackingSteps("SHIPPED").filter((s) => s.done).length, 4);
  assert.equal(trackingSteps("PENDING_PAYMENT").filter((s) => s.done).length, 1);
});

test("catalogue params are whitelisted", () => {
  const f = parseCatalogueParams({ q: "  cast   iron ", category: "cookware", min: "50000", max: "10000", sort: "price-asc", page: "2", inStock: "1" });
  assert.deepEqual(f, { q: "cast iron", category: "cookware", minKobo: 1000000, maxKobo: 5000000, inStock: true, sort: "price-asc", page: 2 });
  const evil = parseCatalogueParams({ category: "'; DROP TABLE", sort: "__proto__", page: "-1", min: "1e9", q: "x" });
  assert.equal(evil.category, null);
  assert.equal(evil.sort, "featured");
  assert.equal(evil.page, 1);
  assert.equal(evil.minKobo, null);
  assert.equal(evil.q, null);
  assert.equal(toQuery(f, { page: 3 }), "?q=cast+iron&category=cookware&min=10000&max=50000&inStock=1&sort=price-asc&page=3");
  assert.equal(toQuery({ sort: "featured", page: 1 }), "");
});

test("rate limit policies are sane", () => {
  for (const [name, l] of Object.entries(LIMITS)) {
    assert.ok(l.limit > 0 && l.windowSec >= 60, name);
  }
});

test("login lockout escalates and caps", () => {
  const now = new Date("2026-10-21T10:00:00Z");
  assert.equal(lockoutUntil(4, now), null);
  assert.equal(lockoutUntil(5, now)!.getTime() - now.getTime(), 5 * 60_000);
  assert.equal(lockoutUntil(6, now)!.getTime() - now.getTime(), 10 * 60_000);
  assert.equal(lockoutUntil(20, now)!.getTime() - now.getTime(), 60 * 60_000);
});
