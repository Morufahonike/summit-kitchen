// Creates (or promotes) the first administrator from ADMIN_EMAIL / ADMIN_PASSWORD.
// Run once:  ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='…' npm run admin:create
// Remove ADMIN_PASSWORD from your environment afterwards.
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/core/crypto.ts";
import { isEmail, normaliseEmail, passwordProblem } from "../src/lib/core/validation.ts";

const email = normaliseEmail(process.env.ADMIN_EMAIL ?? "");
const password = process.env.ADMIN_PASSWORD ?? "";

if (!isEmail(email)) throw new Error("Set ADMIN_EMAIL to a valid email address.");
const problem = passwordProblem(password, email);
if (problem || password.length < 14) throw new Error(`Admin password too weak: ${problem ?? "use at least 14 characters."}`);

const prisma = new PrismaClient();
const passwordHash = await hashPassword(password);
const user = await prisma.user.upsert({
  where: { email },
  update: { role: "ADMIN", passwordHash, disabled: false, failedLogins: 0, lockedUntil: null },
  create: { email, name: "Administrator", passwordHash, role: "ADMIN" },
});
await prisma.session.deleteMany({ where: { userId: user.id } });
await prisma.activityLog.create({ data: { action: "admin.bootstrap", entityType: "User", entityId: user.id } });
console.log(`Admin ready: ${email}`);
await prisma.$disconnect();
