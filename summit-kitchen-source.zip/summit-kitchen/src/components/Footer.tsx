import Link from "next/link";
import { Logo } from "./Logo";

export function TrustBar() {
  const items = [
    { t: "Premium Quality", s: "Built to last" },
    { t: "Curated Collections", s: "For every home" },
    { t: "Delivery Across Nigeria", s: "Rates confirmed at checkout" },
    { t: "Secure Payments", s: "Mastercard, Visa & Verve via Paystack" },
  ];
  return (
    <section className="border-y border-taupe-300 bg-white" aria-label="Why shop with us">
      <ul className="container-site grid grid-cols-2 gap-4 py-6 lg:grid-cols-4">
        {items.map((i) => (
          <li key={i.t} className="flex items-start gap-3">
            <span className="mt-1 h-2 w-2 shrink-0 rotate-45 bg-gold" aria-hidden="true" />
            <span>
              <span className="block text-sm font-semibold">{i.t}</span>
              <span className="block text-xs text-charcoal-400">{i.s}</span>
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="mt-16 bg-forest text-ivory/80">
      <div className="container-site grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo tone="light" />
          <p className="mt-4 max-w-xs text-sm">Elevating the art of everyday living.</p>
        </div>
        <div>
          <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-gold">Shop</h2>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link href="/shop" className="hover:text-white">All products</Link></li>
            <li><Link href="/collections" className="hover:text-white">Collections</Link></li>
            <li><Link href="/shop?sort=newest" className="hover:text-white">New arrivals</Link></li>
          </ul>
        </div>
        <div>
          <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-gold">Help</h2>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link href="/track" className="hover:text-white">Track an order</Link></li>
            <li><Link href="/policies" className="hover:text-white">Delivery &amp; returns</Link></li>
            <li><Link href="/account" className="hover:text-white">My account</Link></li>
          </ul>
        </div>
        <div>
          <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-gold">Company</h2>
          <p className="mt-3 text-sm">Summit Kitchen Services Limited<br />RC 9927529</p>
        </div>
      </div>
      <div className="border-t border-ivory/10">
        <p className="container-site py-4 text-xs text-ivory/60">© {new Date().getFullYear()} Summit Kitchen Services Limited. All rights reserved.</p>
      </div>
    </footer>
  );
}
