import { NIGERIAN_STATES } from "@/lib/core/validation";

type Props = {
  name: string; label: string; type?: string; error?: string; defaultValue?: string | null;
  autoComplete?: string; required?: boolean; placeholder?: string; inputMode?: "text" | "email" | "tel" | "numeric" | "decimal";
};

export function Field({ name, label, type = "text", error, defaultValue, autoComplete, required, placeholder, inputMode }: Props) {
  const id = `f-${name}`;
  return (
    <div>
      <label htmlFor={id} className="label">{label}{required && <span className="text-red-700"> *</span>}</label>
      <input
        id={id} name={name} type={type} className="input" defaultValue={defaultValue ?? undefined}
        autoComplete={autoComplete} required={required} placeholder={placeholder} inputMode={inputMode}
        aria-invalid={error ? true : undefined} aria-describedby={error ? `${id}-err` : undefined}
      />
      {error && <p id={`${id}-err`} className="field-error">{error}</p>}
    </div>
  );
}

export function StateSelect({ error, defaultValue }: { error?: string; defaultValue?: string | null }) {
  return (
    <div>
      <label htmlFor="f-state" className="label">State<span className="text-red-700"> *</span></label>
      <select id="f-state" name="state" className="input" defaultValue={defaultValue ?? ""} required autoComplete="address-level1" aria-invalid={error ? true : undefined}>
        <option value="" disabled>Choose a state</option>
        {NIGERIAN_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
      </select>
      {error && <p className="field-error">{error}</p>}
    </div>
  );
}

export function AddressFields({ errors = {}, values = {} }: { errors?: Record<string, string>; values?: Record<string, string | null | undefined> }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <div className="sm:col-span-2"><Field name="fullName" label="Full name" autoComplete="name" required error={errors.fullName} defaultValue={values.fullName} /></div>
      <Field name="phone" label="Phone" type="tel" inputMode="tel" autoComplete="tel" required placeholder="0803 123 4567" error={errors.phone} defaultValue={values.phone} />
      <div className="sm:col-span-2"><Field name="line1" label="Street address" autoComplete="address-line1" required error={errors.line1} defaultValue={values.line1} /></div>
      <div className="sm:col-span-2"><Field name="line2" label="Apartment, landmark (optional)" autoComplete="address-line2" error={errors.line2} defaultValue={values.line2} /></div>
      <Field name="city" label="City / town" autoComplete="address-level2" required error={errors.city} defaultValue={values.city} />
      <StateSelect error={errors.state} defaultValue={values.state} />
    </div>
  );
}

export function FormMessage({ error, success }: { error?: string | null; success?: string | null }) {
  if (error) return <p role="alert" className="alert-error">{error}</p>;
  if (success) return <p role="status" className="alert-ok">{success}</p>;
  return null;
}
