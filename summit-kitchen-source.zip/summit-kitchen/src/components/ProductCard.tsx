import Link from "next/link";
import { formatMoney } from "@/lib/core/money";

export type CardProduct = {
  slug: string; name: string; priceKobo: number; compareAtKobo: number | null; currency: string;
  image: string | null; isSample: boolean; stock: number; category?: { name: string } | null;
};

export function Price({ priceKobo, compareAtKobo, currency, className = "" }: { priceKobo: number; compareAtKobo?: number | null; currency: string; className?: string }) {
  return (
    <span className={`inline-flex items-baseline gap-2 ${className}`}>
      <span className="font-semibold text-charcoal">{formatMoney(priceKobo, currency)}</span>
      {compareAtKobo && compareAtKobo > priceKobo ? (
        <s className="text-xs text-charcoal-400"><span className="sr-only">Was </span>{formatMoney(compareAtKobo, currency)}</s>
      ) : null}
    </span>
  );
}

export function ProductCard({ p }: { p: CardProduct }) {
  return (
    <Link href={`/product/${p.slug}`} className="group block">
      <div className="relative aspect-square overflow-hidden rounded-lg bg-ivory-200">
        {/* eslint-disable-next-line @next/next/no-img-element -- local SVG placeholders */}
        <img src={p.image ?? "/images/products/accessories.svg"} alt="" className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.03]" loading="lazy" />
        <div className="absolute left-2 top-2 flex flex-col gap-1">
          {p.isSample && <span className="badge-sample">Sample product</span>}
          {p.stock <= 0 && <span className="badge bg-charcoal text-white">Sold out</span>}
        </div>
      </div>
      <div className="mt-3 space-y-1">
        {p.category && <p className="text-[11px] uppercase tracking-wider text-charcoal-400">{p.category.name}</p>}
        <h3 className="font-sans text-sm font-medium leading-snug text-charcoal group-hover:text-olive">{p.name}</h3>
        <Price priceKobo={p.priceKobo} compareAtKobo={p.compareAtKobo} currency={p.currency} className="text-sm" />
      </div>
    </Link>
  );
}

export function ProductGrid({ products }: { products: CardProduct[] }) {
  return (
    <ul className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((p) => (
        <li key={p.slug}><ProductCard p={p} /></li>
      ))}
    </ul>
  );
}
