"use client";
import Link from "next/link";
import { useActionState } from "react";
import { addToCart, type CartState } from "@/app/(store)/cart/actions";
import { SubmitButton } from "./SubmitButton";

export function AddToCart({ productId, maxQty, disabled }: { productId: string; maxQty: number; disabled: boolean }) {
  const [state, action] = useActionState<CartState, FormData>(addToCart, null);
  if (disabled) return <button className="btn-outline w-full sm:w-auto" disabled>Sold out</button>;
  return (
    <form action={action} className="space-y-3">
      <input type="hidden" name="productId" value={productId} />
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <label htmlFor="qty" className="label">Quantity</label>
          <input id="qty" name="quantity" type="number" min={1} max={maxQty} defaultValue={1} className="input w-24" inputMode="numeric" />
        </div>
        <SubmitButton pendingText="Adding…" className="btn-gold flex-1 sm:flex-none">Add to cart</SubmitButton>
      </div>
      <div aria-live="polite">
        {state?.error && <p className="alert-error">{state.error}</p>}
        {state?.ok && (
          <p className="alert-ok">Added to your cart. <Link href="/cart" className="font-semibold underline">View cart</Link></p>
        )}
      </div>
    </form>
  );
}
