import Link from "next/link";
import { Logo } from "./Logo";
import { getCurrentUser } from "@/lib/server/session";
import { cartCount } from "@/lib/server/cart";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  { href: "/collections", label: "Collections" },
  { href: "/about", label: "About" },
];

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
      <circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" />
    </svg>
  );
}
function UserIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
      <circle cx="12" cy="8" r="4" /><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" />
    </svg>
  );
}
function BagIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
      <path d="M5 8h14l-1 12H6z" /><path d="M9 8V6a3 3 0 0 1 6 0v2" />
    </svg>
  );
}

export async function Header() {
  const [user, count] = await Promise.all([getCurrentUser(), cartCount()]);
  return (
    <header className="sticky top-0 z-40 border-b border-taupe-300 bg-ivory/95 backdrop-blur">
      <div className="container-site flex h-16 items-center justify-between gap-4 sm:h-20">
        {/* Mobile menu — works without JavaScript */}
        <details className="group relative md:hidden">
          <summary className="flex h-11 w-11 cursor-pointer list-none items-center justify-center rounded-md hover:bg-taupe-300/40" aria-label="Open menu">
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
              <path d="M4 7h16M4 12h16M4 17h16" />
            </svg>
          </summary>
          <nav className="absolute left-0 top-12 w-64 rounded-lg border border-taupe-300 bg-white p-2 shadow-lg" aria-label="Mobile">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className="block rounded px-3 py-3 text-sm hover:bg-ivory">{n.label}</Link>
            ))}
            <form action="/shop" className="p-2">
              <label htmlFor="m-q" className="sr-only">Search products</label>
              <input id="m-q" name="q" type="search" placeholder="Search products" className="input" />
            </form>
          </nav>
        </details>

        <Link href="/" aria-label="Summit Kitchen home" className="shrink-0">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Main">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} className="text-sm font-medium text-charcoal hover:text-olive">{n.label}</Link>
          ))}
        </nav>

        <div className="flex items-center gap-1">
          <form action="/shop" className="hidden lg:block" role="search">
            <label htmlFor="q" className="sr-only">Search products</label>
            <input id="q" name="q" type="search" placeholder="Search" className="input h-10 min-h-0 w-44" />
          </form>
          <Link href="/shop" className="flex h-11 w-11 items-center justify-center rounded-md hover:bg-taupe-300/40 lg:hidden" aria-label="Search">
            <SearchIcon />
          </Link>
          <Link
            href={user ? (user.role === "CUSTOMER" ? "/account" : "/admin") : "/account/login"}
            className="flex h-11 w-11 items-center justify-center rounded-md hover:bg-taupe-300/40"
            aria-label={user ? "Your account" : "Sign in"}
          >
            <UserIcon />
          </Link>
          <Link href="/cart" className="relative flex h-11 w-11 items-center justify-center rounded-md hover:bg-taupe-300/40" aria-label={`Cart, ${count} items`}>
            <BagIcon />
            {count > 0 && (
              <span className="absolute right-1 top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1 text-[10px] font-bold text-white">
                {count > 99 ? "99+" : count}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
