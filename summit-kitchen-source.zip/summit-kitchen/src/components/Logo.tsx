// Recreated from the brand board as a placeholder until the original logo
// files (SVG/high-res PNG) are supplied. Mountain mark: three peaks.

type Tone = "colour" | "mono" | "light";

export function MountainMark({ className = "h-8 w-auto", tone = "colour" }: { className?: string; tone?: Tone }) {
  const front = tone === "light" ? "#C9A96A" : tone === "mono" ? "#2C2C2C" : "#C9A96A";
  const back = tone === "light" ? "#FAF8F2" : "#2C2C2C";
  return (
    <svg viewBox="0 0 120 52" className={className} aria-hidden="true" fill="none">
      <path d="M4 48 L40 14 L56 30" stroke={back} strokeWidth="3.2" strokeLinejoin="round" strokeLinecap="round" />
      <path d="M30 48 L60 4 L90 48" stroke={front} strokeWidth="3.6" strokeLinejoin="round" strokeLinecap="round" />
      <path d="M68 24 L80 14 L116 48" stroke={back} strokeWidth="3.2" strokeLinejoin="round" strokeLinecap="round" />
      <path d="M50 18 L60 4 L70 18 L64 15 L60 20 L56 15 Z" fill={front} opacity="0.35" />
    </svg>
  );
}

export function Logo({ tone = "colour", stacked = true, className = "" }: { tone?: Tone; stacked?: boolean; className?: string }) {
  const word = tone === "light" ? "text-ivory" : "text-charcoal";
  const sub = tone === "mono" ? "text-charcoal" : "text-gold";
  if (!stacked) {
    return (
      <span className={`inline-flex items-center gap-3 ${className}`}>
        <MountainMark className="h-7 w-auto" tone={tone} />
        <span className={`font-serif text-xl tracking-[0.18em] ${word}`}>SUMMIT KITCHEN</span>
      </span>
    );
  }
  return (
    <span className={`inline-flex flex-col items-center leading-none ${className}`}>
      <MountainMark className="h-6 w-auto sm:h-7" tone={tone} />
      <span className={`mt-1 font-serif text-xl tracking-[0.14em] sm:text-2xl ${word}`}>SUMMIT</span>
      <span className={`mt-0.5 text-[9px] font-medium tracking-brand ${sub}`}>KITCHEN</span>
    </span>
  );
}
