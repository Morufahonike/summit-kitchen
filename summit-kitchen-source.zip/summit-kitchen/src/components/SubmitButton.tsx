"use client";
import { useFormStatus } from "react-dom";

export function SubmitButton({
  children, className = "btn-gold", pendingText = "Please wait…", disabled = false,
}: { children: React.ReactNode; className?: string; pendingText?: string; disabled?: boolean }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className={className} disabled={pending || disabled} aria-disabled={pending || disabled}>
      {pending ? pendingText : children}
    </button>
  );
}
