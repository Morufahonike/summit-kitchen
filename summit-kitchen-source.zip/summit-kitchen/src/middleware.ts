import { NextResponse, type NextRequest } from "next/server";

// Defence in depth only: cheaply bounce requests to /admin that carry no session
// cookie. Real authorisation (valid session + STAFF/ADMIN role) is enforced on the
// server in the admin layout and inside every admin server action.
export function middleware(req: NextRequest) {
  if (!req.cookies.get("sk_session")) {
    const url = req.nextUrl.clone();
    url.pathname = "/account/login";
    url.search = "?next=/admin";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/admin/:path*"] };
