import "server-only";
import { prisma } from "./db.ts";
import { env } from "./env.ts";
import { PaystackClient, assertPaymentsAllowed, evaluateVerification } from "../core/paystack.ts";
import { paymentReference } from "../core/crypto.ts";
import { reserveStock, OutOfStockError } from "./inventory.ts";
import { logActivity } from "./audit.ts";

function client(): { client: PaystackClient; mode: "test" | "live" } {
  const mode = assertPaymentsAllowed(env.paystackSecret, env.paystackAllowLive);
  if (mode === "invalid") throw new Error("unreachable");
  return { client: new PaystackClient(env.paystackSecret!), mode };
}

export function paymentsConfigured(): { ok: boolean; mode: "test" | "live" | null; reason?: string } {
  try {
    return { ok: true, mode: client().mode };
  } catch (e) {
    return { ok: false, mode: null, reason: (e as Error).message };
  }
}

/** Start (or restart) a Paystack payment for a pending order. Returns the hosted checkout URL. */
export async function startPayment(orderId: string, accessToken: string): Promise<{ ok: true; url: string } | { ok: false; error: string }> {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order || order.status !== "PENDING_PAYMENT") return { ok: false, error: "This order can no longer be paid." };
  if (order.reservationExpiresAt && order.reservationExpiresAt < new Date()) return { ok: false, error: "The payment window has expired." };

  let paystack: PaystackClient, mode: "test" | "live";
  try {
    ({ client: paystack, mode } = client());
  } catch {
    return { ok: false, error: "Online payment is not configured yet. Your order is saved; please contact us." };
  }

  const reference = paymentReference(order.reference);
  await prisma.payment.create({
    data: { orderId: order.id, reference, amountKobo: order.totalKobo, currency: order.currency, mode, status: "INITIALIZED" },
  });
  try {
    const init = await paystack.initialize({
      email: order.email,
      amountKobo: order.totalKobo,
      currency: order.currency,
      reference,
      callbackUrl: `${env.appUrl}/checkout/callback?order=${encodeURIComponent(order.reference)}&t=${encodeURIComponent(accessToken)}`,
      metadata: { order_reference: order.reference },
    });
    if (!init.authorization_url.startsWith("https://checkout.paystack.com/")) throw new Error("Unexpected checkout URL");
    return { ok: true, url: init.authorization_url };
  } catch (e) {
    await prisma.payment.update({ where: { reference }, data: { status: "FAILED", gatewayResponse: "Initialization failed" } });
    console.error("[paystack] initialize failed:", (e as Error).message);
    return { ok: false, error: "We couldn't reach the payment provider. Please try again shortly." };
  }
}

export type ConfirmResult = "paid" | "already_paid" | "pending" | "failed" | "unknown_reference" | "needs_review";

/**
 * Idempotent payment confirmation used by BOTH the browser callback and the
 * webhook. It always re-verifies with Paystack's API and checks reference,
 * amount and currency against our own records before changing anything.
 */
export async function confirmPayment(reference: string, source: "callback" | "webhook"): Promise<ConfirmResult> {
  const payment = await prisma.payment.findUnique({ where: { reference }, include: { order: true } });
  if (!payment) return "unknown_reference";
  if (payment.status === "SUCCESS") return "already_paid";

  const { client: paystack } = client();
  const data = await paystack.verify(reference);
  const outcome = evaluateVerification(data, {
    reference: payment.reference,
    amountKobo: payment.amountKobo,
    currency: payment.currency,
  });

  if (!outcome.ok) {
    if (outcome.final) {
      await prisma.payment.updateMany({
        where: { id: payment.id, status: "INITIALIZED" },
        data: { status: "FAILED", gatewayResponse: outcome.gatewayResponse ?? outcome.reason },
      });
      if (/mismatch/i.test(outcome.reason)) {
        await logActivity({ action: "payment.mismatch", entityType: "Payment", entityId: payment.id, details: { reason: outcome.reason, source } });
      }
      return "failed";
    }
    return "pending";
  }

  return prisma.$transaction(async (tx) => {
    // Guarded update: only one of callback/webhook can win this transition.
    const won = await tx.payment.updateMany({
      where: { id: payment.id, status: { not: "SUCCESS" } },
      data: {
        status: "SUCCESS", channel: outcome.channel, cardBrand: outcome.cardBrand, cardLast4: outcome.last4,
        gatewayResponse: outcome.gatewayResponse, paidAt: outcome.paidAt ?? new Date(),
      },
    });
    if (won.count !== 1) return "already_paid" as const;

    const flip = await tx.order.updateMany({ where: { id: payment.orderId, status: "PENDING_PAYMENT" }, data: { status: "PAID" } });
    if (flip.count === 1) {
      await tx.orderStatusEvent.create({ data: { orderId: payment.orderId, status: "PAID", note: `Payment verified (${source})` } });
      await logActivity({ action: "payment.success", entityType: "Order", entityId: payment.orderId, details: { reference, source } }, tx);
      return "paid" as const;
    }

    // Money arrived but the order had already expired/been cancelled.
    // Try to re-reserve stock; otherwise flag for manual refund. Never lose a payment silently.
    const order = await tx.order.findUniqueOrThrow({ where: { id: payment.orderId }, include: { items: true } });
    if (order.status === "EXPIRED") {
      const taken: { productId: string; qty: number }[] = [];
      try {
        for (const i of order.items) {
          if (!i.productId) continue;
          await reserveStock(tx, i.productId, i.nameSnapshot, i.quantity, order.id);
          taken.push({ productId: i.productId, qty: i.quantity });
        }
        await tx.order.update({ where: { id: order.id }, data: { status: "PAID" } });
        await tx.orderStatusEvent.create({ data: { orderId: order.id, status: "PAID", note: "Paid after reservation expired; stock re-reserved" } });
        return "paid" as const;
      } catch (e) {
        if (!(e instanceof OutOfStockError)) throw e;
        // Undo any partial re-reservation so inventory stays exact.
        for (const t of taken) {
          await tx.product.update({ where: { id: t.productId }, data: { stock: { increment: t.qty } } });
          await tx.inventoryMovement.create({ data: { productId: t.productId, delta: t.qty, reason: "ORDER_RELEASED", orderId: order.id, note: "Re-reservation rolled back" } });
        }
      }
    }
    await logActivity({
      action: "payment.needs_review", entityType: "Order", entityId: order.id,
      details: { reference, orderStatus: order.status, reason: "Payment succeeded for an order that cannot be fulfilled — refund or fulfil manually" },
    }, tx);
    return "needs_review" as const;
  });
}
