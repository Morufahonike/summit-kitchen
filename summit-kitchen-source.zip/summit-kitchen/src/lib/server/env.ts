import "server-only";

// Central, validated access to environment variables. Secrets are read only on
// the server; nothing here is ever sent to the browser.

export const env = {
  get appUrl(): string {
    return (process.env.APP_URL ?? "http://localhost:3000").replace(/\/+$/, "");
  },
  get paystackSecret(): string | undefined {
    return process.env.PAYSTACK_SECRET_KEY || undefined;
  },
  get paystackAllowLive(): string | undefined {
    return process.env.PAYSTACK_ALLOW_LIVE;
  },
  get currency(): "NGN" | "USD" {
    return process.env.STORE_CURRENCY === "USD" ? "USD" : "NGN";
  },
  get reservationMinutes(): number {
    const n = Number(process.env.RESERVATION_MINUTES ?? 30);
    return Number.isInteger(n) && n >= 5 && n <= 24 * 60 ? n : 30;
  },
  get cronSecret(): string | undefined {
    return process.env.CRON_SECRET || undefined;
  },
  get isProduction(): boolean {
    return process.env.NODE_ENV === "production";
  },
};
