import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "./db.ts";

type Tx = Prisma.TransactionClient;

export class OutOfStockError extends Error {
  override name = "OutOfStockError";
  readonly productName: string;
  constructor(productName: string) {
    super(`${productName} does not have enough stock.`);
    this.productName = productName;
  }
}

/**
 * Atomically take stock. The conditional UPDATE (stock >= qty) is re-evaluated
 * by PostgreSQL after it acquires the row lock, so concurrent checkouts can
 * never oversell. Verified by tests/db/run.sh ("concurrent reservations never oversell").
 */
export async function reserveStock(tx: Tx, productId: string, name: string, qty: number, orderId: string): Promise<void> {
  const res = await tx.product.updateMany({
    where: { id: productId, isActive: true, stock: { gte: qty } },
    data: { stock: { decrement: qty } },
  });
  if (res.count !== 1) throw new OutOfStockError(name);
  await tx.inventoryMovement.create({ data: { productId, delta: -qty, reason: "ORDER_RESERVED", orderId } });
}

export async function returnStock(tx: Tx, orderId: string, note: string): Promise<void> {
  const items = await tx.orderItem.findMany({ where: { orderId, productId: { not: null } } });
  for (const item of items) {
    await tx.product.update({ where: { id: item.productId! }, data: { stock: { increment: item.quantity } } });
    await tx.inventoryMovement.create({
      data: { productId: item.productId!, delta: item.quantity, reason: "ORDER_RELEASED", orderId, note },
    });
  }
}

/** Admin stock adjustment with an audit trail. Never allows negative stock. */
export async function adjustStock(productId: string, delta: number, actorId: string, note: string): Promise<{ ok: boolean; error?: string }> {
  if (!Number.isInteger(delta) || delta === 0 || Math.abs(delta) > 100_000) return { ok: false, error: "Invalid adjustment." };
  return prisma.$transaction(async (tx) => {
    const res = await tx.product.updateMany({
      where: { id: productId, ...(delta < 0 ? { stock: { gte: -delta } } : {}) },
      data: { stock: { increment: delta } },
    });
    if (res.count !== 1) return { ok: false, error: "Stock cannot go below zero." };
    await tx.inventoryMovement.create({
      data: { productId, delta, reason: delta > 0 ? "RESTOCK" : "ADMIN_ADJUST", actorId, note: note.slice(0, 200) || null },
    });
    return { ok: true };
  });
}

/**
 * Expire unpaid orders whose reservation window has passed and return their
 * stock. Each order flips status with a guarded update so a payment confirmed
 * at the same moment wins cleanly (see payments.ts for paid-after-expiry).
 */
export async function releaseExpiredReservations(now = new Date()): Promise<number> {
  const expired = await prisma.order.findMany({
    where: { status: "PENDING_PAYMENT", reservationExpiresAt: { lt: now } },
    select: { id: true },
    take: 200,
  });
  let released = 0;
  for (const { id } of expired) {
    await prisma.$transaction(async (tx) => {
      const flip = await tx.order.updateMany({ where: { id, status: "PENDING_PAYMENT" }, data: { status: "EXPIRED" } });
      if (flip.count !== 1) return;
      await returnStock(tx, id, "Payment window expired");
      await tx.orderStatusEvent.create({ data: { orderId: id, status: "EXPIRED", note: "Payment not completed in time" } });
      await tx.payment.updateMany({ where: { orderId: id, status: "INITIALIZED" }, data: { status: "ABANDONED" } });
      released++;
    });
  }
  return released;
}
