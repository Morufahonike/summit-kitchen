import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "./db.ts";
import { PAGE_SIZE, type CatalogueFilter } from "../core/catalogue.ts";

const cardSelect = {
  id: true, slug: true, name: true, priceKobo: true, compareAtKobo: true, currency: true,
  image: true, isSample: true, stock: true, category: { select: { name: true, slug: true } },
} satisfies Prisma.ProductSelect;

export async function listCategories() {
  return prisma.category.findMany({
    where: { isActive: true },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    include: { _count: { select: { products: { where: { isActive: true } } } } },
  });
}

export async function searchProducts(f: CatalogueFilter) {
  const where: Prisma.ProductWhereInput = { isActive: true, category: { isActive: true } };
  if (f.category) where.category = { slug: f.category, isActive: true };
  if (f.q) {
    where.OR = [
      { name: { contains: f.q, mode: "insensitive" } },
      { description: { contains: f.q, mode: "insensitive" } },
      { sku: { equals: f.q, mode: "insensitive" } },
      { material: { contains: f.q, mode: "insensitive" } },
    ];
  }
  if (f.minKobo !== null || f.maxKobo !== null) {
    where.priceKobo = { ...(f.minKobo !== null && { gte: f.minKobo }), ...(f.maxKobo !== null && { lte: f.maxKobo }) };
  }
  if (f.inStock) where.stock = { gt: 0 };

  const orderBy: Prisma.ProductOrderByWithRelationInput[] =
    f.sort === "price-asc" ? [{ priceKobo: "asc" }]
    : f.sort === "price-desc" ? [{ priceKobo: "desc" }]
    : f.sort === "newest" ? [{ createdAt: "desc" }]
    : f.sort === "name" ? [{ name: "asc" }]
    : [{ isFeatured: "desc" }, { isBestseller: "desc" }, { name: "asc" }];

  const [total, products] = await prisma.$transaction([
    prisma.product.count({ where }),
    prisma.product.findMany({ where, orderBy: [...orderBy, { id: "asc" }], select: cardSelect, take: PAGE_SIZE, skip: (f.page - 1) * PAGE_SIZE }),
  ]);
  return { total, products, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)) };
}

export async function homepageProducts() {
  const [featured, bestsellers] = await Promise.all([
    prisma.product.findMany({ where: { isActive: true, isFeatured: true }, select: cardSelect, take: 8, orderBy: { name: "asc" } }),
    prisma.product.findMany({ where: { isActive: true, isBestseller: true }, select: cardSelect, take: 4, orderBy: { name: "asc" } }),
  ]);
  return { featured, bestsellers };
}

export async function getProduct(slug: string) {
  if (!/^[a-z0-9-]{1,80}$/.test(slug)) return null;
  return prisma.product.findFirst({ where: { slug, isActive: true }, include: { category: true } });
}

export async function relatedProducts(categoryId: string, excludeId: string) {
  return prisma.product.findMany({ where: { categoryId, isActive: true, id: { not: excludeId } }, select: cardSelect, take: 4 });
}
