import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "./db.ts";
import { clientIp } from "./request.ts";

type Tx = Prisma.TransactionClient;

/** Append-only activity log for admin and security-relevant events. Never log secrets or card data. */
export async function logActivity(
  entry: { actorId?: string | null; action: string; entityType: string; entityId?: string | null; details?: Prisma.InputJsonValue },
  tx: Tx = prisma,
): Promise<void> {
  let ip: string | null = null;
  try {
    ip = await clientIp();
  } catch {
    ip = null; // outside a request (e.g. webhook background work)
  }
  await tx.activityLog.create({
    data: {
      actorId: entry.actorId ?? null,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId ?? null,
      details: entry.details,
      ip,
    },
  });
}
