import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { Role } from "@prisma/client";
import { prisma } from "./db.ts";
import { env } from "./env.ts";
import { randomToken, sha256 } from "../core/crypto.ts";
import { clientIp, userAgent } from "./request.ts";

export const SESSION_COOKIE = "sk_session";
const SESSION_DAYS = 30;
const ADMIN_SESSION_HOURS = 12;

export type CurrentUser = { id: string; email: string; name: string; role: Role };

export async function createSession(userId: string, role: Role): Promise<void> {
  const token = randomToken(32);
  const hours = role === "CUSTOMER" ? SESSION_DAYS * 24 : ADMIN_SESSION_HOURS;
  const expiresAt = new Date(Date.now() + hours * 3600_000);
  await prisma.session.create({
    data: { id: sha256(token), userId, expiresAt, ip: await clientIp(), userAgent: await userAgent() },
  });
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: env.isProduction,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
}

/** Resolves the signed-in user for this request (memoised per request). */
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token || token.length > 100) return null;
  const session = await prisma.session.findUnique({
    where: { id: sha256(token) },
    include: { user: { select: { id: true, email: true, name: true, role: true, disabled: true } } },
  });
  if (!session || session.expiresAt < new Date() || session.user.disabled) return null;
  const { id, email, name, role } = session.user;
  return { id, email, name, role };
});

export async function destroySession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await prisma.session.deleteMany({ where: { id: sha256(token) } });
  jar.delete(SESSION_COOKIE);
}

/** Revoke every session for a user (after password change/reset or admin disable). */
export async function revokeAllSessions(userId: string): Promise<void> {
  await prisma.session.deleteMany({ where: { userId } });
}

export async function requireUser(next = "/account"): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect(`/account/login?next=${encodeURIComponent(next)}`);
  return user;
}

/** STAFF can operate orders/stock; ADMIN additionally manages users, payments config and deletes. */
export async function requireStaff(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/account/login?next=/admin");
  if (user.role !== "ADMIN" && user.role !== "STAFF") redirect("/");
  return user;
}

export async function requireAdmin(): Promise<CurrentUser> {
  const user = await requireStaff();
  if (user.role !== "ADMIN") redirect("/admin?denied=1");
  return user;
}
