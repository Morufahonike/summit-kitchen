import "server-only";
import { prisma } from "./db.ts";
import { env } from "./env.ts";
import { getCartId, getCartLines, clearCart } from "./cart.ts";
import { reserveStock, OutOfStockError, releaseExpiredReservations } from "./inventory.ts";
import { computeTotals, type Zone } from "../core/pricing.ts";
import { orderReference, randomToken, sha256 } from "../core/crypto.ts";
import type { CheckoutInput } from "../core/validation.ts";
import { logActivity } from "./audit.ts";

export async function activeZones(): Promise<Zone[]> {
  return prisma.deliveryZone.findMany({
    where: { isActive: true },
    select: { id: true, name: true, states: true, feeKobo: true, isActive: true },
  });
}

export type PlaceOrderResult =
  | { ok: true; orderId: string; reference: string; accessToken: string }
  | { ok: false; error: string };

/**
 * Creates an order from the server-side cart. All prices, totals and delivery
 * fees are recomputed here; nothing from the client is trusted except the
 * validated address/contact fields. Stock is reserved in the same transaction.
 */
export async function placeOrder(input: CheckoutInput, userId: string | null): Promise<PlaceOrderResult> {
  await releaseExpiredReservations(); // free stock held by abandoned checkouts first

  const cartId = await getCartId(false);
  const lines = await getCartLines();
  if (!cartId || lines.length === 0) return { ok: false, error: "Your cart is empty." };

  const totals = computeTotals(lines, await activeZones(), input.state);
  if (totals.problems.length) return { ok: false, error: totals.problems.map((p) => `${p.name}: ${p.problem}`).join(" ") };
  if (totals.deliveryKobo === null || totals.totalKobo === null || !totals.zone) {
    return { ok: false, error: `Delivery to ${input.state} is not available yet. Please contact us.` };
  }
  const currencies = new Set(lines.map((l) => l.currency));
  if (currencies.size !== 1 || !currencies.has(env.currency)) {
    return { ok: false, error: "Cart contains items in an unsupported currency." };
  }

  const accessToken = randomToken(24);
  const reference = orderReference();
  const expires = new Date(Date.now() + env.reservationMinutes * 60_000);
  const { zone, deliveryKobo, totalKobo, subtotalKobo } = totals;

  try {
    const order = await prisma.$transaction(async (tx) => {
      const created = await tx.order.create({
        data: {
          reference,
          accessTokenHash: sha256(accessToken),
          userId,
          email: input.email,
          phone: input.phone,
          shippingName: input.fullName,
          line1: input.line1,
          line2: input.line2,
          city: input.city,
          state: input.state,
          deliveryZoneId: zone.id,
          subtotalKobo,
          deliveryKobo,
          totalKobo,
          currency: env.currency,
          reservationExpiresAt: expires,
          customerNote: input.note,
          items: {
            create: totals.lines.map((l) => ({
              productId: l.productId,
              nameSnapshot: l.name,
              skuSnapshot: l.sku,
              unitPriceKobo: l.unitPriceKobo,
              quantity: l.quantity,
              lineTotalKobo: l.lineTotalKobo,
            })),
          },
          events: { create: { status: "PENDING_PAYMENT", note: "Order placed" } },
        },
      });
      for (const l of totals.lines) await reserveStock(tx, l.productId, l.name, l.quantity, created.id);
      return created;
    }, { isolationLevel: "ReadCommitted", timeout: 15_000 });

    await clearCart(cartId);
    await logActivity({ actorId: userId, action: "order.placed", entityType: "Order", entityId: order.id, details: { reference, totalKobo } });
    return { ok: true, orderId: order.id, reference, accessToken };
  } catch (e) {
    if (e instanceof OutOfStockError) return { ok: false, error: `${e.productName} just sold out. Please review your cart.` };
    throw e;
  }
}

export { canViewOrder } from "../core/access.ts";
