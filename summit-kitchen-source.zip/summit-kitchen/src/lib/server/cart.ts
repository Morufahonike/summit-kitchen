import "server-only";
import { cookies } from "next/headers";
import { prisma } from "./db.ts";
import { env } from "./env.ts";
import { randomToken, sha256 } from "../core/crypto.ts";
import { MAX_LINES, MAX_QTY_PER_LINE, type PricedLine } from "../core/pricing.ts";

// The cart lives server-side; the browser only holds an opaque random token.
// Prices are never stored in the cart — they are read fresh from Product.

const CART_COOKIE = "sk_cart";

async function cartToken(create: boolean): Promise<string | null> {
  const jar = await cookies();
  const existing = jar.get(CART_COOKIE)?.value;
  if (existing && existing.length <= 100) return existing;
  if (!create) return null;
  const token = randomToken(24);
  jar.set(CART_COOKIE, token, {
    httpOnly: true, secure: env.isProduction, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 30,
  });
  return token;
}

export async function getCartId(create = false): Promise<string | null> {
  const token = await cartToken(create);
  if (!token) return null;
  const tokenHash = sha256(token);
  if (!create) return (await prisma.cart.findUnique({ where: { tokenHash }, select: { id: true } }))?.id ?? null;
  const cart = await prisma.cart.upsert({ where: { tokenHash }, update: {}, create: { tokenHash }, select: { id: true } });
  return cart.id;
}

export type CartLine = PricedLine & { slug: string; image: string | null; isSample: boolean; currency: string };

export async function getCartLines(): Promise<CartLine[]> {
  const cartId = await getCartId(false);
  if (!cartId) return [];
  const items = await prisma.cartItem.findMany({
    where: { cartId },
    include: { product: true },
    orderBy: { id: "asc" },
  });
  return items.map((i) => ({
    productId: i.productId,
    name: i.product.name,
    sku: i.product.sku,
    slug: i.product.slug,
    image: i.product.image,
    isSample: i.product.isSample,
    currency: i.product.currency,
    unitPriceKobo: i.product.priceKobo,
    quantity: i.quantity,
    stock: i.product.stock,
    isActive: i.product.isActive,
  }));
}

export async function cartCount(): Promise<number> {
  const cartId = await getCartId(false);
  if (!cartId) return 0;
  const agg = await prisma.cartItem.aggregate({ where: { cartId }, _sum: { quantity: true } });
  return agg._sum.quantity ?? 0;
}

export type CartMutation = { ok: true } | { ok: false; error: string };

export async function setCartQuantity(productId: string, quantity: number, mode: "add" | "set"): Promise<CartMutation> {
  if (!/^[a-z0-9]{10,40}$/i.test(productId)) return { ok: false, error: "Unknown product." };
  if (!Number.isInteger(quantity) || quantity < 0 || quantity > MAX_QTY_PER_LINE) {
    return { ok: false, error: `Choose a quantity between 1 and ${MAX_QTY_PER_LINE}.` };
  }
  const product = await prisma.product.findUnique({ where: { id: productId }, select: { id: true, stock: true, isActive: true } });
  if (!product || !product.isActive) return { ok: false, error: "This product is not available." };

  const cartId = (await getCartId(true))!;
  const existing = await prisma.cartItem.findUnique({ where: { cartId_productId: { cartId, productId } } });
  const target = mode === "add" ? (existing?.quantity ?? 0) + quantity : quantity;

  if (target <= 0) {
    await prisma.cartItem.deleteMany({ where: { cartId, productId } });
    return { ok: true };
  }
  if (target > MAX_QTY_PER_LINE) return { ok: false, error: `You can order up to ${MAX_QTY_PER_LINE} of each item.` };
  if (target > product.stock) {
    return { ok: false, error: product.stock <= 0 ? "Sorry, this item is out of stock." : `Only ${product.stock} available.` };
  }
  if (!existing) {
    const lines = await prisma.cartItem.count({ where: { cartId } });
    if (lines >= MAX_LINES) return { ok: false, error: "Your cart is full." };
  }
  await prisma.cartItem.upsert({
    where: { cartId_productId: { cartId, productId } },
    update: { quantity: target },
    create: { cartId, productId, quantity: target },
  });
  return { ok: true };
}

export async function clearCart(cartId: string): Promise<void> {
  await prisma.cartItem.deleteMany({ where: { cartId } });
}

/** Attach the current cart to a user on sign-in so it follows them. */
export async function attachCartToUser(userId: string): Promise<void> {
  const cartId = await getCartId(false);
  if (cartId) await prisma.cart.update({ where: { id: cartId }, data: { userId } });
}
