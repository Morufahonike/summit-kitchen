import "server-only";
import { prisma } from "./db.ts";
import { LIMITS, type LimitName } from "../core/ratelimit.ts";

/**
 * Atomic fixed-window counter in a single SQL statement (safe under concurrency;
 * the same statement is exercised in tests/db/run.sh).
 * Returns true when the action is allowed.
 */
export async function rateLimit(name: LimitName, subject: string): Promise<boolean> {
  const { limit, windowSec } = LIMITS[name];
  const key = `${name}:${subject}`.slice(0, 200);
  const rows = await prisma.$queryRaw<{ count: number }[]>`
    INSERT INTO "RateLimit"("key","count","windowStart") VALUES (${key}, 1, now())
    ON CONFLICT ("key") DO UPDATE SET
      "count" = CASE WHEN "RateLimit"."windowStart" < now() - (${windowSec}::int * interval '1 second')
                     THEN 1 ELSE "RateLimit"."count" + 1 END,
      "windowStart" = CASE WHEN "RateLimit"."windowStart" < now() - (${windowSec}::int * interval '1 second')
                     THEN now() ELSE "RateLimit"."windowStart" END
    RETURNING "count"`;
  return (rows[0]?.count ?? 0) <= limit;
}
