import "server-only";
import { env } from "./env.ts";

// No email provider is connected yet (outstanding launch requirement).
// In development the message is logged so flows can be tested locally.
// In production nothing is sent and a warning is logged — links are NEVER
// logged in production because they are credentials.

export type Mail = { to: string; subject: string; text: string };

export async function sendMail(mail: Mail): Promise<{ delivered: boolean }> {
  if (!env.isProduction) {
    console.info(`[mail:dev] to=${mail.to} subject="${mail.subject}"\n${mail.text}`);
    return { delivered: false };
  }
  console.warn(`[mail] No email provider configured; message "${mail.subject}" was not sent.`);
  return { delivered: false };
}
