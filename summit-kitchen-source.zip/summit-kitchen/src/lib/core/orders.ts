// Order status rules shared by checkout, payments and the admin dashboard.

export const ORDER_STATUSES = [
  "PENDING_PAYMENT", "PAID", "PROCESSING", "SHIPPED", "DELIVERED",
  "CANCELLED", "PAYMENT_FAILED", "EXPIRED", "REFUNDED",
] as const;
export type OrderStatusName = (typeof ORDER_STATUSES)[number];

/** Transitions an admin may make manually. Payment-driven ones happen in code. */
const ADMIN_TRANSITIONS: Record<OrderStatusName, OrderStatusName[]> = {
  PENDING_PAYMENT: ["CANCELLED"],
  PAID: ["PROCESSING", "CANCELLED", "REFUNDED"],
  PROCESSING: ["SHIPPED", "CANCELLED", "REFUNDED"],
  SHIPPED: ["DELIVERED"],
  DELIVERED: ["REFUNDED"],
  CANCELLED: [],
  PAYMENT_FAILED: ["CANCELLED"],
  EXPIRED: [],
  REFUNDED: [],
};

export function adminCanTransition(from: OrderStatusName, to: OrderStatusName): boolean {
  return ADMIN_TRANSITIONS[from].includes(to);
}

export function adminNextStatuses(from: OrderStatusName): OrderStatusName[] {
  return ADMIN_TRANSITIONS[from];
}

/** Statuses where reserved stock must be returned to inventory. */
export function releasesStock(from: OrderStatusName, to: OrderStatusName): boolean {
  const holding: OrderStatusName[] = ["PENDING_PAYMENT", "PAID", "PROCESSING", "PAYMENT_FAILED"];
  return holding.includes(from) && (to === "CANCELLED" || to === "EXPIRED");
}

export function isOrderStatus(v: string): v is OrderStatusName {
  return (ORDER_STATUSES as readonly string[]).includes(v);
}

export const STATUS_LABEL: Record<OrderStatusName, string> = {
  PENDING_PAYMENT: "Awaiting payment",
  PAID: "Paid",
  PROCESSING: "Processing",
  SHIPPED: "Shipped",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
  PAYMENT_FAILED: "Payment failed",
  EXPIRED: "Expired",
  REFUNDED: "Refunded",
};

/** Customer-facing tracking steps. */
export function trackingSteps(status: OrderStatusName): { label: string; done: boolean }[] {
  const order: OrderStatusName[] = ["PAID", "PROCESSING", "SHIPPED", "DELIVERED"];
  const idx = order.indexOf(status);
  return [
    { label: "Order placed", done: true },
    { label: "Payment confirmed", done: idx >= 0 },
    { label: "Being prepared", done: idx >= 1 },
    { label: "On its way", done: idx >= 2 },
    { label: "Delivered", done: idx >= 3 },
  ];
}
