import { safeEqualHex, sha256 } from "./crypto.ts";

/**
 * Authorise viewing an order: staff, the signed-in owner, or anyone holding the
 * secret link token issued at checkout. An order reference alone is NOT enough.
 */
export function canViewOrder(
  order: { userId: string | null; accessTokenHash: string },
  viewer: { id: string; role: string } | null,
  token: string | null | undefined,
): boolean {
  if (viewer && (viewer.role === "ADMIN" || viewer.role === "STAFF")) return true;
  if (viewer && order.userId && viewer.id === order.userId) return true;
  if (token && token.length <= 100 && safeEqualHex(sha256(token), order.accessTokenHash)) return true;
  return false;
}
