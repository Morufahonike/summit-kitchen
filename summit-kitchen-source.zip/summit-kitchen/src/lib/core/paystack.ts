import { createHmac, timingSafeEqual } from "node:crypto";

// Paystack integration — pure logic, no framework dependencies.
// Docs: https://paystack.com/docs/payments/accept-payments ,
//       https://paystack.com/docs/payments/webhooks

export const PAYSTACK_API = "https://api.paystack.co";

export type KeyMode = "test" | "live" | "invalid";

export function keyMode(secretKey: string | undefined | null): KeyMode {
  if (!secretKey) return "invalid";
  if (/^sk_test_[A-Za-z0-9]+$/.test(secretKey)) return "test";
  if (/^sk_live_[A-Za-z0-9]+$/.test(secretKey)) return "live";
  return "invalid";
}

/**
 * Live payments require BOTH a live key and an explicit opt-in flag set after the
 * business owner approves. Anything else throws, so a misconfigured live key can
 * never silently take real money.
 */
export function assertPaymentsAllowed(secretKey: string | undefined, allowLiveFlag: string | undefined): KeyMode {
  const mode = keyMode(secretKey);
  if (mode === "invalid") throw new PaymentConfigError("Paystack secret key is missing or malformed.");
  if (mode === "live" && allowLiveFlag !== "true") {
    throw new PaymentConfigError("Live Paystack key detected but live payments have not been approved (PAYSTACK_ALLOW_LIVE).");
  }
  return mode;
}

export class PaymentConfigError extends Error {
  override name = "PaymentConfigError";
}

/** HMAC-SHA512 of the RAW request body with the secret key, hex, constant-time compared. */
export function verifyWebhookSignature(rawBody: string | Buffer, signature: string | null | undefined, secretKey: string): boolean {
  if (!signature || !secretKey || !/^[0-9a-f]{128}$/i.test(signature)) return false;
  const expected = createHmac("sha512", secretKey).update(rawBody).digest();
  const given = Buffer.from(signature, "hex");
  return given.length === expected.length && timingSafeEqual(given, expected);
}

// ---- Verification evaluation -----------------------------------------------

export type VerifyData = {
  status?: string; // "success" | "failed" | "abandoned" | ...
  reference?: string;
  amount?: number; // minor units
  currency?: string;
  channel?: string;
  gateway_response?: string;
  paid_at?: string | null;
  authorization?: { card_type?: string; last4?: string; brand?: string } | null;
};

export type VerifyOutcome =
  | { ok: true; channel: string | null; cardBrand: string | null; last4: string | null; paidAt: Date | null; gatewayResponse: string | null }
  | { ok: false; final: boolean; reason: string; gatewayResponse: string | null };

/**
 * Decide whether a Paystack verify response proves the expected payment.
 * Amount, currency AND reference must all match exactly.
 */
export function evaluateVerification(
  data: VerifyData | null | undefined,
  expected: { reference: string; amountKobo: number; currency: string },
): VerifyOutcome {
  const gatewayResponse = typeof data?.gateway_response === "string" ? data.gateway_response.slice(0, 200) : null;
  if (!data) return { ok: false, final: false, reason: "No data from gateway", gatewayResponse };
  if (data.reference !== expected.reference) return { ok: false, final: true, reason: "Reference mismatch", gatewayResponse };
  if (data.status !== "success") {
    const final = data.status === "failed" || data.status === "abandoned" || data.status === "reversed";
    return { ok: false, final, reason: `Status: ${data.status ?? "unknown"}`, gatewayResponse };
  }
  if (data.amount !== expected.amountKobo) return { ok: false, final: true, reason: "Amount mismatch", gatewayResponse };
  if ((data.currency ?? "").toUpperCase() !== expected.currency.toUpperCase())
    return { ok: false, final: true, reason: "Currency mismatch", gatewayResponse };
  const auth = data.authorization ?? null;
  const last4 = auth?.last4 && /^\d{4}$/.test(auth.last4) ? auth.last4 : null;
  const brand = (auth?.brand || auth?.card_type || "").trim().slice(0, 30) || null;
  const paidAt = data.paid_at ? new Date(data.paid_at) : null;
  return {
    ok: true,
    channel: data.channel?.slice(0, 30) ?? null,
    cardBrand: brand,
    last4,
    paidAt: paidAt && !Number.isNaN(paidAt.getTime()) ? paidAt : null,
    gatewayResponse,
  };
}

// ---- HTTP client (fetch injected so it can be tested offline) ---------------

type FetchLike = (url: string, init: { method: string; headers: Record<string, string>; body?: string; signal?: AbortSignal }) => Promise<{ ok: boolean; status: number; json(): Promise<unknown> }>;

export type InitializeArgs = {
  email: string;
  amountKobo: number;
  currency: string;
  reference: string;
  callbackUrl: string;
  metadata?: Record<string, string>;
};

export class PaystackClient {
  private readonly secretKey: string;
  private readonly fetchImpl: FetchLike;

  constructor(secretKey: string, fetchImpl?: FetchLike) {
    this.secretKey = secretKey;
    this.fetchImpl = fetchImpl ?? (globalThis.fetch as unknown as FetchLike);
  }

  private async call<T>(method: "GET" | "POST", path: string, body?: unknown): Promise<T> {
    const res = await this.fetchImpl(`${PAYSTACK_API}${path}`, {
      method,
      headers: { Authorization: `Bearer ${this.secretKey}`, "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(15_000),
    });
    const json = (await res.json().catch(() => null)) as { status?: boolean; message?: string; data?: T } | null;
    if (!res.ok || !json?.status) {
      // Never include the secret or full payload in errors.
      throw new Error(`Paystack ${path.split("/")[1] ?? ""} failed (${res.status}): ${json?.message ?? "no message"}`);
    }
    return json.data as T;
  }

  async initialize(args: InitializeArgs): Promise<{ authorization_url: string; access_code: string; reference: string }> {
    if (!Number.isInteger(args.amountKobo) || args.amountKobo <= 0) throw new Error("Invalid amount");
    return this.call("POST", "/transaction/initialize", {
      email: args.email,
      amount: args.amountKobo,
      currency: args.currency,
      reference: args.reference,
      callback_url: args.callbackUrl,
      channels: ["card"], // Mastercard / Visa / Verve card payments
      metadata: args.metadata,
    });
  }

  async verify(reference: string): Promise<VerifyData> {
    if (!/^[A-Za-z0-9._=-]{1,100}$/.test(reference)) throw new Error("Invalid reference");
    return this.call("GET", `/transaction/verify/${encodeURIComponent(reference)}`);
  }
}
