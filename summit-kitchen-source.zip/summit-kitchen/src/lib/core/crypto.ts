import { createHash, createHmac, randomBytes, scrypt, timingSafeEqual } from "node:crypto";

// ---- tokens ---------------------------------------------------------------

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString("base64url");
}

export function sha256(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

export function safeEqualHex(a: string, b: string): boolean {
  if (!/^[0-9a-f]*$/i.test(a) || !/^[0-9a-f]*$/i.test(b) || a.length !== b.length || a.length === 0) return false;
  return timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"));
}

export function hmacSha256(secret: string, value: string): string {
  return createHmac("sha256", secret).update(value).digest("hex");
}

// ---- references -----------------------------------------------------------

// Crockford-style alphabet without ambiguous characters (no 0/O, 1/I/L).
const ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ";

export function randomCode(length: number): string {
  // Rejection sampling to avoid modulo bias.
  let out = "";
  while (out.length < length) {
    for (const b of randomBytes(length * 2)) {
      if (b < 248 && out.length < length) out += ALPHABET[b % ALPHABET.length];
    }
  }
  return out;
}

/** Customer-facing order reference, e.g. SK-261021-7KQ4MZ */
export function orderReference(now = new Date()): string {
  const y = String(now.getUTCFullYear()).slice(2);
  const m = String(now.getUTCMonth() + 1).padStart(2, "0");
  const d = String(now.getUTCDate()).padStart(2, "0");
  return `SK-${y}${m}${d}-${randomCode(6)}`;
}

/** Unique per payment attempt; Paystack rejects reused references. */
export function paymentReference(orderRef: string): string {
  return `${orderRef}-P${randomCode(6)}`;
}

// ---- passwords (scrypt, built into Node — no native deps) -----------------

const SCRYPT = { N: 1 << 15, r: 8, p: 1, keylen: 64, maxmem: 64 * 1024 * 1024 };

function scryptAsync(pw: string, salt: Buffer, N: number, r: number, p: number, keylen: number): Promise<Buffer> {
  return new Promise((resolve, reject) =>
    scrypt(pw.normalize("NFKC"), salt, keylen, { N, r, p, maxmem: SCRYPT.maxmem }, (err, key) =>
      err ? reject(err) : resolve(key),
    ),
  );
}

export async function hashPassword(pw: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scryptAsync(pw, salt, SCRYPT.N, SCRYPT.r, SCRYPT.p, SCRYPT.keylen);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString("base64url")}$${key.toString("base64url")}`;
}

export async function verifyPassword(pw: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, n, r, p, saltB64, keyB64] = parts as [string, string, string, string, string, string];
  const N = Number(n), R = Number(r), P = Number(p);
  if (![N, R, P].every(Number.isSafeInteger) || N > 1 << 20) return false;
  const expected = Buffer.from(keyB64, "base64url");
  const actual = await scryptAsync(pw, Buffer.from(saltB64, "base64url"), N, R, P, expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

/** A precomputed hash used to equalise timing when the email doesn't exist. */
export const DUMMY_HASH =
  "scrypt$32768$8$1$AAAAAAAAAAAAAAAAAAAAAA$" + "A".repeat(86);
