// Small dependency-free validators used by every server action / route.
// Every value from a form or request body passes through here before use.

export type Result<T> = { ok: true; data: T } | { ok: false; errors: Record<string, string> };

export const NIGERIAN_STATES = [
  "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno",
  "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu", "FCT - Abuja", "Gombe",
  "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi", "Kwara", "Lagos",
  "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau", "Rivers", "Sokoto",
  "Taraba", "Yobe", "Zamfara",
] as const;

type Raw = FormData | Record<string, unknown>;

function get(raw: Raw, key: string): unknown {
  return raw instanceof FormData ? raw.get(key) : raw[key];
}

export function text(raw: Raw, key: string): string {
  const v = get(raw, key);
  return typeof v === "string" ? v.trim() : "";
}

const EMAIL_RE = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[a-z]{2,}$/i;

export function normaliseEmail(v: string): string {
  return v.trim().toLowerCase();
}

export function isEmail(v: string): boolean {
  return v.length <= 254 && EMAIL_RE.test(v);
}

/** Accepts 080..., +23480..., 23480... — returns +234XXXXXXXXXX or null. */
export function normaliseNigerianPhone(v: string): string | null {
  const digits = v.replace(/[\s\-()]/g, "");
  let m = /^\+?234([789][01]\d{8})$/.exec(digits);
  if (m) return `+234${m[1]}`;
  m = /^0([789][01]\d{8})$/.exec(digits);
  if (m) return `+234${m[1]}`;
  return null;
}

export function isSlug(v: string): boolean {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v) && v.length <= 80;
}

export function slugify(v: string): string {
  return v
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export function parseIntStrict(v: string, min: number, max: number): number | null {
  if (!/^-?\d+$/.test(v)) return null;
  const n = Number(v);
  return Number.isSafeInteger(n) && n >= min && n <= max ? n : null;
}

export const PASSWORD_MIN = 10;

export function passwordProblem(pw: string, email?: string): string | null {
  if (pw.length < PASSWORD_MIN) return `Use at least ${PASSWORD_MIN} characters.`;
  if (pw.length > 200) return "Password is too long.";
  if (!/[a-zA-Z]/.test(pw) || !/\d/.test(pw)) return "Include at least one letter and one number.";
  if (email && pw.toLowerCase().includes(email.split("@")[0]!.toLowerCase()) && email.split("@")[0]!.length >= 4)
    return "Password must not contain your email name.";
  return null;
}

// ---- Composite validators -------------------------------------------------

export type AddressInput = {
  fullName: string; phone: string; line1: string; line2: string | null;
  city: string; state: string;
};

export function validateAddress(raw: Raw): Result<AddressInput> {
  const errors: Record<string, string> = {};
  const fullName = text(raw, "fullName");
  const phoneRaw = text(raw, "phone");
  const line1 = text(raw, "line1");
  const line2 = text(raw, "line2");
  const city = text(raw, "city");
  const state = text(raw, "state");
  if (fullName.length < 2 || fullName.length > 100) errors.fullName = "Enter your full name.";
  const phone = normaliseNigerianPhone(phoneRaw);
  if (!phone) errors.phone = "Enter a valid Nigerian phone number.";
  if (line1.length < 4 || line1.length > 200) errors.line1 = "Enter your street address.";
  if (line2.length > 200) errors.line2 = "Too long.";
  if (city.length < 2 || city.length > 80) errors.city = "Enter your city or town.";
  if (!(NIGERIAN_STATES as readonly string[]).includes(state)) errors.state = "Choose a state.";
  if (Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, data: { fullName, phone: phone!, line1, line2: line2 || null, city, state } };
}

export type RegisterInput = { name: string; email: string; password: string };

export function validateRegister(raw: Raw): Result<RegisterInput> {
  const errors: Record<string, string> = {};
  const name = text(raw, "name");
  const email = normaliseEmail(text(raw, "email"));
  const password = typeof get(raw, "password") === "string" ? (get(raw, "password") as string) : "";
  const confirm = typeof get(raw, "confirm") === "string" ? (get(raw, "confirm") as string) : "";
  if (name.length < 2 || name.length > 100) errors.name = "Enter your name.";
  if (!isEmail(email)) errors.email = "Enter a valid email address.";
  const pwErr = passwordProblem(password, email);
  if (pwErr) errors.password = pwErr;
  else if (password !== confirm) errors.confirm = "Passwords do not match.";
  if (Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, data: { name, email, password } };
}

export type CheckoutInput = AddressInput & { email: string; note: string | null };

export function validateCheckout(raw: Raw): Result<CheckoutInput> {
  const addr = validateAddress(raw);
  const errors: Record<string, string> = addr.ok ? {} : { ...addr.errors };
  const email = normaliseEmail(text(raw, "email"));
  const note = text(raw, "note");
  if (!isEmail(email)) errors.email = "Enter a valid email address.";
  if (note.length > 500) errors.note = "Keep notes under 500 characters.";
  if (!addr.ok || Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, data: { ...addr.data, email, note: note || null } };
}
