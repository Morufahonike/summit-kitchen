// Rate limiting policy. Counting is done atomically in PostgreSQL (see
// src/lib/server/ratelimit.ts, tested in tests/db/run.sh); this file holds the
// pure policy pieces so they can be unit-tested.

export const LIMITS = {
  login: { limit: 10, windowSec: 15 * 60 },
  register: { limit: 5, windowSec: 60 * 60 },
  passwordReset: { limit: 5, windowSec: 60 * 60 },
  checkout: { limit: 20, windowSec: 60 * 60 },
  orderLookup: { limit: 20, windowSec: 15 * 60 },
} as const;

export type LimitName = keyof typeof LIMITS;

/** Account lockout after repeated failed logins (exponential, capped). */
export function lockoutUntil(failedLogins: number, now: Date): Date | null {
  if (failedLogins < 5) return null;
  const minutes = Math.min(60, 2 ** (failedLogins - 5) * 5);
  return new Date(now.getTime() + minutes * 60_000);
}
