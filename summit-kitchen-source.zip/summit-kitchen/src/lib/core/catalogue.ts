// Parse untrusted catalogue query parameters into a safe, whitelisted filter.

export const SORTS = {
  featured: "Featured",
  newest: "Newest",
  "price-asc": "Price: low to high",
  "price-desc": "Price: high to low",
  name: "Name A–Z",
} as const;
export type SortKey = keyof typeof SORTS;

export const PAGE_SIZE = 12;

export type CatalogueFilter = {
  q: string | null;
  category: string | null;
  minKobo: number | null;
  maxKobo: number | null;
  inStock: boolean;
  sort: SortKey;
  page: number;
};

type Params = Record<string, string | string[] | undefined>;

function one(p: Params, k: string): string | undefined {
  const v = p[k];
  return Array.isArray(v) ? v[0] : v;
}

function nairaParam(v: string | undefined): number | null {
  if (!v || !/^\d{1,9}$/.test(v)) return null;
  return Number(v) * 100;
}

export function parseCatalogueParams(p: Params): CatalogueFilter {
  const qRaw = (one(p, "q") ?? "").trim().replace(/\s+/g, " ").slice(0, 100);
  const cat = one(p, "category") ?? "";
  const sortRaw = one(p, "sort") ?? "";
  const pageRaw = one(p, "page") ?? "1";
  let minKobo = nairaParam(one(p, "min"));
  let maxKobo = nairaParam(one(p, "max"));
  if (minKobo !== null && maxKobo !== null && minKobo > maxKobo) [minKobo, maxKobo] = [maxKobo, minKobo];
  const page = /^\d{1,4}$/.test(pageRaw) ? Math.max(1, Number(pageRaw)) : 1;
  return {
    q: qRaw.length >= 2 ? qRaw : null,
    category: /^[a-z0-9-]{1,80}$/.test(cat) ? cat : null,
    minKobo,
    maxKobo,
    inStock: one(p, "inStock") === "1",
    sort: Object.hasOwn(SORTS, sortRaw) ? (sortRaw as SortKey) : "featured",
    page,
  };
}

/** Rebuild a query string, dropping defaults; used for filter links and pagination. */
export function toQuery(f: Partial<CatalogueFilter>, overrides: Partial<CatalogueFilter> = {}): string {
  const m = { ...f, ...overrides };
  const s = new URLSearchParams();
  if (m.q) s.set("q", m.q);
  if (m.category) s.set("category", m.category);
  if (m.minKobo != null) s.set("min", String(Math.floor(m.minKobo / 100)));
  if (m.maxKobo != null) s.set("max", String(Math.floor(m.maxKobo / 100)));
  if (m.inStock) s.set("inStock", "1");
  if (m.sort && m.sort !== "featured") s.set("sort", m.sort);
  if (m.page && m.page > 1) s.set("page", String(m.page));
  const str = s.toString();
  return str ? `?${str}` : "";
}
