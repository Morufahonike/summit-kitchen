// Server-side totals. Client-supplied prices are never trusted: totals are
// always recomputed from current product rows and the configured delivery zone.

export const MAX_QTY_PER_LINE = 20;
export const MAX_LINES = 50;

export type PricedLine = {
  productId: string;
  name: string;
  sku: string;
  unitPriceKobo: number;
  quantity: number;
  stock: number;
  isActive: boolean;
};

export type Zone = { id: string; name: string; states: string[]; feeKobo: number; isActive: boolean };

export type LineProblem = { productId: string; name: string; problem: string };

export type Totals = {
  lines: (PricedLine & { lineTotalKobo: number })[];
  subtotalKobo: number;
  deliveryKobo: number | null; // null = no delivery rate configured for the state
  totalKobo: number | null;
  zone: Zone | null;
  problems: LineProblem[];
};

export function findZoneForState(zones: Zone[], state: string | null | undefined): Zone | null {
  if (!state) return null;
  const s = state.trim().toLowerCase();
  return zones.find((z) => z.isActive && z.states.some((x) => x.trim().toLowerCase() === s)) ?? null;
}

export function computeTotals(lines: PricedLine[], zones: Zone[], state?: string | null): Totals {
  const problems: LineProblem[] = [];
  if (lines.length > MAX_LINES) {
    problems.push({ productId: "*", name: "Cart", problem: `A cart can hold at most ${MAX_LINES} different products.` });
  }
  const priced = lines.map((l) => {
    if (!Number.isInteger(l.quantity) || l.quantity < 1 || l.quantity > MAX_QTY_PER_LINE) {
      problems.push({ productId: l.productId, name: l.name, problem: `Quantity must be between 1 and ${MAX_QTY_PER_LINE}.` });
    }
    if (!Number.isInteger(l.unitPriceKobo) || l.unitPriceKobo <= 0) {
      problems.push({ productId: l.productId, name: l.name, problem: "Price unavailable." });
    }
    if (!l.isActive) {
      problems.push({ productId: l.productId, name: l.name, problem: "No longer available." });
    } else if (l.stock < l.quantity) {
      problems.push({
        productId: l.productId,
        name: l.name,
        problem: l.stock <= 0 ? "Out of stock." : `Only ${l.stock} left in stock.`,
      });
    }
    return { ...l, lineTotalKobo: l.unitPriceKobo * l.quantity };
  });
  const subtotalKobo = priced.reduce((sum, l) => sum + l.lineTotalKobo, 0);
  if (!Number.isSafeInteger(subtotalKobo)) throw new Error("Subtotal overflow");
  const zone = findZoneForState(zones, state);
  const deliveryKobo = zone ? zone.feeKobo : null;
  return {
    lines: priced,
    subtotalKobo,
    deliveryKobo,
    totalKobo: deliveryKobo === null ? null : subtotalKobo + deliveryKobo,
    zone,
    problems,
  };
}

/** Clamp a requested quantity for add-to-cart. */
export function clampQuantity(requested: number, stock: number): number {
  if (!Number.isFinite(requested)) return 1;
  return Math.max(1, Math.min(Math.trunc(requested), MAX_QTY_PER_LINE, Math.max(stock, 1)));
}
