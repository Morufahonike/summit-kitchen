// Validation for admin forms. Kept framework-free so it is unit-tested.
import { parseMajorToMinor } from "./money.ts";
import { NIGERIAN_STATES, isSlug, parseIntStrict, slugify, text, type Result } from "./validation.ts";

type Raw = FormData | Record<string, unknown>;

export type ProductInput = {
  name: string; slug: string; sku: string; description: string; categoryId: string;
  priceKobo: number; compareAtKobo: number | null; material: string | null; colour: string | null;
  image: string | null; isActive: boolean; isFeatured: boolean; isBestseller: boolean; isSample: boolean;
};

const bool = (raw: Raw, k: string) => {
  const v = raw instanceof FormData ? raw.get(k) : raw[k];
  return v === "on" || v === "true" || v === true;
};

export function validateProduct(raw: Raw): Result<ProductInput> {
  const errors: Record<string, string> = {};
  const name = text(raw, "name");
  const slug = text(raw, "slug") || slugify(name);
  const sku = text(raw, "sku").toUpperCase();
  const description = text(raw, "description");
  const categoryId = text(raw, "categoryId");
  const priceKobo = parseMajorToMinor(text(raw, "price"));
  const compareRaw = text(raw, "compareAt");
  const compareAtKobo = compareRaw ? parseMajorToMinor(compareRaw) : null;
  const image = text(raw, "image") || null;

  if (name.length < 2 || name.length > 120) errors.name = "Name must be 2–120 characters.";
  if (!isSlug(slug)) errors.slug = "Use lowercase letters, numbers and hyphens.";
  if (!/^[A-Z0-9][A-Z0-9-]{1,39}$/.test(sku)) errors.sku = "SKU: 2–40 letters, numbers or hyphens.";
  if (description.length < 10 || description.length > 5000) errors.description = "Description must be 10–5000 characters.";
  if (!/^[a-z0-9_]{5,40}$/i.test(categoryId)) errors.categoryId = "Choose a category.";
  if (priceKobo === null || priceKobo <= 0) errors.price = "Enter a price greater than zero.";
  if (compareRaw && (compareAtKobo === null || (priceKobo !== null && compareAtKobo <= priceKobo))) {
    errors.compareAt = "Compare-at price must be higher than the price.";
  }
  // Only local images (served from /public) — no arbitrary external URLs.
  if (image && !/^\/images\/[a-z0-9/_-]+\.(svg|png|jpe?g|webp)$/i.test(image)) errors.image = "Image must be a path under /images/.";

  if (Object.keys(errors).length) return { ok: false, errors };
  return {
    ok: true,
    data: {
      name, slug, sku, description, categoryId, priceKobo: priceKobo!, compareAtKobo,
      material: text(raw, "material").slice(0, 80) || null,
      colour: text(raw, "colour").slice(0, 40) || null,
      image,
      isActive: bool(raw, "isActive"), isFeatured: bool(raw, "isFeatured"),
      isBestseller: bool(raw, "isBestseller"), isSample: bool(raw, "isSample"),
    },
  };
}

export type CategoryInput = { name: string; slug: string; description: string | null; sortOrder: number; isActive: boolean };

export function validateCategory(raw: Raw): Result<CategoryInput> {
  const errors: Record<string, string> = {};
  const name = text(raw, "name");
  const slug = text(raw, "slug") || slugify(name);
  const sortOrder = parseIntStrict(text(raw, "sortOrder") || "0", 0, 1000);
  if (name.length < 2 || name.length > 60) errors.name = "Name must be 2–60 characters.";
  if (!isSlug(slug)) errors.slug = "Use lowercase letters, numbers and hyphens.";
  if (sortOrder === null) errors.sortOrder = "Sort order must be 0–1000.";
  if (Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, data: { name, slug, description: text(raw, "description").slice(0, 300) || null, sortOrder: sortOrder!, isActive: bool(raw, "isActive") } };
}

export type ZoneInput = { name: string; states: string[]; feeKobo: number; etaText: string | null; isActive: boolean };

export function validateZone(raw: Raw): Result<ZoneInput> {
  const errors: Record<string, string> = {};
  const name = text(raw, "name");
  const states = raw instanceof FormData ? raw.getAll("states").map(String) : (Array.isArray(raw.states) ? raw.states.map(String) : []);
  const feeKobo = parseMajorToMinor(text(raw, "fee"));
  if (name.length < 2 || name.length > 60) errors.name = "Name must be 2–60 characters.";
  const valid = states.filter((s) => (NIGERIAN_STATES as readonly string[]).includes(s));
  if (valid.length === 0 || valid.length !== states.length) errors.states = "Choose at least one valid state.";
  if (feeKobo === null) errors.fee = "Enter a delivery fee (0 for free delivery).";
  if (Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, data: { name, states: [...new Set(valid)], feeKobo: feeKobo!, etaText: text(raw, "etaText").slice(0, 80) || null, isActive: bool(raw, "isActive") } };
}

/** States covered by more than one active zone (ambiguous pricing). */
export function overlappingStates(zones: { id: string; states: string[]; isActive: boolean }[], candidate: { id?: string; states: string[] }): string[] {
  const taken = new Set(zones.filter((z) => z.isActive && z.id !== candidate.id).flatMap((z) => z.states));
  return candidate.states.filter((s) => taken.has(s));
}

/** Only allow same-site relative redirects (prevents open redirects after login). */
export function safeNextPath(v: string, fallback: string): string {
  if (typeof v !== "string" || v.length > 200) return fallback;
  if (!v.startsWith("/") || v.startsWith("//") || v.includes("\\") || /[\u0000-\u001f]/.test(v)) return fallback;
  return /^\/[\w\-/?=&%.~]*$/.test(v) ? v : fallback;
}
