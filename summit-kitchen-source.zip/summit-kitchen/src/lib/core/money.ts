// All amounts are integer minor units (kobo). 100 kobo = ₦1.

export function formatMoney(minor: number, currency = "NGN"): string {
  if (!Number.isInteger(minor)) throw new Error("Amount must be integer minor units");
  const major = minor / 100;
  const symbol = currency === "NGN" ? "₦" : currency === "USD" ? "$" : `${currency} `;
  const hasKobo = minor % 100 !== 0;
  const formatted = Math.abs(major).toLocaleString("en-NG", {
    minimumFractionDigits: hasKobo ? 2 : 0,
    maximumFractionDigits: 2,
  });
  return `${minor < 0 ? "-" : ""}${symbol}${formatted}`;
}

/** Parse an admin-entered major amount like "45,000" or "1250.50" into kobo. */
export function parseMajorToMinor(input: string): number | null {
  const cleaned = input.trim().replace(/[,₦\s]/g, "");
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(cleaned)) return null;
  const [whole, frac = ""] = cleaned.split(".");
  const minor = Number(whole) * 100 + Number(frac.padEnd(2, "0"));
  return Number.isSafeInteger(minor) ? minor : null;
}

export function minorToMajorString(minor: number): string {
  const whole = Math.trunc(minor / 100);
  const frac = Math.abs(minor % 100);
  return frac === 0 ? String(whole) : `${whole}.${String(frac).padStart(2, "0")}`;
}
