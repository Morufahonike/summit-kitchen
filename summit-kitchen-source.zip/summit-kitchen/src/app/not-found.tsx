import Link from "next/link";
import { MountainMark } from "@/components/Logo";

export default function NotFound() {
  return (
    <main className="container-site flex min-h-[70vh] flex-col items-center justify-center py-20 text-center">
      <MountainMark className="h-10 w-auto" />
      <h1 className="mt-6 text-4xl">Page not found</h1>
      <p className="mt-3 text-charcoal-600">The page you&apos;re looking for doesn&apos;t exist or has moved.</p>
      <Link href="/" className="btn-gold mt-8">Back to home</Link>
    </main>
  );
}
