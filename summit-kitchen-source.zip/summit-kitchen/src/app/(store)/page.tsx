import Link from "next/link";
import { ProductGrid } from "@/components/ProductCard";
import { TrustBar } from "@/components/Footer";
import { MountainMark } from "@/components/Logo";
import { homepageProducts, listCategories } from "@/lib/server/catalogue";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [{ featured, bestsellers }, categories] = await Promise.all([homepageProducts(), listCategories()]);
  return (
    <>
      {/* Hero — follows the brand board's "Elevate Your Everyday Living" concept */}
      <section className="relative overflow-hidden bg-ivory-200">
        <div className="container-site grid items-center gap-10 py-14 md:grid-cols-2 md:py-20 lg:py-28">
          <div className="max-w-xl">
            <p className="eyebrow">Summit Kitchen</p>
            <h1 className="mt-4 text-4xl leading-tight sm:text-5xl lg:text-6xl">Elevate Your Everyday Living</h1>
            <p className="mt-5 text-base text-charcoal-600 sm:text-lg">Premium kitchen and homeware for modern homes — thoughtfully curated for quality, functionality and timeless elegance.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/shop" className="btn-gold">Shop the Collection</Link>
              <Link href="/collections" className="btn-outline">Browse categories</Link>
            </div>
          </div>
          <div className="relative mx-auto aspect-[4/3] w-full max-w-lg">
            <div className="absolute inset-0 rounded-[2rem] bg-sage-100" />
            <div className="absolute inset-6 flex items-center justify-center rounded-[1.5rem] bg-ivory">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/products/cookware.svg" alt="" className="h-full w-full rounded-[1.5rem] object-cover" />
            </div>
            <p className="absolute bottom-3 right-4 text-[10px] uppercase tracking-widest text-charcoal-400">Placeholder imagery</p>
          </div>
        </div>
      </section>

      <TrustBar />

      <section className="container-site py-14" aria-labelledby="cat-h">
        <div className="text-center">
          <h2 id="cat-h" className="text-3xl">Shop by Category</h2>
          <div className="rule-gold mt-4" />
        </div>
        <ul className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-7">
          {categories.map((c) => (
            <li key={c.id}>
              <Link href={`/shop?category=${c.slug}`} className="group flex flex-col items-center rounded-lg border border-taupe-300 bg-white p-4 text-center hover:border-olive">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/images/products/${c.slug}.svg`} alt="" className="h-20 w-20 rounded-full object-cover" />
                <span className="mt-3 text-sm font-medium group-hover:text-olive">{c.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {featured.length > 0 && (
        <section className="container-site py-6" aria-labelledby="feat-h">
          <div className="mb-8 flex items-end justify-between gap-4">
            <h2 id="feat-h" className="text-3xl">Featured</h2>
            <Link href="/shop" className="btn-link">View all</Link>
          </div>
          <ProductGrid products={featured} />
        </section>
      )}

      <section className="my-16 bg-forest py-16 text-center text-ivory">
        <div className="container-site">
          <MountainMark className="mx-auto h-10 w-auto" tone="light" />
          <p className="mx-auto mt-6 max-w-2xl font-serif text-2xl leading-relaxed sm:text-3xl">Quality. Functionality. Elegance. Modern living.</p>
        </div>
      </section>

      {bestsellers.length > 0 && (
        <section className="container-site py-6" aria-labelledby="best-h">
          <div className="mb-8 flex items-end justify-between gap-4">
            <h2 id="best-h" className="text-3xl">Bestsellers</h2>
            <Link href="/shop?sort=featured" className="btn-link">Shop more</Link>
          </div>
          <ProductGrid products={bestsellers} />
        </section>
      )}
    </>
  );
}
