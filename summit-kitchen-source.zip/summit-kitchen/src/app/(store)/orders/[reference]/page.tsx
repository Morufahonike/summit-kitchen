import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { canViewOrder } from "@/lib/server/checkout";
import { getCurrentUser } from "@/lib/server/session";
import { formatMoney } from "@/lib/core/money";
import { STATUS_LABEL, trackingSteps } from "@/lib/core/orders";
import { retryPaymentAction } from "../../checkout/actions";

export const metadata: Metadata = { title: "Order", robots: { index: false } };
export const dynamic = "force-dynamic";

type Props = { params: Promise<{ reference: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function OrderPage({ params, searchParams }: Props) {
  const { reference } = await params;
  const sp = await searchParams;
  const token = typeof sp.t === "string" ? sp.t : "";
  const notice = typeof sp.notice === "string" ? sp.notice.slice(0, 200) : null;
  if (!/^SK-\d{6}-[A-Z0-9]{6}$/.test(reference)) notFound();

  const order = await prisma.order.findUnique({
    where: { reference },
    include: { items: true, events: { orderBy: { createdAt: "asc" } } },
  });
  const user = await getCurrentUser();
  // Same 404 whether the order doesn't exist or the viewer isn't allowed — avoids leaking which references exist.
  if (!order || !canViewOrder(order, user, token)) notFound();

  const steps = trackingSteps(order.status);
  const canPay = order.status === "PENDING_PAYMENT" && (!order.reservationExpiresAt || order.reservationExpiresAt > new Date());

  return (
    <div className="container-site max-w-3xl py-10">
      <p className="eyebrow">Order</p>
      <h1 className="mt-2 text-3xl tracking-wide">{order.reference}</h1>
      <p className="mt-1 text-sm text-charcoal-400">Placed {order.createdAt.toLocaleString("en-NG", { dateStyle: "medium", timeStyle: "short", timeZone: "Africa/Lagos" })}</p>
      {token && <p className="mt-2 text-xs text-charcoal-400">Keep this page&apos;s link private — it gives access to your order.</p>}
      {notice && <p className="alert-info mt-4">{notice}</p>}

      <section className="card mt-6 p-6" aria-labelledby="st-h">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 id="st-h" className="text-xl">Status</h2>
          <span className="badge bg-sage-50 text-olive">{STATUS_LABEL[order.status]}</span>
        </div>
        {["CANCELLED", "EXPIRED", "PAYMENT_FAILED", "REFUNDED"].includes(order.status) ? null : (
          <ol className="mt-6 grid gap-4 sm:grid-cols-5">
            {steps.map((s) => (
              <li key={s.label} className="flex items-center gap-2 text-sm sm:flex-col sm:text-center">
                <span className={`h-3 w-3 rounded-full ${s.done ? "bg-olive" : "border border-taupe bg-white"}`} aria-hidden="true" />
                <span className={s.done ? "font-medium" : "text-charcoal-400"}>{s.label}</span>
              </li>
            ))}
          </ol>
        )}
        {order.trackingNumber && <p className="mt-4 text-sm">Tracking: {order.carrier ? `${order.carrier} — ` : ""}<strong>{order.trackingNumber}</strong></p>}
        {canPay && (
          <form action={retryPaymentAction} className="mt-6">
            <input type="hidden" name="reference" value={order.reference} />
            <input type="hidden" name="t" value={token} />
            <button className="btn-gold" type="submit">Pay now — {formatMoney(order.totalKobo, order.currency)}</button>
            {order.reservationExpiresAt && (
              <p className="mt-2 text-xs text-charcoal-400">Items are held until {order.reservationExpiresAt.toLocaleTimeString("en-NG", { timeStyle: "short", timeZone: "Africa/Lagos" })}.</p>
            )}
          </form>
        )}
      </section>

      <section className="card mt-6 p-6" aria-labelledby="it-h">
        <h2 id="it-h" className="text-xl">Items</h2>
        <ul className="mt-4 divide-y divide-taupe-300/60 text-sm">
          {order.items.map((i) => (
            <li key={i.id} className="flex justify-between gap-4 py-2">
              <span>{i.nameSnapshot} <span className="text-charcoal-400">× {i.quantity}</span></span>
              <span>{formatMoney(i.lineTotalKobo, order.currency)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-4 space-y-1 border-t border-taupe-300 pt-4 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatMoney(order.subtotalKobo, order.currency)}</dd></div>
          <div className="flex justify-between"><dt>Delivery</dt><dd>{formatMoney(order.deliveryKobo, order.currency)}</dd></div>
          <div className="flex justify-between text-base font-semibold"><dt>Total</dt><dd>{formatMoney(order.totalKobo, order.currency)}</dd></div>
        </dl>
      </section>

      <section className="card mt-6 p-6 text-sm" aria-labelledby="ad-h">
        <h2 id="ad-h" className="text-xl">Delivery to</h2>
        <address className="mt-3 not-italic leading-relaxed">
          {order.shippingName}<br />{order.line1}{order.line2 ? <>, {order.line2}</> : null}<br />{order.city}, {order.state}<br />{order.phone}
        </address>
      </section>

      <div className="mt-8 text-center">
        <Link href={user ? "/account/orders" : "/shop"} className="btn-link">{user ? "Back to my orders" : "Continue shopping"}</Link>
      </div>
    </div>
  );
}
