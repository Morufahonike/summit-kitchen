import Link from "next/link";
import type { Metadata } from "next";
import { requireUser } from "@/lib/server/session";
import { prisma } from "@/lib/server/db";
import { formatMoney } from "@/lib/core/money";
import { STATUS_LABEL } from "@/lib/core/orders";
import { AccountNav } from "../AccountNav";

export const metadata: Metadata = { title: "My orders", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function OrdersPage() {
  const user = await requireUser("/account/orders");
  const orders = await prisma.order.findMany({
    where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 100,
    include: { _count: { select: { items: true } } },
  });
  return (
    <div className="container-site max-w-4xl py-10">
      <h1 className="text-3xl">My orders</h1>
      <div className="mt-6"><AccountNav current="orders" /></div>
      {orders.length === 0 ? (
        <p className="mt-8 text-charcoal-600">You haven&apos;t placed any orders yet.</p>
      ) : (
        <div className="mt-6 overflow-x-auto">
          <table className="table min-w-[560px]">
            <thead><tr><th>Reference</th><th>Date</th><th>Items</th><th>Status</th><th className="text-right">Total</th></tr></thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id}>
                  <td><Link href={`/orders/${o.reference}`} className="font-medium hover:text-olive">{o.reference}</Link></td>
                  <td>{o.createdAt.toLocaleDateString("en-NG", { timeZone: "Africa/Lagos" })}</td>
                  <td>{o._count.items}</td>
                  <td>{STATUS_LABEL[o.status]}</td>
                  <td className="text-right">{formatMoney(o.totalKobo, o.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
