import type { Metadata } from "next";
import { ResetForm } from "../forms";

export const metadata: Metadata = { title: "Choose a new password", robots: { index: false } };

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function ResetPage({ searchParams }: Props) {
  const sp = await searchParams;
  const token = typeof sp.token === "string" ? sp.token : "";
  return (
    <div className="container-site max-w-md py-14">
      <h1 className="text-3xl">Choose a new password</h1>
      <div className="mt-6">
        {token ? <ResetForm token={token} /> : <p className="alert-error">This reset link is invalid or has expired.</p>}
      </div>
    </div>
  );
}
