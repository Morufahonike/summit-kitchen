import type { Metadata } from "next";
import { requireUser } from "@/lib/server/session";
import { prisma } from "@/lib/server/db";
import { AccountNav } from "../AccountNav";
import { AddressForm } from "../forms";
import { deleteAddressAction } from "../actions";

export const metadata: Metadata = { title: "Addresses", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function AddressesPage() {
  const user = await requireUser("/account/addresses");
  const addresses = await prisma.address.findMany({ where: { userId: user.id }, orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }] });
  return (
    <div className="container-site max-w-4xl py-10">
      <h1 className="text-3xl">Addresses</h1>
      <div className="mt-6"><AccountNav current="addresses" /></div>
      <div className="mt-8 grid gap-8 md:grid-cols-2">
        <section aria-label="Saved addresses" className="space-y-4">
          {addresses.length === 0 && <p className="text-sm text-charcoal-600">No saved addresses yet.</p>}
          {addresses.map((a) => (
            <details key={a.id} className="card p-5">
              <summary className="cursor-pointer list-none">
                <p className="font-medium">{a.label ?? "Address"} {a.isDefault && <span className="badge bg-sage-50 text-olive">Default</span>}</p>
                <address className="mt-1 text-sm not-italic text-charcoal-600">{a.fullName}, {a.line1}, {a.city}, {a.state} · {a.phone}</address>
                <span className="btn-link mt-2 inline-block">Edit</span>
              </summary>
              <div className="mt-4 space-y-4 border-t border-taupe-300 pt-4">
                <AddressForm address={{ ...a, createdAt: null, updatedAt: null }} />
                <form action={deleteAddressAction}>
                  <input type="hidden" name="id" value={a.id} />
                  <button className="btn-danger" type="submit">Delete address</button>
                </form>
              </div>
            </details>
          ))}
        </section>
        <section className="card p-6" aria-labelledby="new-h">
          <h2 id="new-h" className="text-xl">Add an address</h2>
          <div className="mt-4"><AddressForm /></div>
        </section>
      </div>
    </div>
  );
}
