import Link from "next/link";
import type { Metadata } from "next";
import { requireUser } from "@/lib/server/session";
import { prisma } from "@/lib/server/db";
import { formatMoney } from "@/lib/core/money";
import { STATUS_LABEL } from "@/lib/core/orders";
import { AccountNav } from "./AccountNav";
import { ChangePasswordForm, ProfileForm } from "./forms";

export const metadata: Metadata = { title: "My account", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const user = await requireUser();
  const recent = await prisma.order.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 3 });
  return (
    <div className="container-site max-w-4xl py-10">
      <h1 className="text-3xl">Hello, {user.name.split(" ")[0]}</h1>
      <div className="mt-6"><AccountNav current="overview" /></div>
      <div className="mt-8 grid gap-8 md:grid-cols-2">
        <section className="card p-6">
          <h2 className="text-xl">Recent orders</h2>
          {recent.length === 0 ? (
            <p className="mt-3 text-sm text-charcoal-600">No orders yet. <Link href="/shop" className="btn-link">Start shopping</Link></p>
          ) : (
            <ul className="mt-3 divide-y divide-taupe-300/60 text-sm">
              {recent.map((o) => (
                <li key={o.id} className="flex justify-between gap-2 py-2">
                  <Link href={`/orders/${o.reference}`} className="font-medium hover:text-olive">{o.reference}</Link>
                  <span className="text-charcoal-400">{STATUS_LABEL[o.status]}</span>
                  <span>{formatMoney(o.totalKobo, o.currency)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section className="card space-y-8 p-6">
          <div>
            <h2 className="text-xl">Profile</h2>
            <p className="mt-1 text-sm text-charcoal-400">{user.email}</p>
            <div className="mt-4"><ProfileForm name={user.name} /></div>
          </div>
          <div>
            <h2 className="text-xl">Password</h2>
            <div className="mt-4"><ChangePasswordForm /></div>
          </div>
        </section>
      </div>
    </div>
  );
}
