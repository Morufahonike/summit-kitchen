import Link from "next/link";
import { logoutAction } from "./actions";

export function AccountNav({ current }: { current: "overview" | "orders" | "addresses" }) {
  const items = [
    { k: "overview", href: "/account", label: "Overview" },
    { k: "orders", href: "/account/orders", label: "Orders" },
    { k: "addresses", href: "/account/addresses", label: "Addresses" },
  ] as const;
  return (
    <nav className="flex flex-wrap items-center gap-2 border-b border-taupe-300 pb-4" aria-label="Account">
      {items.map((i) => (
        <Link key={i.k} href={i.href} aria-current={current === i.k ? "page" : undefined}
          className={`rounded-full px-4 py-2 text-sm ${current === i.k ? "bg-forest text-ivory" : "hover:bg-taupe-300/40"}`}>
          {i.label}
        </Link>
      ))}
      <form action={logoutAction} className="ml-auto">
        <button className="btn-link" type="submit">Sign out</button>
      </form>
    </nav>
  );
}
