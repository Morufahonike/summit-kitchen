import Link from "next/link";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/server/session";
import { LoginForm, RegisterForm } from "../forms";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function LoginPage({ searchParams }: Props) {
  const sp = await searchParams;
  const next = typeof sp.next === "string" ? sp.next : "";
  if (await getCurrentUser()) redirect("/account");
  return (
    <div className="container-site grid max-w-5xl gap-10 py-14 md:grid-cols-2">
      <section className="card p-6 sm:p-8" aria-labelledby="in-h">
        <h1 id="in-h" className="text-2xl">Sign in</h1>
        <div className="mt-6"><LoginForm next={next} /></div>
      </section>
      <section className="card p-6 sm:p-8" aria-labelledby="up-h">
        <h2 id="up-h" className="text-2xl">Create an account</h2>
        <p className="mt-1 text-sm text-charcoal-600">Save addresses, view order history and track deliveries.</p>
        <div className="mt-6"><RegisterForm next={next} /></div>
      </section>
      <p className="text-center text-sm text-charcoal-400 md:col-span-2">
        Checked out as a guest? <Link href="/track" className="btn-link">Track your order</Link>
      </p>
    </div>
  );
}
