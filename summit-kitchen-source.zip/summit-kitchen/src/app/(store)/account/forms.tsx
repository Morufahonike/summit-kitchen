"use client";
import Link from "next/link";
import { useActionState } from "react";
import {
  loginAction, registerAction, forgotPasswordAction, resetPasswordAction, changePasswordAction,
  saveAddressAction, updateProfileAction, type FormState,
} from "./actions";
import { AddressFields, Field, FormMessage } from "@/components/Field";
import { SubmitButton } from "@/components/SubmitButton";

export function LoginForm({ next }: { next: string }) {
  const [s, a] = useActionState<FormState, FormData>(loginAction, null);
  return (
    <form action={a} className="space-y-4">
      <FormMessage error={s?.error} />
      <input type="hidden" name="next" value={next} />
      <Field name="email" label="Email" type="email" autoComplete="email" required />
      <Field name="password" label="Password" type="password" autoComplete="current-password" required />
      <div className="flex items-center justify-between">
        <SubmitButton pendingText="Signing in…">Sign in</SubmitButton>
        <Link href="/account/forgot" className="btn-link">Forgot password?</Link>
      </div>
    </form>
  );
}

export function RegisterForm({ next }: { next: string }) {
  const [s, a] = useActionState<FormState, FormData>(registerAction, null);
  const e = s?.errors ?? {};
  return (
    <form action={a} className="space-y-4" noValidate>
      <FormMessage error={s?.error} />
      <input type="hidden" name="next" value={next} />
      <Field name="name" label="Full name" autoComplete="name" required error={e.name} />
      <Field name="email" label="Email" type="email" autoComplete="email" required error={e.email} />
      <Field name="password" label="Password (10+ characters, letters and numbers)" type="password" autoComplete="new-password" required error={e.password} />
      <Field name="confirm" label="Confirm password" type="password" autoComplete="new-password" required error={e.confirm} />
      <SubmitButton pendingText="Creating account…">Create account</SubmitButton>
    </form>
  );
}

export function ForgotForm() {
  const [s, a] = useActionState<FormState, FormData>(forgotPasswordAction, null);
  return (
    <form action={a} className="space-y-4">
      <FormMessage error={s?.error} success={s?.success} />
      <Field name="email" label="Email" type="email" autoComplete="email" required error={s?.errors?.email} />
      <SubmitButton pendingText="Sending…">Send reset link</SubmitButton>
    </form>
  );
}

export function ResetForm({ token }: { token: string }) {
  const [s, a] = useActionState<FormState, FormData>(resetPasswordAction, null);
  if (s?.success) return <p className="alert-ok">{s.success} <Link href="/account/login" className="font-semibold underline">Sign in</Link></p>;
  return (
    <form action={a} className="space-y-4">
      <FormMessage error={s?.error} />
      <input type="hidden" name="token" value={token} />
      <Field name="password" label="New password" type="password" autoComplete="new-password" required error={s?.errors?.password} />
      <Field name="confirm" label="Confirm new password" type="password" autoComplete="new-password" required error={s?.errors?.confirm} />
      <SubmitButton pendingText="Saving…">Set new password</SubmitButton>
    </form>
  );
}

export function ChangePasswordForm() {
  const [s, a] = useActionState<FormState, FormData>(changePasswordAction, null);
  return (
    <form action={a} className="space-y-4">
      <FormMessage error={s?.error} success={s?.success} />
      <Field name="current" label="Current password" type="password" autoComplete="current-password" required error={s?.errors?.current} />
      <Field name="password" label="New password" type="password" autoComplete="new-password" required error={s?.errors?.password} />
      <SubmitButton className="btn-outline" pendingText="Saving…">Change password</SubmitButton>
    </form>
  );
}

export function ProfileForm({ name }: { name: string }) {
  const [s, a] = useActionState<FormState, FormData>(updateProfileAction, null);
  return (
    <form action={a} className="space-y-4">
      <FormMessage error={s?.error} success={s?.success} />
      <Field name="name" label="Name" defaultValue={name} required error={s?.errors?.name} autoComplete="name" />
      <SubmitButton className="btn-outline" pendingText="Saving…">Save</SubmitButton>
    </form>
  );
}

export function AddressForm({ address }: { address?: Record<string, string | boolean | null> }) {
  const [s, a] = useActionState<FormState, FormData>(saveAddressAction, null);
  const values = (address ?? {}) as Record<string, string | null>;
  return (
    <form action={a} className="space-y-4" noValidate>
      <FormMessage error={s?.error ?? (s?.errors ? "Please check the highlighted fields." : null)} success={s?.success} />
      {address?.id && <input type="hidden" name="id" value={String(address.id)} />}
      <Field name="label" label="Label (e.g. Home, Office)" defaultValue={values.label} />
      <AddressFields errors={s?.errors} values={values} />
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="isDefault" defaultChecked={Boolean(address?.isDefault)} className="accent-olive" /> Use as default address</label>
      <SubmitButton pendingText="Saving…">Save address</SubmitButton>
    </form>
  );
}
