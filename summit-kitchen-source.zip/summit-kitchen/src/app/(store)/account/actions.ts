"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { createSession, destroySession, getCurrentUser, requireUser, revokeAllSessions } from "@/lib/server/session";
import { attachCartToUser } from "@/lib/server/cart";
import { rateLimit } from "@/lib/server/ratelimit";
import { clientIp } from "@/lib/server/request";
import { logActivity } from "@/lib/server/audit";
import { sendMail } from "@/lib/server/mail";
import { hashPassword, verifyPassword, randomToken, sha256, DUMMY_HASH } from "@/lib/core/crypto";
import { lockoutUntil } from "@/lib/core/ratelimit";
import { safeNextPath } from "@/lib/core/admin";
import { isEmail, normaliseEmail, passwordProblem, text, validateAddress, validateRegister } from "@/lib/core/validation";

export type FormState = { error?: string; success?: string; errors?: Record<string, string> } | null;


export async function registerAction(_prev: FormState, form: FormData): Promise<FormState> {
  if (!(await rateLimit("register", await clientIp()))) return { error: "Too many sign-ups from this network. Try again later." };
  const parsed = validateRegister(form);
  if (!parsed.ok) return { errors: parsed.errors };
  const { name, email, password } = parsed.data;
  const exists = await prisma.user.findUnique({ where: { email }, select: { id: true } });
  if (exists) return { errors: { email: "An account with this email already exists. Try signing in." } };
  const user = await prisma.user.create({ data: { name, email, passwordHash: await hashPassword(password) } });
  await logActivity({ actorId: user.id, action: "user.registered", entityType: "User", entityId: user.id });
  await createSession(user.id, user.role);
  await attachCartToUser(user.id);
  redirect(safeNextPath(text(form, "next"), "/account"));
}

export async function loginAction(_prev: FormState, form: FormData): Promise<FormState> {
  const email = normaliseEmail(text(form, "email"));
  const password = String(form.get("password") ?? "");
  const generic = { error: "Incorrect email or password." };
  const ip = await clientIp();
  if (!(await rateLimit("login", ip)) || !(await rateLimit("login", `email:${email}`))) {
    return { error: "Too many sign-in attempts. Please wait and try again." };
  }
  if (!isEmail(email) || password.length === 0 || password.length > 200) return generic;

  const user = await prisma.user.findUnique({ where: { email } });
  // Always run a hash comparison so response time doesn't reveal whether the email exists.
  const valid = await verifyPassword(password, user?.passwordHash ?? DUMMY_HASH);
  if (!user || user.disabled) return generic;
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    return { error: "This account is temporarily locked after several failed attempts. Try again later or reset your password." };
  }
  if (!valid) {
    const failed = user.failedLogins + 1;
    await prisma.user.update({ where: { id: user.id }, data: { failedLogins: failed, lockedUntil: lockoutUntil(failed, new Date()) } });
    if (user.role !== "CUSTOMER") await logActivity({ action: "admin.login_failed", entityType: "User", entityId: user.id });
    return generic;
  }
  await prisma.user.update({ where: { id: user.id }, data: { failedLogins: 0, lockedUntil: null, lastLoginAt: new Date() } });
  await createSession(user.id, user.role);
  await attachCartToUser(user.id);
  if (user.role !== "CUSTOMER") await logActivity({ actorId: user.id, action: "admin.login", entityType: "User", entityId: user.id });
  redirect(safeNextPath(text(form, "next"), user.role === "CUSTOMER" ? "/account" : "/admin"));
}

export async function logoutAction(): Promise<void> {
  await destroySession();
  redirect("/");
}

export async function forgotPasswordAction(_prev: FormState, form: FormData): Promise<FormState> {
  const email = normaliseEmail(text(form, "email"));
  const done = { success: "If an account exists for that email, we've sent a link to reset your password." };
  if (!(await rateLimit("passwordReset", await clientIp()))) return { error: "Too many requests. Please try again later." };
  if (!isEmail(email)) return { errors: { email: "Enter a valid email address." } };
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || user.disabled) return done; // same response either way (no account enumeration)
  const token = randomToken(32);
  await prisma.passwordResetToken.deleteMany({ where: { userId: user.id, usedAt: null } });
  await prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash: sha256(token), expiresAt: new Date(Date.now() + 30 * 60_000) } });
  await sendMail({
    to: user.email,
    subject: "Reset your Summit Kitchen password",
    text: `Use this link within 30 minutes to choose a new password:\n${env.appUrl}/account/reset?token=${token}\n\nIf you didn't ask for this, ignore this email.`,
  });
  return done;
}

export async function resetPasswordAction(_prev: FormState, form: FormData): Promise<FormState> {
  const token = text(form, "token");
  const password = String(form.get("password") ?? "");
  const confirm = String(form.get("confirm") ?? "");
  if (!token || token.length > 100) return { error: "This reset link is invalid or has expired." };
  const row = await prisma.passwordResetToken.findUnique({ where: { tokenHash: sha256(token) }, include: { user: true } });
  if (!row || row.usedAt || row.expiresAt < new Date() || row.user.disabled) return { error: "This reset link is invalid or has expired." };
  const problem = passwordProblem(password, row.user.email);
  if (problem) return { errors: { password: problem } };
  if (password !== confirm) return { errors: { confirm: "Passwords do not match." } };
  // Mark used with a guarded update so a link can only be redeemed once, even concurrently.
  const used = await prisma.passwordResetToken.updateMany({ where: { id: row.id, usedAt: null }, data: { usedAt: new Date() } });
  if (used.count !== 1) return { error: "This reset link has already been used." };
  await prisma.user.update({ where: { id: row.userId }, data: { passwordHash: await hashPassword(password), failedLogins: 0, lockedUntil: null } });
  await revokeAllSessions(row.userId);
  await logActivity({ actorId: row.userId, action: "user.password_reset", entityType: "User", entityId: row.userId });
  return { success: "Your password has been updated. You can now sign in." };
}

export async function changePasswordAction(_prev: FormState, form: FormData): Promise<FormState> {
  const me = await requireUser();
  const user = await prisma.user.findUniqueOrThrow({ where: { id: me.id } });
  const current = String(form.get("current") ?? "");
  const password = String(form.get("password") ?? "");
  if (!(await verifyPassword(current, user.passwordHash))) return { errors: { current: "Current password is incorrect." } };
  const problem = passwordProblem(password, user.email);
  if (problem) return { errors: { password: problem } };
  await prisma.user.update({ where: { id: user.id }, data: { passwordHash: await hashPassword(password) } });
  await revokeAllSessions(user.id);
  await createSession(user.id, user.role); // keep this device signed in; others are signed out
  await logActivity({ actorId: user.id, action: "user.password_changed", entityType: "User", entityId: user.id });
  return { success: "Password changed. Other devices have been signed out." };
}

export async function saveAddressAction(_prev: FormState, form: FormData): Promise<FormState> {
  const me = await requireUser("/account/addresses");
  const parsed = validateAddress(form);
  if (!parsed.ok) return { errors: parsed.errors };
  const id = text(form, "id");
  const isDefault = form.get("isDefault") === "on";
  const label = text(form, "label").slice(0, 40) || null;
  await prisma.$transaction(async (tx) => {
    if (isDefault) await tx.address.updateMany({ where: { userId: me.id }, data: { isDefault: false } });
    if (id) {
      // Ownership enforced in the WHERE clause — users can only edit their own addresses.
      const res = await tx.address.updateMany({ where: { id, userId: me.id }, data: { ...parsed.data, label, isDefault } });
      if (res.count !== 1) throw new Error("Address not found");
    } else {
      const count = await tx.address.count({ where: { userId: me.id } });
      if (count >= 10) throw new Error("Address limit reached");
      await tx.address.create({ data: { ...parsed.data, label, isDefault: isDefault || count === 0, userId: me.id } });
    }
  });
  revalidatePath("/account/addresses");
  return { success: "Address saved." };
}

export async function deleteAddressAction(form: FormData): Promise<void> {
  const me = await requireUser("/account/addresses");
  await prisma.address.deleteMany({ where: { id: text(form, "id"), userId: me.id } });
  revalidatePath("/account/addresses");
}

export async function updateProfileAction(_prev: FormState, form: FormData): Promise<FormState> {
  const me = await getCurrentUser();
  if (!me) redirect("/account/login");
  const name = text(form, "name");
  if (name.length < 2 || name.length > 100) return { errors: { name: "Enter your name." } };
  await prisma.user.update({ where: { id: me.id }, data: { name } });
  revalidatePath("/account");
  return { success: "Profile updated." };
}
