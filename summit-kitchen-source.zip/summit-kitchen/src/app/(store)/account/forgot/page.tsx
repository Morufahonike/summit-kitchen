import type { Metadata } from "next";
import { ForgotForm } from "../forms";

export const metadata: Metadata = { title: "Forgot password", robots: { index: false } };

export default function ForgotPage() {
  return (
    <div className="container-site max-w-md py-14">
      <h1 className="text-3xl">Reset your password</h1>
      <p className="mt-2 text-sm text-charcoal-600">Enter your email and we&apos;ll send you a link to choose a new password.</p>
      <div className="mt-6"><ForgotForm /></div>
    </div>
  );
}
