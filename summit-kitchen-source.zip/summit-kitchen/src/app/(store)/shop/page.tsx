import Link from "next/link";
import type { Metadata } from "next";
import { ProductGrid } from "@/components/ProductCard";
import { parseCatalogueParams, toQuery, SORTS } from "@/lib/core/catalogue";
import { listCategories, searchProducts } from "@/lib/server/catalogue";

export const metadata: Metadata = { title: "Shop" };
export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function ShopPage({ searchParams }: Props) {
  const f = parseCatalogueParams(await searchParams);
  const [categories, { products, total, pages }] = await Promise.all([listCategories(), searchProducts(f)]);
  const current = categories.find((c) => c.slug === f.category);
  const title = f.q ? `Results for “${f.q}”` : current?.name ?? "All Products";

  return (
    <div className="container-site py-10">
      <nav className="text-xs text-charcoal-400" aria-label="Breadcrumb">
        <Link href="/" className="hover:text-olive">Home</Link> / <Link href="/shop" className="hover:text-olive">Shop</Link>
        {current && <> / <span>{current.name}</span></>}
      </nav>
      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl">{title}</h1>
          <p className="mt-1 text-sm text-charcoal-400">{total} {total === 1 ? "product" : "products"}</p>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[240px_1fr]">
        {/* Filters: a plain GET form so it works without JavaScript and links are shareable */}
        <aside>
          <details className="group rounded-lg border border-taupe-300 bg-white lg:open:border-transparent lg:border-0 lg:bg-transparent" open>
            <summary className="cursor-pointer list-none px-4 py-3 text-sm font-semibold lg:hidden">Filter &amp; sort</summary>
            <form action="/shop" className="space-y-6 p-4 lg:p-0">
              <div>
                <label htmlFor="s-q" className="label">Search</label>
                <input id="s-q" name="q" type="search" defaultValue={f.q ?? ""} className="input" placeholder="e.g. casserole" />
              </div>
              <fieldset>
                <legend className="label">Category</legend>
                <div className="space-y-1.5 text-sm">
                  <label className="flex items-center gap-2"><input type="radio" name="category" value="" defaultChecked={!f.category} className="accent-olive" /> All</label>
                  {categories.map((c) => (
                    <label key={c.id} className="flex items-center gap-2">
                      <input type="radio" name="category" value={c.slug} defaultChecked={f.category === c.slug} className="accent-olive" />
                      {c.name} <span className="text-charcoal-400">({c._count.products})</span>
                    </label>
                  ))}
                </div>
              </fieldset>
              <fieldset>
                <legend className="label">Price (₦)</legend>
                <div className="flex items-center gap-2">
                  <input name="min" inputMode="numeric" pattern="\d*" aria-label="Minimum price" placeholder="Min" defaultValue={f.minKobo !== null ? f.minKobo / 100 : ""} className="input" />
                  <span>–</span>
                  <input name="max" inputMode="numeric" pattern="\d*" aria-label="Maximum price" placeholder="Max" defaultValue={f.maxKobo !== null ? f.maxKobo / 100 : ""} className="input" />
                </div>
              </fieldset>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" name="inStock" value="1" defaultChecked={f.inStock} className="accent-olive" /> In stock only
              </label>
              <div>
                <label htmlFor="s-sort" className="label">Sort by</label>
                <select id="s-sort" name="sort" defaultValue={f.sort} className="input">
                  {Object.entries(SORTS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div className="flex gap-2">
                <button className="btn-forest flex-1" type="submit">Apply</button>
                <Link href="/shop" className="btn-outline">Clear</Link>
              </div>
            </form>
          </details>
        </aside>

        <section aria-label="Products">
          {products.length === 0 ? (
            <div className="card p-10 text-center">
              <p className="font-serif text-xl">No products match your filters.</p>
              <Link href="/shop" className="btn-link mt-3 inline-block">Clear filters</Link>
            </div>
          ) : (
            <ProductGrid products={products} />
          )}
          {pages > 1 && (
            <nav className="mt-10 flex items-center justify-center gap-2" aria-label="Pagination">
              {f.page > 1 && <Link className="btn-outline" href={`/shop${toQuery(f, { page: f.page - 1 })}`}>Previous</Link>}
              <span className="px-3 text-sm">Page {f.page} of {pages}</span>
              {f.page < pages && <Link className="btn-outline" href={`/shop${toQuery(f, { page: f.page + 1 })}`}>Next</Link>}
            </nav>
          )}
        </section>
      </div>
    </div>
  );
}
