import Link from "next/link";
import type { Metadata } from "next";
import { MountainMark } from "@/components/Logo";

export const metadata: Metadata = { title: "About" };

export default function AboutPage() {
  return (
    <div className="container-site max-w-3xl py-16 text-center">
      <MountainMark className="mx-auto h-10 w-auto" />
      <h1 className="mt-6 text-4xl">Elevating the Art of Everyday Living</h1>
      <div className="rule-gold mt-6" />
      <p className="mt-8 text-lg leading-relaxed text-charcoal-600">
        Summit Kitchen curates premium kitchen and homeware products designed for modern living — chosen for quality,
        functionality and timeless elegance.
      </p>
      <p className="mt-4 text-sm text-charcoal-400">Summit Kitchen Services Limited · RC 9927529</p>
      <Link href="/shop" className="btn-gold mt-10">Shop the Collection</Link>
    </div>
  );
}
