import Link from "next/link";
import type { Metadata } from "next";
import { listCategories } from "@/lib/server/catalogue";

export const metadata: Metadata = { title: "Collections" };
export const dynamic = "force-dynamic";

export default async function CollectionsPage() {
  const categories = await listCategories();
  return (
    <div className="container-site py-12">
      <div className="text-center">
        <h1 className="text-4xl">Collections</h1>
        <div className="rule-gold mt-4" />
      </div>
      <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c) => (
          <li key={c.id}>
            <Link href={`/shop?category=${c.slug}`} className="group card flex items-center gap-5 p-5 hover:border-olive">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={`/images/products/${c.slug}.svg`} alt="" className="h-24 w-24 shrink-0 rounded-lg object-cover" />
              <div>
                <h2 className="text-xl group-hover:text-olive">{c.name}</h2>
                {c.description && <p className="mt-1 text-sm text-charcoal-600">{c.description}</p>}
                <p className="mt-2 text-xs text-charcoal-400">{c._count.products} products</p>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
