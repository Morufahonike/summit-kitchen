import type { Metadata } from "next";
import { TrackForm } from "./TrackForm";

export const metadata: Metadata = { title: "Track an order" };

export default function TrackPage() {
  return (
    <div className="container-site max-w-lg py-14">
      <h1 className="text-3xl">Track an order</h1>
      <p className="mt-2 text-sm text-charcoal-600">Enter your order reference and the email used at checkout.</p>
      <TrackForm />
    </div>
  );
}
