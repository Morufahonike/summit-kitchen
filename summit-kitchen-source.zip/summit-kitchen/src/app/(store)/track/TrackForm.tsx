"use client";
import { useActionState } from "react";
import { trackOrder, type TrackState } from "./actions";
import { SubmitButton } from "@/components/SubmitButton";

export function TrackForm() {
  const [state, action] = useActionState<TrackState, FormData>(trackOrder, null);
  return (
    <>
      <form action={action} className="mt-6 space-y-4">
        {state?.error && <p role="alert" className="alert-error">{state.error}</p>}
        <div>
          <label htmlFor="t-ref" className="label">Order reference</label>
          <input id="t-ref" name="reference" className="input uppercase" placeholder="SK-261021-ABC234" required autoComplete="off" />
        </div>
        <div>
          <label htmlFor="t-email" className="label">Email</label>
          <input id="t-email" name="email" type="email" className="input" required autoComplete="email" />
        </div>
        <SubmitButton className="btn-forest w-full" pendingText="Looking up…">Track order</SubmitButton>
      </form>
      {state?.result && (
        <div className="card mt-8 p-6" role="status">
          <p className="text-sm text-charcoal-400">{state.result.reference}</p>
          <p className="mt-1 font-serif text-2xl">{state.result.status}</p>
          {state.result.tracking && <p className="mt-2 text-sm">Tracking: {state.result.tracking}</p>}
          <p className="mt-4 text-xs text-charcoal-400">For full order details, use the link from your checkout confirmation or sign in.</p>
        </div>
      )}
    </>
  );
}
