"use server";

import { prisma } from "@/lib/server/db";
import { rateLimit } from "@/lib/server/ratelimit";
import { clientIp } from "@/lib/server/request";
import { normaliseEmail } from "@/lib/core/validation";
import { STATUS_LABEL } from "@/lib/core/orders";

export type TrackState = { error?: string; result?: { reference: string; status: string; tracking: string | null } } | null;

/**
 * Guest lookup by reference + email. Returns STATUS ONLY (no address, phone or
 * items) and is rate-limited per IP, so a guessed reference reveals nothing
 * personal. Full details require the private checkout link or signing in.
 */
export async function trackOrder(_prev: TrackState, form: FormData): Promise<TrackState> {
  const ref = String(form.get("reference") ?? "").trim().toUpperCase().slice(0, 30);
  const email = normaliseEmail(String(form.get("email") ?? "")).slice(0, 254);
  if (!(await rateLimit("orderLookup", await clientIp()))) return { error: "Too many lookups. Please try again later." };
  const order = /^SK-\d{6}-[A-Z0-9]{6}$/.test(ref)
    ? await prisma.order.findFirst({ where: { reference: ref, email }, select: { reference: true, status: true, trackingNumber: true, carrier: true } })
    : null;
  if (!order) return { error: "We couldn't find an order with those details." };
  return {
    result: {
      reference: order.reference,
      status: STATUS_LABEL[order.status],
      tracking: order.trackingNumber ? `${order.carrier ? `${order.carrier} — ` : ""}${order.trackingNumber}` : null,
    },
  };
}
