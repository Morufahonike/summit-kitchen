import Link from "next/link";
import type { Metadata } from "next";
import { getCartLines } from "@/lib/server/cart";
import { computeTotals, MAX_QTY_PER_LINE } from "@/lib/core/pricing";
import { formatMoney } from "@/lib/core/money";
import { updateCartItem, removeCartItem } from "./actions";

export const metadata: Metadata = { title: "Your cart" };
export const dynamic = "force-dynamic";

export default async function CartPage() {
  const lines = await getCartLines();
  const totals = computeTotals(lines, [], null); // delivery is chosen at checkout
  const problems = new Map(totals.problems.map((p) => [p.productId, p.problem]));

  if (lines.length === 0) {
    return (
      <div className="container-site py-20 text-center">
        <h1 className="text-3xl">Your cart is empty</h1>
        <p className="mt-3 text-charcoal-600">Discover pieces made for everyday cooking.</p>
        <Link href="/shop" className="btn-gold mt-8">Shop the Collection</Link>
      </div>
    );
  }

  return (
    <div className="container-site py-10">
      <h1 className="text-3xl sm:text-4xl">Your cart</h1>
      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_340px]">
        <ul className="divide-y divide-taupe-300 border-y border-taupe-300">
          {lines.map((l) => (
            <li key={l.productId} className="flex gap-4 py-5">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={l.image ?? "/images/products/accessories.svg"} alt="" className="h-24 w-24 shrink-0 rounded-md object-cover" />
              <div className="flex min-w-0 flex-1 flex-col gap-2 sm:flex-row sm:justify-between">
                <div>
                  <Link href={`/product/${l.slug}`} className="font-medium hover:text-olive">{l.name}</Link>
                  {l.isSample && <span className="badge-sample ml-2 align-middle">Sample</span>}
                  <p className="text-sm text-charcoal-400">{formatMoney(l.unitPriceKobo, l.currency)} each</p>
                  {problems.get(l.productId) && <p className="mt-1 text-sm text-red-700">{problems.get(l.productId)}</p>}
                </div>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-2 sm:flex-col sm:flex-nowrap sm:items-end">
                  <form action={updateCartItem} className="flex items-center gap-2">
                    <input type="hidden" name="productId" value={l.productId} />
                    <label htmlFor={`q-${l.productId}`} className="sr-only">Quantity for {l.name}</label>
                    <input id={`q-${l.productId}`} name="quantity" type="number" min={0} max={MAX_QTY_PER_LINE} defaultValue={l.quantity} className="input h-10 min-h-0 w-20" />
                    <button className="btn-outline min-h-10 px-3 py-1.5" type="submit">Update</button>
                  </form>
                  <form action={removeCartItem}>
                    <input type="hidden" name="productId" value={l.productId} />
                    <button className="text-xs text-charcoal-400 underline hover:text-red-700" type="submit">Remove</button>
                  </form>
                  <p className="ml-auto font-semibold sm:ml-0">{formatMoney(l.unitPriceKobo * l.quantity, l.currency)}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>

        <aside className="card h-fit p-6">
          <h2 className="text-xl">Order summary</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between"><dt>Subtotal</dt><dd className="font-semibold">{formatMoney(totals.subtotalKobo)}</dd></div>
            <div className="flex justify-between text-charcoal-400"><dt>Delivery</dt><dd>Calculated at checkout</dd></div>
          </dl>
          {totals.problems.length > 0 ? (
            <p className="alert-error mt-6">Please fix the items marked above before checking out.</p>
          ) : (
            <Link href="/checkout" className="btn-gold mt-6 w-full">Proceed to checkout</Link>
          )}
          <Link href="/shop" className="btn-link mt-4 block text-center">Continue shopping</Link>
        </aside>
      </div>
    </div>
  );
}
