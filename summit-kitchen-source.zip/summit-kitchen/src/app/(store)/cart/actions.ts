"use server";

import { revalidatePath } from "next/cache";
import { setCartQuantity } from "@/lib/server/cart";
import { parseIntStrict, text } from "@/lib/core/validation";
import { MAX_QTY_PER_LINE } from "@/lib/core/pricing";

export type CartState = { ok?: boolean; error?: string } | null;

export async function addToCart(_prev: CartState, form: FormData): Promise<CartState> {
  const productId = text(form, "productId");
  const qty = parseIntStrict(text(form, "quantity") || "1", 1, MAX_QTY_PER_LINE);
  if (qty === null) return { error: `Choose a quantity between 1 and ${MAX_QTY_PER_LINE}.` };
  const res = await setCartQuantity(productId, qty, "add");
  revalidatePath("/", "layout");
  return res.ok ? { ok: true } : { error: res.error };
}

export async function updateCartItem(form: FormData): Promise<void> {
  const productId = text(form, "productId");
  const qty = parseIntStrict(text(form, "quantity"), 0, MAX_QTY_PER_LINE);
  if (qty === null) return;
  await setCartQuantity(productId, qty, "set");
  revalidatePath("/", "layout");
}

export async function removeCartItem(form: FormData): Promise<void> {
  await setCartQuantity(text(form, "productId"), 0, "set");
  revalidatePath("/", "layout");
}
