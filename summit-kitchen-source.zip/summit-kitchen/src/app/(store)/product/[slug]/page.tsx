import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getProduct, relatedProducts } from "@/lib/server/catalogue";
import { Price, ProductGrid } from "@/components/ProductCard";
import { AddToCart } from "@/components/AddToCart";
import { MAX_QTY_PER_LINE } from "@/lib/core/pricing";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getProduct((await params).slug);
  return p ? { title: p.name, description: p.description.slice(0, 155) } : { title: "Not found" };
}

export default async function ProductPage({ params }: Props) {
  const p = await getProduct((await params).slug);
  if (!p) notFound();
  const related = await relatedProducts(p.categoryId, p.id);
  const lowStock = p.stock > 0 && p.stock <= 5;

  return (
    <div className="container-site py-10">
      <nav className="text-xs text-charcoal-400" aria-label="Breadcrumb">
        <Link href="/" className="hover:text-olive">Home</Link> / <Link href="/shop" className="hover:text-olive">Shop</Link> /{" "}
        <Link href={`/shop?category=${p.category.slug}`} className="hover:text-olive">{p.category.name}</Link>
      </nav>

      <div className="mt-6 grid gap-10 md:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-xl bg-ivory-200">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={p.image ?? "/images/products/accessories.svg"} alt={`${p.name} (placeholder image)`} className="h-full w-full object-cover" />
        </div>

        <div>
          {p.isSample && (
            <p className="alert-info mb-4">
              <strong>Sample product.</strong> This listing, its price and stock are placeholders until our supplier range is confirmed.
            </p>
          )}
          <p className="eyebrow">{p.category.name}</p>
          <h1 className="mt-2 text-3xl leading-tight sm:text-4xl">{p.name}</h1>
          <Price priceKobo={p.priceKobo} compareAtKobo={p.compareAtKobo} currency={p.currency} className="mt-4 text-xl" />
          <p className={`mt-2 text-sm ${p.stock <= 0 ? "text-red-700" : lowStock ? "text-gold-600" : "text-olive"}`}>
            {p.stock <= 0 ? "Out of stock" : lowStock ? `Only ${p.stock} left` : "In stock"}
          </p>
          <p className="mt-6 leading-relaxed text-charcoal-600">{p.description}</p>

          <div className="mt-8">
            <AddToCart productId={p.id} maxQty={Math.min(p.stock, MAX_QTY_PER_LINE)} disabled={p.stock <= 0} />
          </div>

          <dl className="mt-8 grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 border-t border-taupe-300 pt-6 text-sm">
            <dt className="text-charcoal-400">SKU</dt><dd>{p.sku}</dd>
            {p.material && <><dt className="text-charcoal-400">Material</dt><dd>{p.material}</dd></>}
            {p.colour && <><dt className="text-charcoal-400">Colour</dt><dd>{p.colour}</dd></>}
            <dt className="text-charcoal-400">Delivery</dt><dd>Fee calculated at checkout by state</dd>
          </dl>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-16" aria-labelledby="rel-h">
          <h2 id="rel-h" className="mb-6 text-2xl">You may also like</h2>
          <ProductGrid products={related} />
        </section>
      )}
    </div>
  );
}
