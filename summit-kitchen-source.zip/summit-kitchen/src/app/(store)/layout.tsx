import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export default function StoreLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-white focus:px-4 focus:py-2">
        Skip to content
      </a>
      <div className="bg-forest py-2 text-center text-xs text-ivory/90">
        Preview store — products and prices shown are <strong className="text-gold">samples</strong>. Payments run in test mode.
      </div>
      <Header />
      <main id="main">{children}</main>
      <Footer />
    </>
  );
}
