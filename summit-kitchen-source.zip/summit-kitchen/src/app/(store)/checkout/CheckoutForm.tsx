"use client";
import { useActionState } from "react";
import { checkoutAction, type CheckoutState } from "./actions";
import { AddressFields, Field, FormMessage } from "@/components/Field";
import { SubmitButton } from "@/components/SubmitButton";

export function CheckoutForm({ defaults, disabled }: { defaults: Record<string, string | null>; disabled: boolean }) {
  const [state, action] = useActionState<CheckoutState, FormData>(checkoutAction, null);
  const values = state?.values ?? defaults;
  const errors = state?.errors ?? {};
  return (
    <form action={action} className="space-y-8" noValidate>
      <FormMessage error={state?.error ?? (Object.keys(errors).length ? "Please check the highlighted fields." : null)} />
      <fieldset className="space-y-4">
        <legend className="font-serif text-xl">Contact</legend>
        <Field name="email" label="Email" type="email" inputMode="email" autoComplete="email" required error={errors.email} defaultValue={values.email} />
      </fieldset>
      <fieldset className="space-y-4">
        <legend className="font-serif text-xl">Delivery address</legend>
        <AddressFields errors={errors} values={values} />
        <div>
          <label htmlFor="f-note" className="label">Delivery note (optional)</label>
          <textarea id="f-note" name="note" rows={2} maxLength={500} className="input" defaultValue={values.note ?? ""} />
        </div>
      </fieldset>
      <div className="space-y-3">
        <SubmitButton className="btn-gold w-full" pendingText="Placing order…" disabled={disabled}>{disabled ? "Checkout unavailable" : "Continue to secure payment"}</SubmitButton>
        <p className="text-center text-xs text-charcoal-400">You&apos;ll be redirected to Paystack to pay by card (Mastercard, Visa, Verve). We never see or store your card details.</p>
      </div>
    </form>
  );
}
