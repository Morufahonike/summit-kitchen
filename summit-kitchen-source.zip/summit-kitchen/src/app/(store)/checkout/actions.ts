"use server";

import { redirect } from "next/navigation";
import { validateCheckout } from "@/lib/core/validation";
import { getCurrentUser } from "@/lib/server/session";
import { canViewOrder, placeOrder } from "@/lib/server/checkout";
import { prisma } from "@/lib/server/db";
import { startPayment } from "@/lib/server/payments";
import { rateLimit } from "@/lib/server/ratelimit";
import { clientIp } from "@/lib/server/request";

export type CheckoutState = { error?: string; errors?: Record<string, string>; values?: Record<string, string> } | null;

export async function checkoutAction(_prev: CheckoutState, form: FormData): Promise<CheckoutState> {
  const values = Object.fromEntries(
    ["email", "fullName", "phone", "line1", "line2", "city", "state", "note"].map((k) => [k, String(form.get(k) ?? "").slice(0, 500)]),
  );
  const parsed = validateCheckout(form);
  if (!parsed.ok) return { errors: parsed.errors, values };

  if (!(await rateLimit("checkout", await clientIp()))) {
    return { error: "Too many checkout attempts. Please wait a while and try again.", values };
  }

  const user = await getCurrentUser();
  const placed = await placeOrder(parsed.data, user?.id ?? null);
  if (!placed.ok) return { error: placed.error, values };

  const pay = await startPayment(placed.orderId, placed.accessToken);
  if (!pay.ok) {
    redirect(`/orders/${placed.reference}?t=${encodeURIComponent(placed.accessToken)}&notice=${encodeURIComponent(pay.error)}`);
  }
  redirect(pay.url); // Paystack hosted checkout (card details are entered on Paystack, never on our site)
}

/** Retry payment for an existing pending order (owner or link holder). */
export async function retryPaymentAction(form: FormData): Promise<void> {
  const reference = String(form.get("reference") ?? "").slice(0, 30);
  const token = String(form.get("t") ?? "").slice(0, 100);
  const order = await prisma.order.findUnique({ where: { reference } });
  const user = await getCurrentUser();
  if (!order || !canViewOrder(order, user, token)) redirect("/");
  const pay = await startPayment(order.id, token);
  if (!pay.ok) redirect(`/orders/${reference}?t=${encodeURIComponent(token)}&notice=${encodeURIComponent(pay.error)}`);
  redirect(pay.url);
}
