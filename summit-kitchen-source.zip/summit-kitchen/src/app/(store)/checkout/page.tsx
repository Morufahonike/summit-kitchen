import Link from "next/link";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { getCartLines } from "@/lib/server/cart";
import { activeZones } from "@/lib/server/checkout";
import { getCurrentUser } from "@/lib/server/session";
import { paymentsConfigured } from "@/lib/server/payments";
import { prisma } from "@/lib/server/db";
import { computeTotals } from "@/lib/core/pricing";
import { formatMoney } from "@/lib/core/money";
import { CheckoutForm } from "./CheckoutForm";

export const metadata: Metadata = { title: "Checkout", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function CheckoutPage() {
  const lines = await getCartLines();
  if (lines.length === 0) redirect("/cart");
  const [zones, user] = await Promise.all([activeZones(), getCurrentUser()]);
  const totals = computeTotals(lines, zones, null);
  if (totals.problems.length) redirect("/cart");
  const pay = paymentsConfigured();

  const address = user ? await prisma.address.findFirst({ where: { userId: user.id }, orderBy: [{ isDefault: "desc" }, { createdAt: "desc" }] }) : null;
  const defaults = {
    email: user?.email ?? "", fullName: address?.fullName ?? user?.name ?? "", phone: address?.phone ?? "",
    line1: address?.line1 ?? "", line2: address?.line2 ?? "", city: address?.city ?? "", state: address?.state ?? "", note: "",
  };

  return (
    <div className="container-site py-10">
      <h1 className="text-3xl sm:text-4xl">Checkout</h1>
      {!user && (
        <p className="mt-2 text-sm text-charcoal-600">
          Have an account? <Link href="/account/login?next=/checkout" className="btn-link">Sign in</Link> for faster checkout and order history.
        </p>
      )}

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          {zones.length === 0 && (
            <p className="alert-info">
              <strong>Delivery rates are not configured yet.</strong> You can review your order, but orders can&apos;t be placed until delivery pricing is set up.
            </p>
          )}
          {pay.mode === "test" && <p className="alert-info"><strong>Test mode:</strong> no real money will be taken. Use Paystack test cards only.</p>}
          {!pay.ok && <p className="alert-info">Online payment isn&apos;t configured on this environment yet.</p>}
          <CheckoutForm defaults={defaults} disabled={zones.length === 0} />
        </div>

        <aside className="card h-fit p-6">
          <h2 className="text-xl">Order summary</h2>
          <ul className="mt-4 divide-y divide-taupe-300/60 text-sm">
            {totals.lines.map((l) => (
              <li key={l.productId} className="flex justify-between gap-4 py-2">
                <span>{l.name} <span className="text-charcoal-400">× {l.quantity}</span></span>
                <span className="shrink-0">{formatMoney(l.lineTotalKobo)}</span>
              </li>
            ))}
          </ul>
          <dl className="mt-4 space-y-2 border-t border-taupe-300 pt-4 text-sm">
            <div className="flex justify-between"><dt>Subtotal</dt><dd className="font-semibold">{formatMoney(totals.subtotalKobo)}</dd></div>
            <div className="flex justify-between text-charcoal-400"><dt>Delivery</dt><dd>By state (see below)</dd></div>
          </dl>
          {zones.length > 0 && (
            <div className="mt-4 rounded-md bg-ivory p-3 text-xs">
              <p className="font-semibold">Delivery fees</p>
              <ul className="mt-1 space-y-1">
                {zones.map((z) => (
                  <li key={z.id} className="flex justify-between gap-2"><span>{z.name}: {z.states.join(", ")}</span><span>{formatMoney(z.feeKobo)}</span></li>
                ))}
              </ul>
              <p className="mt-2 text-charcoal-400">Your final total is confirmed before payment.</p>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
