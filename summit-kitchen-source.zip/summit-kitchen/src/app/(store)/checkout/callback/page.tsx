import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { confirmPayment, type ConfirmResult } from "@/lib/server/payments";
import { canViewOrder } from "@/lib/server/checkout";
import { getCurrentUser } from "@/lib/server/session";

export const metadata: Metadata = { title: "Payment status", robots: { index: false } };
export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

const MESSAGES: Record<ConfirmResult | "error", { title: string; body: string; tone: "ok" | "info" | "error" }> = {
  paid: { title: "Thank you — payment received", body: "Your order is confirmed. We'll prepare it for delivery.", tone: "ok" },
  already_paid: { title: "Payment already confirmed", body: "This order is paid. No further action is needed.", tone: "ok" },
  pending: { title: "Payment is processing", body: "We haven't received confirmation yet. This page will reflect the update once Paystack confirms.", tone: "info" },
  failed: { title: "Payment was not completed", body: "No money has been taken for this attempt. You can try again from your order page.", tone: "error" },
  needs_review: { title: "We've received your payment", body: "Our team needs to review this order and will contact you shortly.", tone: "info" },
  unknown_reference: { title: "We couldn't find that payment", body: "Please check your order page or contact us.", tone: "error" },
  error: { title: "We couldn't confirm your payment right now", body: "If you were charged, your order will update automatically once Paystack notifies us.", tone: "info" },
};

export default async function CallbackPage({ searchParams }: Props) {
  const sp = await searchParams;
  const str = (k: string) => (typeof sp[k] === "string" ? (sp[k] as string) : "");
  const orderRef = str("order");
  const token = str("t");
  const paymentRef = str("reference") || str("trxref");

  const order = orderRef ? await prisma.order.findUnique({ where: { reference: orderRef } }) : null;
  const user = await getCurrentUser();
  if (!order || !canViewOrder(order, user, token)) {
    return <Result r={MESSAGES.unknown_reference} />;
  }

  let result: ConfirmResult | "error" = "unknown_reference";
  const payment = paymentRef ? await prisma.payment.findUnique({ where: { reference: paymentRef } }) : null;
  if (payment && payment.orderId === order.id) {
    try {
      result = await confirmPayment(payment.reference, "callback");
    } catch (e) {
      console.error("[paystack] callback verify failed:", (e as Error).message);
      result = "error";
    }
  }
  const orderUrl = `/orders/${order.reference}${token ? `?t=${encodeURIComponent(token)}` : ""}`;
  return <Result r={MESSAGES[result]} reference={order.reference} orderUrl={orderUrl} />;
}

function Result({ r, reference, orderUrl }: { r: (typeof MESSAGES)[keyof typeof MESSAGES]; reference?: string; orderUrl?: string }) {
  return (
    <div className="container-site max-w-xl py-20 text-center">
      <h1 className="text-3xl">{r.title}</h1>
      <p className={`mt-6 ${r.tone === "ok" ? "alert-ok" : r.tone === "error" ? "alert-error" : "alert-info"}`}>{r.body}</p>
      {reference && <p className="mt-6 text-sm">Order reference: <strong className="tracking-wider">{reference}</strong></p>}
      <div className="mt-8 flex justify-center gap-3">
        {orderUrl && <Link href={orderUrl} className="btn-gold">View order</Link>}
        <Link href="/shop" className="btn-outline">Continue shopping</Link>
      </div>
    </div>
  );
}
