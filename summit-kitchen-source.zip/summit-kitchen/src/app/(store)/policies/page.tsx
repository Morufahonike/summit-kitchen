import type { Metadata } from "next";

export const metadata: Metadata = { title: "Delivery & returns" };

// PLACEHOLDER: the business has not yet supplied delivery rates, a returns
// policy, tax treatment or terms of sale. Nothing here is invented — replace
// with approved, legally reviewed text before launch.
export default function PoliciesPage() {
  return (
    <div className="container-site max-w-3xl py-14">
      <h1 className="text-4xl">Delivery &amp; returns</h1>
      <p className="alert-info mt-6">
        Our delivery, returns and refund policies are being finalised and will be published here before launch.
      </p>
      <section className="mt-10 space-y-3">
        <h2 className="text-2xl">Delivery</h2>
        <p className="text-charcoal-600">Delivery fees are calculated by state at checkout. Delivery timelines will be confirmed with each order.</p>
      </section>
      <section className="mt-10 space-y-3">
        <h2 className="text-2xl">Returns</h2>
        <p className="text-charcoal-600">Returns policy to be confirmed.</p>
      </section>
      <section className="mt-10 space-y-3">
        <h2 className="text-2xl">Payments</h2>
        <p className="text-charcoal-600">Card payments (Mastercard, Visa, Verve) are processed securely by Paystack. We never see or store your full card details.</p>
      </section>
    </div>
  );
}
