import type { Metadata, Viewport } from "next";
import { Playfair_Display, Montserrat } from "next/font/google";
import "./globals.css";

// Brand typography: Playfair Display (headings), Montserrat (body).
// next/font downloads these at BUILD time and self-hosts them.
const playfair = Playfair_Display({ subsets: ["latin"], variable: "--font-playfair", display: "swap" });
const montserrat = Montserrat({ subsets: ["latin"], variable: "--font-montserrat", display: "swap" });

export const metadata: Metadata = {
  title: { default: "Summit Kitchen — Elevating the Art of Everyday Living", template: "%s | Summit Kitchen" },
  description: "Premium kitchen and homeware products designed for modern living. Thoughtfully curated for quality, functionality and timeless elegance.",
  icons: { icon: "/images/icon.svg" },
};

export const viewport: Viewport = { themeColor: "#FAF8F2", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-NG" className={`${playfair.variable} ${montserrat.variable}`}>
      <body className="min-h-screen">{children}</body>
    </html>
  );
}
