"use client";

// Generic error boundary: never shows stack traces or internal messages to customers.
export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="container-site flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
      <h1 className="text-3xl">Something went wrong</h1>
      <p className="mt-3 text-charcoal-600">Please try again. If the problem continues, contact us.</p>
      <button onClick={reset} className="btn-gold mt-8" type="button">Try again</button>
    </main>
  );
}
