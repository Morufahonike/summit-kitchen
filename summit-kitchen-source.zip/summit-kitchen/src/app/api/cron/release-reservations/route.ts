import { NextResponse } from "next/server";
import { env } from "@/lib/server/env";
import { releaseExpiredReservations } from "@/lib/server/inventory";
import { safeEqualHex, sha256 } from "@/lib/core/crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Releases stock held by unpaid orders past their payment window.
 * Call from a scheduler with header `Authorization: Bearer <CRON_SECRET>`.
 * (Expired reservations are also released opportunistically at checkout and
 * when admins open the dashboard, so this is a backstop.)
 */
export async function POST(req: Request): Promise<Response> {
  const secret = env.cronSecret;
  const given = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  if (!secret || !safeEqualHex(sha256(given), sha256(secret))) {
    return new NextResponse("Unauthorized", { status: 401 });
  }
  const released = await releaseExpiredReservations();
  return NextResponse.json({ released });
}
