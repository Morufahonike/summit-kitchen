import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { verifyWebhookSignature } from "@/lib/core/paystack";
import { sha256 } from "@/lib/core/crypto";
import { confirmPayment } from "@/lib/server/payments";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BODY = 64 * 1024;

/**
 * Paystack webhook. Order of checks:
 *  1. size limit; 2. HMAC-SHA512 signature over the RAW body; 3. dedupe by body hash
 *  (Paystack retries); 4. re-verify via Paystack API inside confirmPayment()
 *  (amount/currency/reference must match our records) before marking paid.
 */
export async function POST(req: Request): Promise<Response> {
  const secret = env.paystackSecret;
  if (!secret) return new NextResponse("Not configured", { status: 503 });

  const raw = await req.text();
  if (raw.length > MAX_BODY) return new NextResponse("Payload too large", { status: 413 });
  if (!verifyWebhookSignature(raw, req.headers.get("x-paystack-signature"), secret)) {
    return new NextResponse("Invalid signature", { status: 401 });
  }

  let event: { event?: string; data?: { reference?: string } };
  try {
    event = JSON.parse(raw);
  } catch {
    return new NextResponse("Bad JSON", { status: 400 });
  }
  const type = String(event.event ?? "unknown").slice(0, 60);
  const reference = typeof event.data?.reference === "string" ? event.data.reference.slice(0, 100) : null;

  const dedupeKey = sha256(raw);
  try {
    await prisma.webhookEvent.create({ data: { provider: "PAYSTACK", dedupeKey, eventType: type, reference } });
  } catch {
    const prev = await prisma.webhookEvent.findUnique({ where: { dedupeKey } });
    if (prev?.processedAt) return NextResponse.json({ received: true, duplicate: true });
    // Seen before but not processed (earlier failure) — fall through and retry processing.
  }

  try {
    if (type === "charge.success" && reference) {
      const result = await confirmPayment(reference, "webhook");
      if (result === "pending") {
        // Not yet final at Paystack — leave unprocessed and ask Paystack to retry later.
        await prisma.webhookEvent.update({ where: { dedupeKey }, data: { error: "pending" } });
        return new NextResponse("Pending", { status: 503 });
      }
      await prisma.webhookEvent.update({ where: { dedupeKey }, data: { processedAt: new Date(), error: result === "paid" || result === "already_paid" ? null : result } });
    } else {
      await prisma.webhookEvent.update({ where: { dedupeKey }, data: { processedAt: new Date(), error: "ignored event" } });
    }
    return NextResponse.json({ received: true });
  } catch (e) {
    const msg = (e as Error).message.slice(0, 300);
    await prisma.webhookEvent.update({ where: { dedupeKey }, data: { error: msg } }).catch(() => undefined);
    console.error("[paystack] webhook processing failed:", msg);
    return new NextResponse("Processing error", { status: 500 }); // Paystack will retry
  }
}
