import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { formatMoney } from "@/lib/core/money";
import { ORDER_STATUSES, STATUS_LABEL, isOrderStatus } from "@/lib/core/orders";

export const metadata: Metadata = { title: "Orders" };
export const dynamic = "force-dynamic";

export default async function AdminOrders({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  const sp = await searchParams;
  const status = sp.status && isOrderStatus(sp.status) ? sp.status : null;
  const q = (sp.q ?? "").trim().slice(0, 80);
  const orders = await prisma.order.findMany({
    where: {
      ...(status && { status }),
      ...(q && { OR: [{ reference: { contains: q, mode: "insensitive" as const } }, { email: { contains: q, mode: "insensitive" as const } }, { shippingName: { contains: q, mode: "insensitive" as const } }] }),
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Orders</h1>
      <form className="flex flex-wrap gap-2">
        <label htmlFor="os" className="sr-only">Status</label>
        <select id="os" name="status" defaultValue={status ?? ""} className="input w-auto">
          <option value="">All statuses</option>
          {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
        </select>
        <label htmlFor="oq" className="sr-only">Search</label>
        <input id="oq" name="q" defaultValue={q} placeholder="Reference, email or name" className="input w-64" />
        <button className="btn-outline" type="submit">Filter</button>
      </form>
      <div className="card overflow-x-auto">
        <table className="table min-w-[720px]">
          <thead><tr><th>Reference</th><th>Date</th><th>Customer</th><th>State</th><th>Status</th><th className="text-right">Total</th></tr></thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td><Link href={`/admin/orders/${o.id}`} className="font-medium hover:text-olive">{o.reference}</Link></td>
                <td>{o.createdAt.toLocaleString("en-NG", { timeZone: "Africa/Lagos", dateStyle: "short", timeStyle: "short" })}</td>
                <td>{o.shippingName}<br /><span className="text-xs text-charcoal-400">{o.email}</span></td>
                <td>{o.state}</td>
                <td>{STATUS_LABEL[o.status]}</td>
                <td className="text-right">{formatMoney(o.totalKobo, o.currency)}</td>
              </tr>
            ))}
            {orders.length === 0 && <tr><td colSpan={6} className="text-charcoal-400">No orders found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
