import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { formatMoney } from "@/lib/core/money";
import { STATUS_LABEL, adminNextStatuses } from "@/lib/core/orders";
import { OrderStatusForm, TrackingForm } from "../../AdminForms";

export const metadata: Metadata = { title: "Order" };
export const dynamic = "force-dynamic";

const fmt = (d: Date) => d.toLocaleString("en-NG", { timeZone: "Africa/Lagos", dateStyle: "medium", timeStyle: "short" });

export default async function AdminOrder({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = await prisma.order.findUnique({
    where: { id },
    include: {
      items: true, payments: { orderBy: { createdAt: "desc" } }, events: { orderBy: { createdAt: "asc" } },
      user: { select: { id: true, email: true } }, deliveryZone: { select: { name: true } },
    },
  });
  if (!order) notFound();
  const flags = await prisma.activityLog.findMany({ where: { entityId: order.id, action: { in: ["payment.needs_review", "payment.mismatch"] } } });

  return (
    <div className="max-w-5xl space-y-6">
      <Link href="/admin/orders" className="btn-link">← Orders</Link>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl tracking-wide">{order.reference}</h1>
        <span className="badge bg-sage-50 text-olive">{STATUS_LABEL[order.status]}</span>
      </div>
      {flags.map((f) => <p key={f.id} className="alert-error">Needs review: {JSON.stringify(f.details)}</p>)}

      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <div className="min-w-0 space-y-6">
          <section className="card overflow-x-auto p-5">
            <h2 className="text-xl">Items</h2>
            <table className="table mt-3 min-w-[480px]">
              <thead><tr><th>Item</th><th>SKU</th><th className="text-right">Qty</th><th className="text-right">Line total</th></tr></thead>
              <tbody>
                {order.items.map((i) => (
                  <tr key={i.id}><td>{i.nameSnapshot}</td><td className="font-mono text-xs">{i.skuSnapshot}</td><td className="text-right">{i.quantity}</td><td className="text-right">{formatMoney(i.lineTotalKobo, order.currency)}</td></tr>
                ))}
              </tbody>
            </table>
            <dl className="mt-4 space-y-1 text-sm">
              <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatMoney(order.subtotalKobo, order.currency)}</dd></div>
              <div className="flex justify-between"><dt>Delivery ({order.deliveryZone?.name ?? "zone removed"})</dt><dd>{formatMoney(order.deliveryKobo, order.currency)}</dd></div>
              <div className="flex justify-between font-semibold"><dt>Total</dt><dd>{formatMoney(order.totalKobo, order.currency)}</dd></div>
            </dl>
          </section>

          <section className="card overflow-x-auto p-5">
            <h2 className="text-xl">Payments</h2>
            <table className="table mt-3 min-w-[560px]">
              <thead><tr><th>Reference</th><th>Status</th><th>Mode</th><th>Card</th><th className="text-right">Amount</th></tr></thead>
              <tbody>
                {order.payments.map((p) => (
                  <tr key={p.id}>
                    <td className="font-mono text-xs">{p.reference}</td>
                    <td>{p.status}{p.gatewayResponse ? <span className="block text-xs text-charcoal-400">{p.gatewayResponse}</span> : null}</td>
                    <td>{p.mode}</td>
                    <td>{p.cardBrand ? `${p.cardBrand} •••• ${p.cardLast4 ?? ""}` : "—"}</td>
                    <td className="text-right">{formatMoney(p.amountKobo, p.currency)}</td>
                  </tr>
                ))}
                {order.payments.length === 0 && <tr><td colSpan={5} className="text-charcoal-400">No payment attempts.</td></tr>}
              </tbody>
            </table>
          </section>

          <section className="card p-5">
            <h2 className="text-xl">History</h2>
            <ol className="mt-3 space-y-2 text-sm">
              {order.events.map((e) => (
                <li key={e.id}><span className="text-charcoal-400">{fmt(e.createdAt)}</span> — <strong>{STATUS_LABEL[e.status]}</strong>{e.note ? `: ${e.note}` : ""}</li>
              ))}
            </ol>
          </section>
        </div>

        <div className="min-w-0 space-y-6">
          <section className="card p-5"><h2 className="mb-3 text-xl">Status</h2><OrderStatusForm id={order.id} next={adminNextStatuses(order.status)} /></section>
          <section className="card p-5"><h2 className="mb-3 text-xl">Tracking</h2><TrackingForm id={order.id} carrier={order.carrier} trackingNumber={order.trackingNumber} /></section>
          <section className="card p-5 text-sm">
            <h2 className="text-xl">Customer</h2>
            <p className="mt-2">{order.shippingName}</p>
            <p>{order.email}{order.user ? " (account)" : " (guest)"}</p>
            <p>{order.phone}</p>
            <address className="mt-2 not-italic">{order.line1}{order.line2 ? `, ${order.line2}` : ""}<br />{order.city}, {order.state}</address>
            {order.customerNote && <p className="mt-2 rounded bg-ivory p-2">Note: {order.customerNote}</p>}
          </section>
        </div>
      </div>
    </div>
  );
}
