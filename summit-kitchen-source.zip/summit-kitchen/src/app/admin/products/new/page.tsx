import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { ProductForm } from "../../AdminForms";

export const metadata: Metadata = { title: "New product" };
export const dynamic = "force-dynamic";

export default async function NewProduct() {
  const categories = await prisma.category.findMany({ orderBy: { sortOrder: "asc" }, select: { id: true, name: true } });
  return (
    <div className="max-w-3xl space-y-6">
      <Link href="/admin/products" className="btn-link">← Products</Link>
      <h1 className="text-3xl">New product</h1>
      <div className="card p-6"><ProductForm values={{ isSample: true, isActive: true }} categories={categories} /></div>
    </div>
  );
}
