import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { getCurrentUser } from "@/lib/server/session";
import { minorToMajorString } from "@/lib/core/money";
import { ProductForm, StockForm } from "../../AdminForms";
import { archiveProductAction } from "../../actions";

export const metadata: Metadata = { title: "Edit product" };
export const dynamic = "force-dynamic";

export default async function EditProduct({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }> }) {
  const { id } = await params;
  const [product, categories, movements, me] = await Promise.all([
    prisma.product.findUnique({ where: { id } }),
    prisma.category.findMany({ orderBy: { sortOrder: "asc" }, select: { id: true, name: true } }),
    prisma.inventoryMovement.findMany({ where: { productId: id }, orderBy: { createdAt: "desc" }, take: 15 }),
    getCurrentUser(),
  ]);
  if (!product) notFound();
  const created = (await searchParams).created;

  return (
    <div className="max-w-4xl space-y-6">
      <Link href="/admin/products" className="btn-link">← Products</Link>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl">{product.name}</h1>
        {product.isActive && <Link href={`/product/${product.slug}`} className="btn-link">View in store</Link>}
      </div>
      {created && <p className="alert-ok">Product created.</p>}
      <div className="card p-6">
        <ProductForm
          categories={categories}
          values={{
            id: product.id, name: product.name, slug: product.slug, sku: product.sku, description: product.description,
            categoryId: product.categoryId, price: minorToMajorString(product.priceKobo),
            compareAt: product.compareAtKobo ? minorToMajorString(product.compareAtKobo) : "",
            material: product.material, colour: product.colour, image: product.image,
            isActive: product.isActive, isFeatured: product.isFeatured, isBestseller: product.isBestseller, isSample: product.isSample,
          }}
        />
      </div>

      <section className="card p-6">
        <h2 className="text-xl">Stock: {product.stock}</h2>
        <div className="mt-3"><StockForm productId={product.id} /></div>
        <table className="table mt-4">
          <thead><tr><th>When</th><th>Change</th><th>Reason</th><th>Note</th></tr></thead>
          <tbody>
            {movements.map((m) => (
              <tr key={m.id}>
                <td>{m.createdAt.toLocaleString("en-NG", { timeZone: "Africa/Lagos" })}</td>
                <td className={m.delta > 0 ? "text-olive" : "text-red-700"}>{m.delta > 0 ? `+${m.delta}` : m.delta}</td>
                <td>{m.reason.replace("_", " ").toLowerCase()}</td>
                <td>{m.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {me?.role === "ADMIN" && product.isActive && (
        <form action={archiveProductAction} className="card border-red-200 p-6">
          <input type="hidden" name="id" value={product.id} />
          <h2 className="text-xl">Archive product</h2>
          <p className="mt-1 text-sm text-charcoal-600">Hides the product from the store and removes it from carts. Order history is kept.</p>
          <button className="btn-danger mt-4" type="submit">Archive</button>
        </form>
      )}
    </div>
  );
}
