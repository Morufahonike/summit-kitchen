import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { formatMoney } from "@/lib/core/money";

export const metadata: Metadata = { title: "Products" };
export const dynamic = "force-dynamic";

export default async function AdminProducts({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const q = ((await searchParams).q ?? "").trim().slice(0, 80);
  const products = await prisma.product.findMany({
    where: q ? { OR: [{ name: { contains: q, mode: "insensitive" } }, { sku: { contains: q, mode: "insensitive" } }] } : {},
    include: { category: { select: { name: true } } },
    orderBy: [{ isActive: "desc" }, { name: "asc" }],
    take: 200,
  });
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl">Products</h1>
        <Link href="/admin/products/new" className="btn-gold">Add product</Link>
      </div>
      <form className="flex max-w-md gap-2">
        <label htmlFor="pq" className="sr-only">Search products</label>
        <input id="pq" name="q" defaultValue={q} placeholder="Search name or SKU" className="input" />
        <button className="btn-outline" type="submit">Search</button>
      </form>
      <div className="card overflow-x-auto">
        <table className="table min-w-[720px]">
          <thead><tr><th>Product</th><th>SKU</th><th>Category</th><th className="text-right">Price</th><th className="text-right">Stock</th><th>Status</th></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>
                  <Link href={`/admin/products/${p.id}`} className="font-medium hover:text-olive">{p.name}</Link>
                  {p.isSample && <span className="badge-sample ml-2">Sample</span>}
                </td>
                <td className="font-mono text-xs">{p.sku}</td>
                <td>{p.category.name}</td>
                <td className="text-right">{formatMoney(p.priceKobo, p.currency)}</td>
                <td className={`text-right ${p.stock === 0 ? "font-semibold text-red-700" : ""}`}>{p.stock}</td>
                <td>{p.isActive ? "Visible" : <span className="text-charcoal-400">Hidden</span>}</td>
              </tr>
            ))}
            {products.length === 0 && <tr><td colSpan={6} className="text-charcoal-400">No products found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
