import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";

export const metadata: Metadata = { title: "Activity" };
export const dynamic = "force-dynamic";

export default async function AdminActivity({ searchParams }: { searchParams: Promise<{ action?: string }> }) {
  const action = ((await searchParams).action ?? "").replace(/[^a-z._]/g, "").slice(0, 40);
  const logs = await prisma.activityLog.findMany({
    where: action ? { action: { startsWith: action } } : {},
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { actor: { select: { email: true } } },
  });
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Activity log</h1>
      <form className="flex max-w-md gap-2">
        <label htmlFor="aq" className="sr-only">Filter by action</label>
        <input id="aq" name="action" defaultValue={action} placeholder="e.g. order, payment, admin.login" className="input" />
        <button className="btn-outline" type="submit">Filter</button>
      </form>
      <div className="card overflow-x-auto">
        <table className="table min-w-[760px]">
          <thead><tr><th>When</th><th>Who</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr></thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id}>
                <td className="whitespace-nowrap">{l.createdAt.toLocaleString("en-NG", { timeZone: "Africa/Lagos", dateStyle: "short", timeStyle: "medium" })}</td>
                <td>{l.actor?.email ?? <span className="text-charcoal-400">system</span>}</td>
                <td className="font-mono text-xs">{l.action}</td>
                <td className="text-xs">{l.entityType}{l.entityId ? ` ${l.entityId.slice(0, 10)}…` : ""}</td>
                <td className="max-w-xs break-words font-mono text-[11px] text-charcoal-600">{l.details ? JSON.stringify(l.details) : ""}</td>
                <td className="text-xs">{l.ip}</td>
              </tr>
            ))}
            {logs.length === 0 && <tr><td colSpan={6} className="text-charcoal-400">No activity yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
