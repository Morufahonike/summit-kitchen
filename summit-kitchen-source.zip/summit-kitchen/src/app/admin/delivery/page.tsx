import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { getCurrentUser } from "@/lib/server/session";
import { formatMoney, minorToMajorString } from "@/lib/core/money";
import { ZoneForm } from "../AdminForms";

export const metadata: Metadata = { title: "Delivery" };
export const dynamic = "force-dynamic";

export default async function AdminDelivery() {
  const [zones, me] = await Promise.all([prisma.deliveryZone.findMany({ orderBy: { name: "asc" } }), getCurrentUser()]);
  const isAdmin = me?.role === "ADMIN";
  return (
    <div className="max-w-4xl space-y-6">
      <h1 className="text-3xl">Delivery zones</h1>
      <p className="alert-info">
        Delivery rates are <strong>not configured</strong> by default. Customers can only check out to states covered by an active zone.
        Enter rates once they&apos;re confirmed with your logistics provider.
      </p>
      {!isAdmin && <p className="alert-info">Only administrators can edit delivery zones.</p>}
      {isAdmin && (
        <section className="card p-6">
          <h2 className="text-xl">New zone</h2>
          <div className="mt-4"><ZoneForm /></div>
        </section>
      )}
      {zones.map((z) => (
        <details key={z.id} className="card p-5">
          <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-2">
            <span className="font-medium">{z.name}{!z.isActive && <span className="ml-2 text-xs text-charcoal-400">(inactive)</span>}</span>
            <span className="text-sm">{formatMoney(z.feeKobo)} · {z.states.length} states</span>
          </summary>
          <p className="mt-2 text-sm text-charcoal-600">{z.states.join(", ")}</p>
          {isAdmin && (
            <div className="mt-4 border-t border-taupe-300 pt-4">
              <ZoneForm values={{ id: z.id, name: z.name, states: z.states, fee: minorToMajorString(z.feeKobo), etaText: z.etaText, isActive: z.isActive }} />
            </div>
          )}
        </details>
      ))}
    </div>
  );
}
