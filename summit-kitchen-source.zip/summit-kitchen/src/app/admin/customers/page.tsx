import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { getCurrentUser } from "@/lib/server/session";
import { setUserDisabledAction, setUserRoleAction } from "../actions";

export const metadata: Metadata = { title: "Customers" };
export const dynamic = "force-dynamic";

export default async function AdminCustomers({ searchParams }: { searchParams: Promise<{ q?: string; error?: string }> }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim().slice(0, 80);
  const me = await getCurrentUser();
  const isAdmin = me?.role === "ADMIN";
  const users = await prisma.user.findMany({
    where: q ? { OR: [{ email: { contains: q, mode: "insensitive" } }, { name: { contains: q, mode: "insensitive" } }] } : {},
    select: { id: true, name: true, email: true, role: true, disabled: true, createdAt: true, lastLoginAt: true, _count: { select: { orders: true } } },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return (
    <div className="space-y-6">
      <h1 className="text-3xl">Customers</h1>
      {sp.error === "self" && <p className="alert-error">You can&apos;t change your own role or disable your own account.</p>}
      {!isAdmin && <p className="alert-info">Only administrators can change roles or disable accounts.</p>}
      <form className="flex max-w-md gap-2">
        <label htmlFor="cq" className="sr-only">Search</label>
        <input id="cq" name="q" defaultValue={q} placeholder="Name or email" className="input" />
        <button className="btn-outline" type="submit">Search</button>
      </form>
      <div className="card overflow-x-auto">
        <table className="table min-w-[760px]">
          <thead><tr><th>Name</th><th>Email</th><th>Orders</th><th>Joined</th><th>Role</th><th>Status</th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>{u._count.orders}</td>
                <td>{u.createdAt.toLocaleDateString("en-NG", { timeZone: "Africa/Lagos" })}</td>
                <td>
                  {isAdmin && u.id !== me?.id ? (
                    <form action={setUserRoleAction} className="flex gap-1">
                      <input type="hidden" name="id" value={u.id} />
                      <select name="role" defaultValue={u.role} className="input h-9 min-h-0 w-auto py-1 text-xs" aria-label={`Role for ${u.email}`}>
                        <option value="CUSTOMER">Customer</option><option value="STAFF">Staff</option><option value="ADMIN">Admin</option>
                      </select>
                      <button type="submit" className="btn-outline min-h-9 px-2 py-1 text-xs">Set</button>
                    </form>
                  ) : u.role.toLowerCase()}
                </td>
                <td>
                  {isAdmin && u.id !== me?.id ? (
                    <form action={setUserDisabledAction}>
                      <input type="hidden" name="id" value={u.id} />
                      <input type="hidden" name="disabled" value={u.disabled ? "false" : "true"} />
                      <button type="submit" className={u.disabled ? "btn-outline min-h-9 px-2 py-1 text-xs" : "btn-danger min-h-9 px-2 py-1 text-xs"}>{u.disabled ? "Enable" : "Disable"}</button>
                    </form>
                  ) : u.disabled ? "Disabled" : "Active"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
