"use server";

// Every admin action re-checks authorisation itself. Layout guards only protect
// page rendering; server actions are separate POST endpoints.

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/server/db";
import { requireAdmin, requireStaff, revokeAllSessions } from "@/lib/server/session";
import { logActivity } from "@/lib/server/audit";
import { adjustStock, returnStock } from "@/lib/server/inventory";
import { validateCategory, validateProduct, validateZone, overlappingStates } from "@/lib/core/admin";
import { adminCanTransition, isOrderStatus, releasesStock } from "@/lib/core/orders";
import { parseIntStrict, text } from "@/lib/core/validation";

export type AdminState = { error?: string; success?: string; errors?: Record<string, string> } | null;

function uniqueError(e: unknown): string | null {
  if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
    const target = (e.meta?.target as string[] | undefined)?.join(", ") ?? "field";
    return `That ${target} is already in use.`;
  }
  return null;
}

// ---- Products --------------------------------------------------------------

export async function saveProductAction(_prev: AdminState, form: FormData): Promise<AdminState> {
  const me = await requireStaff();
  const parsed = validateProduct(form);
  if (!parsed.ok) return { errors: parsed.errors };
  const id = text(form, "id");
  const category = await prisma.category.findUnique({ where: { id: parsed.data.categoryId }, select: { id: true } });
  if (!category) return { errors: { categoryId: "Choose a category." } };
  try {
    if (id) {
      const before = await prisma.product.findUnique({ where: { id }, select: { priceKobo: true, isActive: true } });
      if (!before) return { error: "Product not found." };
      await prisma.product.update({ where: { id }, data: parsed.data });
      await logActivity({ actorId: me.id, action: "product.updated", entityType: "Product", entityId: id,
        details: { priceKobo: { from: before.priceKobo, to: parsed.data.priceKobo }, isActive: parsed.data.isActive } });
    } else {
      const initial = parseIntStrict(text(form, "initialStock") || "0", 0, 100_000);
      if (initial === null) return { errors: { initialStock: "Enter 0–100000." } };
      const created = await prisma.product.create({ data: { ...parsed.data, stock: initial } });
      if (initial > 0) await prisma.inventoryMovement.create({ data: { productId: created.id, delta: initial, reason: "RESTOCK", actorId: me.id, note: "Initial stock" } });
      await logActivity({ actorId: me.id, action: "product.created", entityType: "Product", entityId: created.id, details: { sku: created.sku } });
      revalidatePath("/admin/products");
      redirect(`/admin/products/${created.id}?created=1`);
    }
  } catch (e) {
    const msg = uniqueError(e);
    if (msg) return { error: msg };
    throw e;
  }
  revalidatePath("/admin/products");
  revalidatePath("/", "layout");
  return { success: "Product saved." };
}

export async function archiveProductAction(form: FormData): Promise<void> {
  const me = await requireAdmin();
  const id = text(form, "id");
  // Products are archived (hidden), never hard-deleted, so order history stays intact.
  await prisma.product.update({ where: { id }, data: { isActive: false } });
  await prisma.cartItem.deleteMany({ where: { productId: id } });
  await logActivity({ actorId: me.id, action: "product.archived", entityType: "Product", entityId: id });
  revalidatePath("/admin/products");
}

// ---- Stock -----------------------------------------------------------------

export async function adjustStockAction(_prev: AdminState, form: FormData): Promise<AdminState> {
  const me = await requireStaff();
  const productId = text(form, "productId");
  const delta = parseIntStrict(text(form, "delta"), -100_000, 100_000);
  const note = text(form, "note");
  if (delta === null || delta === 0) return { error: "Enter a whole number, e.g. 10 or -2." };
  if (note.length < 3) return { error: "Add a short reason for the adjustment." };
  const res = await adjustStock(productId, delta, me.id, note);
  if (!res.ok) return { error: res.error };
  await logActivity({ actorId: me.id, action: "stock.adjusted", entityType: "Product", entityId: productId, details: { delta, note } });
  revalidatePath("/admin/inventory");
  return { success: `Stock adjusted by ${delta > 0 ? "+" : ""}${delta}.` };
}

// ---- Categories ------------------------------------------------------------

export async function saveCategoryAction(_prev: AdminState, form: FormData): Promise<AdminState> {
  const me = await requireStaff();
  const parsed = validateCategory(form);
  if (!parsed.ok) return { errors: parsed.errors };
  const id = text(form, "id");
  try {
    const row = id
      ? await prisma.category.update({ where: { id }, data: parsed.data })
      : await prisma.category.create({ data: parsed.data });
    await logActivity({ actorId: me.id, action: id ? "category.updated" : "category.created", entityType: "Category", entityId: row.id });
  } catch (e) {
    const msg = uniqueError(e);
    if (msg) return { error: msg };
    throw e;
  }
  revalidatePath("/admin/categories");
  return { success: "Category saved." };
}

// ---- Orders ----------------------------------------------------------------

export async function updateOrderStatusAction(_prev: AdminState, form: FormData): Promise<AdminState> {
  const me = await requireStaff();
  const id = text(form, "id");
  const to = text(form, "status");
  const note = text(form, "note").slice(0, 300) || null;
  if (!isOrderStatus(to)) return { error: "Unknown status." };
  if (to === "REFUNDED" && me.role !== "ADMIN") return { error: "Only administrators can mark refunds." };

  const result = await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id }, select: { status: true } });
    if (!order) return { error: "Order not found." };
    if (!adminCanTransition(order.status, to)) return { error: `Cannot change ${order.status} to ${to}.` };
    // Guarded on the current status so two admins can't apply conflicting changes.
    const flip = await tx.order.updateMany({ where: { id, status: order.status }, data: { status: to } });
    if (flip.count !== 1) return { error: "The order changed while you were editing. Reload and try again." };
    if (releasesStock(order.status, to)) await returnStock(tx, id, `Order ${to.toLowerCase()} by staff`);
    await tx.orderStatusEvent.create({ data: { orderId: id, status: to, note, actorId: me.id } });
    await logActivity({ actorId: me.id, action: "order.status", entityType: "Order", entityId: id, details: { from: order.status, to, note } }, tx);
    return { success: `Order marked ${to.replace("_", " ").toLowerCase()}.` };
  });
  revalidatePath(`/admin/orders/${id}`);
  if (to === "REFUNDED" && result.success) {
    return { success: `${result.success} Remember to issue the refund in the Paystack dashboard — this only updates our records.` };
  }
  return result;
}

export async function updateTrackingAction(_prev: AdminState, form: FormData): Promise<AdminState> {
  const me = await requireStaff();
  const id = text(form, "id");
  const carrier = text(form, "carrier").slice(0, 60) || null;
  const trackingNumber = text(form, "trackingNumber").slice(0, 80) || null;
  await prisma.order.update({ where: { id }, data: { carrier, trackingNumber } });
  await logActivity({ actorId: me.id, action: "order.tracking", entityType: "Order", entityId: id, details: { carrier, trackingNumber } });
  revalidatePath(`/admin/orders/${id}`);
  return { success: "Tracking details saved." };
}

// ---- Customers (ADMIN only) ------------------------------------------------

export async function setUserDisabledAction(form: FormData): Promise<void> {
  const me = await requireAdmin();
  const id = text(form, "id");
  const disabled = text(form, "disabled") === "true";
  if (id === me.id) redirect("/admin/customers?error=self");
  await prisma.user.update({ where: { id }, data: { disabled } });
  if (disabled) await revokeAllSessions(id);
  await logActivity({ actorId: me.id, action: disabled ? "user.disabled" : "user.enabled", entityType: "User", entityId: id });
  revalidatePath("/admin/customers");
}

export async function setUserRoleAction(form: FormData): Promise<void> {
  const me = await requireAdmin();
  const id = text(form, "id");
  const role = text(form, "role");
  if (!["CUSTOMER", "STAFF", "ADMIN"].includes(role)) return;
  if (id === me.id) redirect("/admin/customers?error=self");
  await prisma.user.update({ where: { id }, data: { role: role as "CUSTOMER" | "STAFF" | "ADMIN" } });
  await revokeAllSessions(id); // force re-login with new privileges
  await logActivity({ actorId: me.id, action: "user.role", entityType: "User", entityId: id, details: { role } });
  revalidatePath("/admin/customers");
}

// ---- Delivery zones (ADMIN only) --------------------------------------------

export async function saveZoneAction(_prev: AdminState, form: FormData): Promise<AdminState> {
  const me = await requireAdmin();
  const parsed = validateZone(form);
  if (!parsed.ok) return { errors: parsed.errors };
  const id = text(form, "id") || undefined;
  if (parsed.data.isActive) {
    const zones = await prisma.deliveryZone.findMany({ select: { id: true, states: true, isActive: true } });
    const overlap = overlappingStates(zones, { id, states: parsed.data.states });
    if (overlap.length) return { error: `Already covered by another active zone: ${overlap.join(", ")}.` };
  }
  const row = id
    ? await prisma.deliveryZone.update({ where: { id }, data: parsed.data })
    : await prisma.deliveryZone.create({ data: parsed.data });
  await logActivity({ actorId: me.id, action: id ? "zone.updated" : "zone.created", entityType: "DeliveryZone", entityId: row.id, details: { feeKobo: row.feeKobo, states: row.states } });
  revalidatePath("/admin/delivery");
  return { success: "Delivery zone saved." };
}
