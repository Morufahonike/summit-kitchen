import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { paymentsConfigured } from "@/lib/server/payments";
import { formatMoney } from "@/lib/core/money";

export const metadata: Metadata = { title: "Payments" };
export const dynamic = "force-dynamic";

export default async function AdminPayments() {
  const [payments, webhooks] = await Promise.all([
    prisma.payment.findMany({ orderBy: { createdAt: "desc" }, take: 100, include: { order: { select: { id: true, reference: true } } } }),
    prisma.webhookEvent.findMany({ orderBy: { receivedAt: "desc" }, take: 20 }),
  ]);
  const cfg = paymentsConfigured();
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Payments</h1>
      <p className={cfg.ok ? "alert-info" : "alert-error"}>
        Gateway: Paystack · {cfg.ok ? <>Mode: <strong>{cfg.mode?.toUpperCase()}</strong></> : cfg.reason}
        {" "}· Live payments stay blocked until the owner approves them and <code>PAYSTACK_ALLOW_LIVE</code> is set.
      </p>
      <div className="card overflow-x-auto">
        <table className="table min-w-[760px]">
          <thead><tr><th>Date</th><th>Order</th><th>Reference</th><th>Status</th><th>Mode</th><th>Card</th><th className="text-right">Amount</th></tr></thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id}>
                <td>{p.createdAt.toLocaleString("en-NG", { timeZone: "Africa/Lagos", dateStyle: "short", timeStyle: "short" })}</td>
                <td><Link href={`/admin/orders/${p.order.id}`} className="hover:text-olive">{p.order.reference}</Link></td>
                <td className="font-mono text-xs">{p.reference}</td>
                <td>{p.status}</td>
                <td>{p.mode}</td>
                <td>{p.cardBrand ? `${p.cardBrand} •••• ${p.cardLast4 ?? ""}` : "—"}</td>
                <td className="text-right">{formatMoney(p.amountKobo, p.currency)}</td>
              </tr>
            ))}
            {payments.length === 0 && <tr><td colSpan={7} className="text-charcoal-400">No payments yet.</td></tr>}
          </tbody>
        </table>
      </div>
      <section className="card overflow-x-auto p-5">
        <h2 className="text-xl">Webhook events</h2>
        <table className="table mt-3 min-w-[560px]">
          <thead><tr><th>Received</th><th>Event</th><th>Reference</th><th>Result</th></tr></thead>
          <tbody>
            {webhooks.map((w) => (
              <tr key={w.id}>
                <td>{w.receivedAt.toLocaleString("en-NG", { timeZone: "Africa/Lagos" })}</td>
                <td>{w.eventType}</td>
                <td className="font-mono text-xs">{w.reference}</td>
                <td>{w.processedAt ? (w.error ?? "processed") : <span className="text-red-700">{w.error ?? "pending"}</span>}</td>
              </tr>
            ))}
            {webhooks.length === 0 && <tr><td colSpan={4} className="text-charcoal-400">No webhooks received.</td></tr>}
          </tbody>
        </table>
      </section>
    </div>
  );
}
