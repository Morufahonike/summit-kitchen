import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { CategoryForm } from "../AdminForms";

export const metadata: Metadata = { title: "Categories" };
export const dynamic = "force-dynamic";

export default async function AdminCategories() {
  const categories = await prisma.category.findMany({ orderBy: [{ sortOrder: "asc" }, { name: "asc" }], include: { _count: { select: { products: true } } } });
  return (
    <div className="max-w-4xl space-y-6">
      <h1 className="text-3xl">Categories</h1>
      <section className="card p-6">
        <h2 className="text-xl">Add category</h2>
        <div className="mt-4"><CategoryForm /></div>
      </section>
      <div className="space-y-3">
        {categories.map((c) => (
          <details key={c.id} className="card p-5">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3">
              <span className="font-medium">{c.name} <span className="text-sm text-charcoal-400">/{c.slug}</span></span>
              <span className="text-sm text-charcoal-400">{c._count.products} products{c.isActive ? "" : " · hidden"}</span>
            </summary>
            <div className="mt-4 border-t border-taupe-300 pt-4"><CategoryForm values={c} /></div>
          </details>
        ))}
      </div>
    </div>
  );
}
