import Link from "next/link";
import { prisma } from "@/lib/server/db";
import { releaseExpiredReservations } from "@/lib/server/inventory";
import { paymentsConfigured } from "@/lib/server/payments";
import { formatMoney } from "@/lib/core/money";
import { STATUS_LABEL } from "@/lib/core/orders";

export const dynamic = "force-dynamic";

function Stat({ label, value, href }: { label: string; value: string | number; href?: string }) {
  const body = (
    <div className="card p-5">
      <p className="text-xs uppercase tracking-wider text-charcoal-400">{label}</p>
      <p className="mt-2 font-serif text-3xl">{value}</p>
    </div>
  );
  return href ? <Link href={href} className="block hover:opacity-90">{body}</Link> : body;
}

export default async function AdminDashboard({ searchParams }: { searchParams: Promise<{ denied?: string }> }) {
  await releaseExpiredReservations();
  const since = new Date(Date.now() - 30 * 86400_000);
  const [paidAgg, toFulfil, awaiting, lowStock, zones, review, recent] = await Promise.all([
    prisma.order.aggregate({ where: { status: { in: ["PAID", "PROCESSING", "SHIPPED", "DELIVERED"] }, createdAt: { gte: since } }, _sum: { totalKobo: true }, _count: true }),
    prisma.order.count({ where: { status: { in: ["PAID", "PROCESSING"] } } }),
    prisma.order.count({ where: { status: "PENDING_PAYMENT" } }),
    prisma.product.findMany({ where: { isActive: true, stock: { lte: 5 } }, orderBy: { stock: "asc" }, take: 8, select: { id: true, name: true, stock: true } }),
    prisma.deliveryZone.count({ where: { isActive: true } }),
    prisma.activityLog.findMany({ where: { action: { in: ["payment.needs_review", "payment.mismatch"] }, createdAt: { gte: since } }, orderBy: { createdAt: "desc" }, take: 5 }),
    prisma.order.findMany({ orderBy: { createdAt: "desc" }, take: 8 }),
  ]);
  const pay = paymentsConfigured();
  const { denied } = await searchParams;

  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Dashboard</h1>
      {denied && <p className="alert-error">That area needs administrator access.</p>}

      <div className="space-y-2">
        {zones === 0 && <p className="alert-info"><strong>Checkout is disabled:</strong> no delivery zones are configured. <Link className="underline" href="/admin/delivery">Set up delivery rates</Link>.</p>}
        {!pay.ok && <p className="alert-info"><strong>Payments not configured:</strong> {pay.reason}</p>}
        {pay.mode === "test" && <p className="alert-info">Payments are in <strong>Paystack TEST mode</strong>. No real money is collected.</p>}
        {review.map((r) => (
          <p key={r.id} className="alert-error">
            Payment needs review ({r.action.replace("payment.", "")}) — <Link className="underline" href={`/admin/orders/${r.entityId}`}>open order</Link>
          </p>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Paid sales (30 days)" value={formatMoney(paidAgg._sum.totalKobo ?? 0)} />
        <Stat label="Paid orders (30 days)" value={paidAgg._count} />
        <Stat label="To fulfil" value={toFulfil} href="/admin/orders?status=PAID" />
        <Stat label="Awaiting payment" value={awaiting} href="/admin/orders?status=PENDING_PAYMENT" />
      </div>

      <div className="grid gap-6 xl:grid-cols-[2fr_1fr]">
        <section className="card overflow-x-auto p-5">
          <h2 className="text-xl">Recent orders</h2>
          <table className="table mt-3 min-w-[480px]">
            <thead><tr><th>Reference</th><th>Customer</th><th>Status</th><th className="text-right">Total</th></tr></thead>
            <tbody>
              {recent.map((o) => (
                <tr key={o.id}>
                  <td><Link href={`/admin/orders/${o.id}`} className="font-medium hover:text-olive">{o.reference}</Link></td>
                  <td>{o.shippingName}</td>
                  <td>{STATUS_LABEL[o.status]}</td>
                  <td className="text-right">{formatMoney(o.totalKobo, o.currency)}</td>
                </tr>
              ))}
              {recent.length === 0 && <tr><td colSpan={4} className="text-charcoal-400">No orders yet.</td></tr>}
            </tbody>
          </table>
        </section>
        <section className="card p-5">
          <h2 className="text-xl">Low stock</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {lowStock.map((p) => (
              <li key={p.id} className="flex justify-between gap-2">
                <Link href={`/admin/products/${p.id}`} className="hover:text-olive">{p.name}</Link>
                <span className={p.stock === 0 ? "font-semibold text-red-700" : "text-gold-600"}>{p.stock}</span>
              </li>
            ))}
            {lowStock.length === 0 && <li className="text-charcoal-400">All products have healthy stock.</li>}
          </ul>
        </section>
      </div>
    </div>
  );
}
