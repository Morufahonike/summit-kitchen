import Link from "next/link";
import type { Metadata } from "next";
import { requireStaff } from "@/lib/server/session";
import { Logo } from "@/components/Logo";
import { logoutAction } from "@/app/(store)/account/actions";

export const metadata: Metadata = { title: { default: "Admin", template: "%s | Summit Admin" }, robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/inventory", label: "Stock" },
  { href: "/admin/customers", label: "Customers" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/delivery", label: "Delivery" },
  { href: "/admin/activity", label: "Activity" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const me = await requireStaff();
  return (
    <div className="min-h-screen bg-ivory lg:grid lg:grid-cols-[220px_1fr]">
      <aside className="border-b border-forest-800 bg-forest text-ivory lg:min-h-screen lg:border-b-0">
        <div className="flex items-center justify-between px-4 py-4 lg:block lg:px-5 lg:py-6">
          <Link href="/admin" aria-label="Admin home"><Logo tone="light" stacked={false} className="[&_span]:text-sm" /></Link>
          <p className="text-xs text-ivory/60 lg:mt-3">{me.role === "ADMIN" ? "Administrator" : "Staff"}</p>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-2 pb-3 lg:flex-col lg:px-3" aria-label="Admin">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} className="whitespace-nowrap rounded-md px-3 py-2 text-sm text-ivory/85 hover:bg-forest-800 hover:text-white">{n.label}</Link>
          ))}
          <form action={logoutAction} className="lg:hidden">
            <button type="submit" className="whitespace-nowrap rounded-md px-3 py-2 text-sm text-ivory/85 hover:bg-forest-800">Sign out</button>
          </form>
        </nav>
        <div className="hidden px-5 py-6 text-xs text-ivory/60 lg:block">
          <p className="truncate">{me.email}</p>
          <div className="mt-2 flex gap-3">
            <Link href="/" className="underline">View store</Link>
            <form action={logoutAction}><button type="submit" className="underline">Sign out</button></form>
          </div>
        </div>
      </aside>
      <main id="main" className="min-w-0 px-4 py-6 sm:px-6 lg:px-10 lg:py-10">{children}</main>
    </div>
  );
}
