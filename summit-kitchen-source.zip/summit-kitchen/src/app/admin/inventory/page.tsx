import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/server/db";
import { StockForm } from "../AdminForms";

export const metadata: Metadata = { title: "Stock" };
export const dynamic = "force-dynamic";

export default async function AdminInventory() {
  const [products, movements] = await Promise.all([
    prisma.product.findMany({ where: { isActive: true }, orderBy: [{ stock: "asc" }, { name: "asc" }], select: { id: true, name: true, sku: true, stock: true } }),
    prisma.inventoryMovement.findMany({ orderBy: { createdAt: "desc" }, take: 30, include: { product: { select: { name: true } } } }),
  ]);
  return (
    <div className="space-y-8">
      <h1 className="text-3xl">Stock</h1>
      <p className="text-sm text-charcoal-600">Stock is reserved when an order is placed and returned automatically if payment isn&apos;t completed in time or the order is cancelled.</p>
      <div className="card overflow-x-auto">
        <table className="table min-w-[640px]">
          <thead><tr><th>Product</th><th>SKU</th><th className="text-right">Available</th><th>Adjust</th></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td><Link href={`/admin/products/${p.id}`} className="hover:text-olive">{p.name}</Link></td>
                <td className="font-mono text-xs">{p.sku}</td>
                <td className={`text-right font-semibold ${p.stock === 0 ? "text-red-700" : p.stock <= 5 ? "text-gold-600" : ""}`}>{p.stock}</td>
                <td><StockForm productId={p.id} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <section className="card overflow-x-auto p-5">
        <h2 className="text-xl">Recent movements</h2>
        <table className="table mt-3 min-w-[560px]">
          <thead><tr><th>When</th><th>Product</th><th>Change</th><th>Reason</th><th>Note</th></tr></thead>
          <tbody>
            {movements.map((m) => (
              <tr key={m.id}>
                <td>{m.createdAt.toLocaleString("en-NG", { timeZone: "Africa/Lagos" })}</td>
                <td>{m.product.name}</td>
                <td className={m.delta > 0 ? "text-olive" : "text-red-700"}>{m.delta > 0 ? `+${m.delta}` : m.delta}</td>
                <td>{m.reason.replace("_", " ").toLowerCase()}</td>
                <td>{m.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
