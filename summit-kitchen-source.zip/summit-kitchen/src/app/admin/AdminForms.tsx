"use client";
import { useActionState } from "react";
import {
  saveProductAction, adjustStockAction, saveCategoryAction, updateOrderStatusAction, updateTrackingAction, saveZoneAction,
  type AdminState,
} from "./actions";
import { Field, FormMessage } from "@/components/Field";
import { SubmitButton } from "@/components/SubmitButton";
import { NIGERIAN_STATES } from "@/lib/core/validation";
import { STATUS_LABEL, type OrderStatusName } from "@/lib/core/orders";

type ProductValues = {
  id?: string; name?: string; slug?: string; sku?: string; description?: string; categoryId?: string; price?: string; compareAt?: string;
  material?: string | null; colour?: string | null; image?: string | null; isActive?: boolean; isFeatured?: boolean; isBestseller?: boolean; isSample?: boolean;
};

function Check({ name, label, defaultChecked }: { name: string; label: string; defaultChecked?: boolean }) {
  return <label className="flex items-center gap-2 text-sm"><input type="checkbox" name={name} defaultChecked={defaultChecked} className="accent-olive" /> {label}</label>;
}

export function ProductForm({ values, categories }: { values: ProductValues; categories: { id: string; name: string }[] }) {
  const [s, a] = useActionState<AdminState, FormData>(saveProductAction, null);
  const e = s?.errors ?? {};
  return (
    <form action={a} className="space-y-5" noValidate>
      <FormMessage error={s?.error ?? (Object.keys(e).length ? "Please check the highlighted fields." : null)} success={s?.success} />
      {values.id && <input type="hidden" name="id" value={values.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2"><Field name="name" label="Name" required defaultValue={values.name} error={e.name} /></div>
        <Field name="slug" label="URL slug (blank = from name)" defaultValue={values.slug} error={e.slug} />
        <Field name="sku" label="SKU" required defaultValue={values.sku} error={e.sku} />
        <div className="sm:col-span-2">
          <label htmlFor="f-description" className="label">Description *</label>
          <textarea id="f-description" name="description" rows={5} className="input" defaultValue={values.description} />
          {e.description && <p className="field-error">{e.description}</p>}
        </div>
        <div>
          <label htmlFor="f-categoryId" className="label">Category *</label>
          <select id="f-categoryId" name="categoryId" className="input" defaultValue={values.categoryId ?? ""}>
            <option value="" disabled>Choose…</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          {e.categoryId && <p className="field-error">{e.categoryId}</p>}
        </div>
        <Field name="image" label="Image path (e.g. /images/products/cookware.svg)" defaultValue={values.image} error={e.image} />
        <Field name="price" label="Price (₦)" inputMode="decimal" required defaultValue={values.price} error={e.price} />
        <Field name="compareAt" label="Compare-at price (₦, optional)" inputMode="decimal" defaultValue={values.compareAt} error={e.compareAt} />
        <Field name="material" label="Material" defaultValue={values.material} />
        <Field name="colour" label="Colour" defaultValue={values.colour} />
        {!values.id && <Field name="initialStock" label="Initial stock" inputMode="numeric" defaultValue="0" error={e.initialStock} />}
      </div>
      <div className="flex flex-wrap gap-x-6 gap-y-2">
        <Check name="isActive" label="Visible in store" defaultChecked={values.isActive ?? true} />
        <Check name="isFeatured" label="Featured" defaultChecked={values.isFeatured} />
        <Check name="isBestseller" label="Bestseller" defaultChecked={values.isBestseller} />
        <Check name="isSample" label="Sample product (shows badge)" defaultChecked={values.isSample ?? true} />
      </div>
      <SubmitButton pendingText="Saving…">{values.id ? "Save changes" : "Create product"}</SubmitButton>
    </form>
  );
}

export function StockForm({ productId }: { productId: string }) {
  const [s, a] = useActionState<AdminState, FormData>(adjustStockAction, null);
  return (
    <form action={a} className="relative flex flex-wrap items-start gap-2">
      <input type="hidden" name="productId" value={productId} />
      <label className="sr-only" htmlFor={`d-${productId}`}>Adjustment</label>
      <input id={`d-${productId}`} name="delta" inputMode="numeric" placeholder="+10 / -2" className="input h-9 min-h-0 w-24" />
      <label className="sr-only" htmlFor={`n-${productId}`}>Reason</label>
      <input id={`n-${productId}`} name="note" placeholder="Reason" className="input h-9 min-h-0 w-36" />
      <SubmitButton className="btn-outline min-h-9 px-3 py-1" pendingText="…">Apply</SubmitButton>
      {(s?.error || s?.success) && <p className={`w-full text-xs ${s.error ? "text-red-700" : "text-olive"}`}>{s.error ?? s.success}</p>}
    </form>
  );
}

export function CategoryForm({ values }: { values?: { id: string; name: string; slug: string; description: string | null; sortOrder: number; isActive: boolean } }) {
  const [s, a] = useActionState<AdminState, FormData>(saveCategoryAction, null);
  const e = s?.errors ?? {};
  return (
    <form action={a} className="space-y-3">
      <FormMessage error={s?.error} success={s?.success} />
      {values && <input type="hidden" name="id" value={values.id} />}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field name="name" label="Name" required defaultValue={values?.name} error={e.name} />
        <Field name="slug" label="Slug" defaultValue={values?.slug} error={e.slug} />
        <Field name="description" label="Description" defaultValue={values?.description} />
        <Field name="sortOrder" label="Sort order" inputMode="numeric" defaultValue={String(values?.sortOrder ?? 0)} error={e.sortOrder} />
      </div>
      <Check name="isActive" label="Active" defaultChecked={values?.isActive ?? true} />
      <SubmitButton className="btn-outline" pendingText="Saving…">{values ? "Save" : "Add category"}</SubmitButton>
    </form>
  );
}

export function OrderStatusForm({ id, next }: { id: string; next: OrderStatusName[] }) {
  const [s, a] = useActionState<AdminState, FormData>(updateOrderStatusAction, null);
  if (next.length === 0) return <p className="text-sm text-charcoal-400">No further status changes are available.</p>;
  return (
    <form action={a} className="space-y-3">
      <FormMessage error={s?.error} success={s?.success} />
      <input type="hidden" name="id" value={id} />
      <div>
        <label htmlFor="o-status" className="label">Change status to</label>
        <select id="o-status" name="status" className="input">
          {next.map((st) => <option key={st} value={st}>{STATUS_LABEL[st]}</option>)}
        </select>
      </div>
      <Field name="note" label="Note (internal, optional)" />
      <SubmitButton className="btn-forest" pendingText="Updating…">Update status</SubmitButton>
    </form>
  );
}

export function TrackingForm({ id, carrier, trackingNumber }: { id: string; carrier: string | null; trackingNumber: string | null }) {
  const [s, a] = useActionState<AdminState, FormData>(updateTrackingAction, null);
  return (
    <form action={a} className="space-y-3">
      <FormMessage error={s?.error} success={s?.success} />
      <input type="hidden" name="id" value={id} />
      <Field name="carrier" label="Carrier" defaultValue={carrier} />
      <Field name="trackingNumber" label="Tracking number" defaultValue={trackingNumber} />
      <SubmitButton className="btn-outline" pendingText="Saving…">Save tracking</SubmitButton>
    </form>
  );
}

export function ZoneForm({ values }: { values?: { id: string; name: string; states: string[]; fee: string; etaText: string | null; isActive: boolean } }) {
  const [s, a] = useActionState<AdminState, FormData>(saveZoneAction, null);
  const e = s?.errors ?? {};
  return (
    <form action={a} className="space-y-4">
      <FormMessage error={s?.error} success={s?.success} />
      {values && <input type="hidden" name="id" value={values.id} />}
      <div className="grid gap-3 sm:grid-cols-3">
        <Field name="name" label="Zone name" required defaultValue={values?.name} error={e.name} />
        <Field name="fee" label="Delivery fee (₦)" inputMode="decimal" required defaultValue={values?.fee} error={e.fee} />
        <Field name="etaText" label="Delivery estimate (optional)" defaultValue={values?.etaText} placeholder="e.g. 2–4 working days" />
      </div>
      <fieldset>
        <legend className="label">States covered</legend>
        <div className="grid max-h-56 grid-cols-2 gap-1 overflow-y-auto rounded-md border border-taupe p-3 text-sm sm:grid-cols-3 lg:grid-cols-4">
          {NIGERIAN_STATES.map((st) => (
            <label key={st} className="flex items-center gap-2"><input type="checkbox" name="states" value={st} defaultChecked={values?.states.includes(st)} className="accent-olive" /> {st}</label>
          ))}
        </div>
        {e.states && <p className="field-error">{e.states}</p>}
      </fieldset>
      <Check name="isActive" label="Active" defaultChecked={values?.isActive ?? true} />
      <SubmitButton pendingText="Saving…">{values ? "Save zone" : "Create zone"}</SubmitButton>
    </form>
  );
}
